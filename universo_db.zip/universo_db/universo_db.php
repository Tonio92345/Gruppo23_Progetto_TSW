<!DOCTYPE html>
<?php
    require_once "../logindb.php";

  session_start();
 ?>
<html lang="<?php echo $lan;?>">
<head>
    <?php include '../language/language.php'; ?>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Universo Harry Potter</title>
    <base href=""/>
    <link rel="icon" href="../header/img/C.png" type="image/X-icon"/>
    <link rel="stylesheet" type="text/css" href="universo_db2.css">
    <meta name="author" content="Gruppo21"/>
    <meta name="keywords" content="Dragonball, Goku, sfere del drago, Namecc, Stanza dello spirito e del tempo, Super Sayan"/>
    <meta name="description" content="Pagina riguardante l'universo di Dragonball che presenta tre mete: Namecc, Stanza dello spirito e del tempo, Torneo Tenkaichi"/>

    <script>
      //Funzione che serve per far inserire all'utente un numero di stelle nella recensione
      //e inserire il numero di stelle nel database
      //Come parametri gli vien passato il num di stelle che dipende dalla stella che clicco
      function background_stelle(x){
          //Array dove prendo le 5 img stelle 
          var stelle = new Array();
          stelle[0] = document.querySelector("#stella1");
          stelle[1] = document.querySelector("#stella2");
          stelle[2] = document.querySelector("#stella3");
          stelle[3] = document.querySelector("#stella4");
          stelle[4] = document.querySelector("#stella5");
          
          //Prendo il numero di stelle e lo metto nell'input nascosto che poi mando col form
          //per inserire una recensione
          var num_stelle = document.getElementById('num_stelle');
          num_stelle.value = x;

          //Prendo il bottone per inviare la recensione
          var btn = document.getElementById('rec_button');

          //Coloro le stelle in base a quella che clicco e quando le stelle diventano gialle abilito il
          //bottone per inserire la recensione
          if(stelle[x-1].style.backgroundColor === 'transparent'){
              while(x !== 0){
                  stelle[x-1].style.backgroundColor = 'yellow';
                  x--;
              }
              btn.disabled = false;
              btn.style.backgroundColor = "";
              btn.style.color = "";

          }
          //Funzione che fa tornare le stelle trasparenti quando clicco una stella colorata di giallo
          //Quando poi le stelle diventano trasparenti torno a disabilitare il bottone
          else{
              x = stelle.length;
              while(x !== 0){
                  stelle[x-1].style.backgroundColor = 'transparent';
                  x--;
              }
              btn.disabled = true;
              btn.style.backgroundColor = 'grey';
              btn.style.color = 'white';
          }
      }

      //Setta il bottone per la recensione, che inizialmente è disabilitato perchè non ho scelto quante stelle ha la recensione
      function set_rec_button(){
        //Prendo il bottone per inviare la recensione
        var btn = document.getElementById('rec_button');
        btn.disabled = true;
        btn.style.backgroundColor = 'grey';
        btn.style.color = 'white';
      }

    </script>

  </head>
  <body onload="disabilitaFinestre();set_rec_button()">
    <header>
        <?php include '../header/header.php' ?>
    </header>

    <div class="box">

    <div class="totale">
      <div class="apertura">
        <canvas id="animazione1" width="250" height="100"></canvas>
        <img id="logo" src="immagini\Dragon-Ball-Logo.png" alt="logo" width="250" height="140">
        <canvas id="animazione2" width="250" height="100"></canvas>
      </div>



      <div class="presentazione">
        <img id="goku" src="immagini\goku_presenta.png" alt="goku" width="250" height="200">
        <p id="fumetto">
          <p id="descrizione_iniziale"><?php echo $dizionario['descrizione_iniziale_db']; ?></p>
        </p>
      </div>


      <br><br><br>
      <h1 id="scelta"><?php echo $dizionario['scelta_db']; ?></h1>

      <div class="luoghi">

        <div class="luogo1">
            <h1 class="titoli" >Namecc</h1>
            <br>
            <div class="descrizione">
              <img id="namecc" onclick="nascondiLuoghi(event)" class="immagini" src="immagini\namecc.jpg" alt="Namecc" width="350" height="200">
              <p class="brevi_descrizioni"><?php echo $dizionario['breve_descrizione1_db']; ?></p>
            </div>

        </div>
        <br> <br>


        <div class="luogo2">
            <h1 class="titoli"><?php echo $dizionario['stanza_db']; ?></h1>
            <br>
            <div class="descrizione">
              <img id="stanza" onclick="nascondiLuoghi(event)" class="immagini" src="immagini\stanza_dello_spirito.jpg" alt="stanza dello spirito e del tempo" width="350" height="200">
              <p class="brevi_descrizioni"><?php echo $dizionario['breve_descrizione2_db']; ?></p>
            </div>
        </div>
        <br> <br>


        <div class="luogo3">
          <h1 class="titoli"><?php echo $dizionario['torneo_db']; ?></h1>
          <br>
          <div class="descrizione">
            <img id="torneo" onclick="nascondiLuoghi(event)" class="immagini" src="immagini\torneo_tenkaichi.jpeg" alt="torneo tenkaichi" width="250" height="200">
            <p class="brevi_descrizioni"><?php echo $dizionario['breve_descrizione3_db']; ?></p>
          </div>

        </div>

        <br><br><br><br>
        </div>



          <div class="prenotazione1">
            <h1 class="titolo">Namecc</h1>
            <div class="sezione1">
              <div class="caratteristiche">
                <p> <?php echo $dizionario['caratteristiche1_db']; ?></p>
              </div>
              <div class="contenitore">
                <div class="collage">
                  <img class="foto_collage" src="immagini\namecc1.jpg" alt="namecc1" width="280px" height="190px">
                </div>
                <div class="collage">
                  <img class="foto_collage" src="immagini\namec2.jpeg" alt="namecc2" width="280px" height="190px">
                </div>
                <div class="collage">
                  <img class="foto_collage" src="immagini\namecc3.jpeg" alt="namecc3" width="280px" height="190px">
                </div>
                <div class="collage">
                  <img class="foto_collage" src="immagini\namecc4.jpeg" alt="namecc4" width="180px" height="130px">
                </div>
                <div class="collage">
                  <img class="foto_collage" src="immagini\namecc5.jpeg" alt="namecc5" width="180px" height="130px">
                </div>
                <div class="collage">
                  <img class="foto_collage" src="immagini\namecc6.jpeg" alt="namecc6" width="180px" height="130px">
                </div>
                <div class="collage">
                  <img class="foto_collage" src="immagini\namecc7.jpeg" alt="namecc7" width="180px" height="130px">
                </div>
              </div>


            </div>
            <p class="descrizione_approfondita"><?php echo $dizionario['descrizione_approfondita1_db']; ?></p>
            <br><br>

            <?php
              if($_SESSION['logged']){
            ?>

            <h2 class="prenota_biglietto"><?php echo $dizionario['prenota_biglietto_db']; ?></h2>
            <div class="biglietto">
              <form class="modulo_ticket" action="mailto:multiversus.tsw21@gmail.com?subject=voglio_prenotarmi_su_Namecc" method="post">
                <p><label for="nome"><?php echo $dizionario['nome_db']; ?> <input type="text" name="nome" value="" placeholder="Giovanni" required></p>

                <p><label for="cognome"><?php echo $dizionario['cognome_db']; ?> <input type="text" name="cognome" value="" placeholder="Rossi" required></label></p>

                <p><label for="mail"><?php echo $dizionario['email_db']; ?><input type="email" name="mail" value="" placeholder="gio.rossi@gmail.com" required></label></p>

                <p><label for="data_iniziale"><?php echo $dizionario['da_db']; ?><input type="date" name="data_iniziale" value="" required></label>
                <label for="data_finale"><?php echo $dizionario['a_db']; ?> <input type="date" name="data_finale" value="" required></label></p>
                <p><label for="invio"><input type="submit" name="invio" value="<?php echo $dizionario['invia_prenotazione'] ?>"></label></p>
              </form>
            </div>

            
            <?php
                }else{
            ?>
            
            <div>
                <p><?php echo $dizionario['prenotazione_non_loggato']; ?></p>
            </div>
            
            <?php
                }
            ?>

            <br><br>
            <input onclick="tornaIndietro()" class="bottone" type="button" name="back" value="<?php echo $dizionario['torna_indietro'] ?>">
          </div>


          <div class="prenotazione2">
            <h1 class="titolo"><?php echo $dizionario['stanza_db']; ?></h1>
            <div class="sezione1">
              <div class="caratteristiche">
                <p> <?php echo $dizionario['caratteristiche2_db']; ?></p>
              </div>
              <div class="contenitore">
                <div class="collage">
                  <img class="foto_collage" src="immagini\stanza1.jpg" alt="stanza1" width="280px" height="190px">
                </div>
                <div class="collage">
                  <img class="foto_collage" src="immagini\stanza2.jpg" alt="stanza2" width="280px" height="190px">
                </div>
                <div class="collage">
                  <img class="foto_collage" src="immagini\stanza3.jpg" alt="stanza3" width="280px" height="190px">
                </div>
                <div class="collage">
                  <img class="foto_collage" src="immagini\stanza4.jpg" alt="stanza4" width="180px" height="130px">
                </div>
                <div class="collage">
                  <img class="foto_collage" src="immagini\stanza5.jpg" alt="stanza5" width="180px" height="130px">
                </div>
                <div class="collage">
                  <img class="foto_collage" src="immagini\stanza6.jpeg" alt="stanza6" width="180px" height="130px">
                </div>
                <div class="collage">
                  <img class="foto_collage" src="immagini\stanza7.jpg" alt="stanza7" width="180px" height="130px">
                </div>
              </div>


            </div>
            <p class="descrizione_approfondita"><?php echo $dizionario['descrizione_approfondita2_db']; ?>
            </p>
            <br><br>

            <?php
              if($_SESSION['logged']){
            ?>

            <h2 class="prenota_biglietto"><?php echo $dizionario['prenota_biglietto_db']; ?></h2>
            <div class="biglietto">
              <form class="modulo_ticket" action="mailto:multiversus.tsw21@gmail.com?subject=voglio_prenotarmi_alla_stanza_dello_spirito_e_del_tempo" method="post">
                <p><label for="nome"><?php echo $dizionario['nome_db']; ?> <input type="text" name="nome" value="" placeholder="Giovanni" required></p>

                <p><label for="cognome"><?php echo $dizionario['cognome_db']; ?> <input type="text" name="cognome" value="" placeholder="Rossi" required></label></p>

                <p><label for="mail"><?php echo $dizionario['email_db']; ?> <input type="email" name="mail" value="" placeholder="gio.rossi@gmail.com" required></label></p>

                <p><label for="data_iniziale"><?php echo $dizionario['da_db']; ?><input type="date" name="data_iniziale" value="" required></label>
                <label for="data_finale"><?php echo $dizionario['a_db']; ?> <input type="date" name="data_finale" value="" required></label></p>
                <p><label for="invio"><input type="submit" name="invio" value="<?php echo $dizionario['invia_prenotazione'] ?>"></label></p>
              </form>
            </div>
             
            <?php
                }else{
            ?>
            
            <div>
                <p><?php echo $dizionario['prenotazione_non_loggato']; ?></p>
            </div>
            
            <?php
                }
            ?>

            <br><br>
            <input onclick="tornaIndietro()" class="bottone" type="button" name="back" value="<?php echo $dizionario['torna_indietro'] ?>">


          </div>

          <div class="prenotazione3">
            <h1 class="titolo"><?php echo $dizionario['torneo_db']; ?></h1>
            <div class="sezione1">
              <div class="caratteristiche">
                <p><?php echo $dizionario['caratteristiche3_db']; ?></p>
              </div>
              <div class="contenitore">
                <div class="collage">
                  <img class="foto_collage" src="immagini\torneo1.jpeg" alt="torneo1" width="280px" height="190px">
                </div>
                <div class="collage">
                  <img class="foto_collage" src="immagini\torneo2.jpeg" alt="torneo2" width="280px" height="190px">
                </div>
                <div class="collage">
                  <img class="foto_collage" src="immagini\torneo3.jpg" alt="torneo3" width="280px" height="190px">
                </div>
                <div class="collage">
                  <img class="foto_collage" src="immagini\torneo4.jpeg" alt="torneo4" width="180px" height="130px">
                </div>
                <div class="collage">
                  <img class="foto_collage" src="immagini\torneo5.jpeg" alt="torneo5" width="180px" height="130px">
                </div>
                <div class="collage">
                  <img class="foto_collage" src="immagini\torneo6.jpeg" alt="torneo6" width="180px" height="130px">
                </div>
                <div class="collage">
                  <img class="foto_collage" src="immagini\torneo7.jpeg" alt="torneo7" width="180px" height="130px">
                </div>
              </div>


            </div>
            <p class="descrizione_approfondita"><?php echo $dizionario['descrizione_approfondita3_db']; ?>
            </p>
            <br><br>

            <?php
                if($_SESSION['logged']){
            ?>
                        
            <h2 class="prenota_biglietto"><?php echo $dizionario['prenota_biglietto_db']; ?></h2>
            <div class="biglietto">
              <form class="modulo_ticket" action="mailto:multiversus.tsw21@gmail.com?subject=voglio_prenotarmi_al_torneo_tenkaichi" method="post">
                <p><label for="nome"><?php echo $dizionario['nome_db']; ?><input type="text" name="nome" value="" placeholder="Giovanni" required></p>

                <p><label for="cognome"><?php echo $dizionario['cognome_db']; ?><input type="text" name="cognome" value="" placeholder="Rossi" required></label></p>

                <p><label for="mail"><?php echo $dizionario['email_db']; ?> <input type="email" name="mail" value="" placeholder="gio.rossi@gmail.com" required></label></p>

                <p><label for="data_iniziale"><?php echo $dizionario['da_db']; ?> <input type="date" name="data_iniziale" value="" required></label>
                <label for="data_finale"><?php echo $dizionario['a_db']; ?> <input type="date" name="data_finale" value="" required></label></p>
                <p><label for="invio"><input type="submit" name="invio" value="<?php echo $dizionario['invia_prenotazione'] ?>"></label></p>
              </form>
            </div>

            <?php
                }else{
            ?>
            
            <div>
                <p><?php echo $dizionario['prenotazione_non_loggato']; ?></p>
            </div>
            
            <?php
                }
            ?>

            <br><br>
            <input onclick="tornaIndietro()" class="bottone" type="button" name="back" value="<?php echo $dizionario['torna_indietro'] ?>">


          </div>




        <h1><?php echo $dizionario['recensione_db']; ?></h1>

        <div class="recensioni">
          <?php
            //Se l'utente è loggato vengono mostrati i commenti e viene data la possibilità di inserire un commento
            if($_SESSION['logged'] == true){
            ?>

            <!--Contenitore col form dove mettere i campi per inserire una recensione-->
            <div>
                <form action="<?php echo $_SERVER['PHP_SELF']?>" method="post">

                    <!--Area di testo dove inserire la recensione-->
                    <p class="campo_rec">
                        <label for="recensione">Inserisci una recensione:</label> <br>
                        <textarea name="recensione" cols="160" rows="5" required></textarea>
                    </p>

                    <!--Campo dove inserire le stelle della recensione-->
                    <p class="campo_rec">
                        <label for="stelle">Inserisci un numero di stelle:  </label>
                        <div class="stars">
                          <img id="stella1" onclick="background_stelle(1)" src="immagini/not_selected_star_db.png" alt="stellina_recensioni1" height="30cm" width="30cm">
                          <img id="stella2" onclick="background_stelle(2)" src="immagini/not_selected_star_db.png" alt="stellina_recensioni2" height="30cm" width="30cm">
                          <img id="stella3" onclick="background_stelle(3)" src="immagini/not_selected_star_db.png" alt="stellina_recensioni3" height="30cm" width="30cm">
                          <img id="stella4" onclick="background_stelle(4)" src="immagini/not_selected_star_db.png" alt="stellina_recensioni4" height="30cm" width="30cm">
                          <img id="stella5" onclick="background_stelle(5)" src="immagini/not_selected_star_db.png" alt="stellina_recensioni5" height="30cm" width="30cm">
                        </div>
                        
                        <!--Quando clicco una stella per indicare quante stelle ha la recensione viene aggiornato il valore di questo input nascosto
                            che poi mado tramite il form e mi permette di conservare il numero di stelle del commento-->
                        <input type="hidden" name="stelle" id="num_stelle" min="1" max="5" required>
                    </p>

                    <input type="submit" value="Invia recensione" id="rec_button">
                </form>

                <?php
                    //Procedura per aggiungere un commento che viene avviata dopo che l'utente ha compilato e inviato i campi del form
                    if(!empty($_POST)){
                        //Mi connetto al database
                        $db = pg_connect($connection_string) or die('Impossibile connetersi al database: ' . pg_last_error());

                        //Prendo i valori dei campi che dovrò inserire nella tabella recensioni del database
                        $username = $_SESSION['username'];
                        $propic = $_SESSION['propic'];
                        $recensione = pg_escape_literal($_POST['recensione']);
                        $stelle = $_POST['stelle'];
                        date_default_timezone_set('Europe/Rome');
                        $data = date('Y-m-d H:i:s');
                        $universo = "db";

                        //Verifico se il commento dell'utente è stato già scritto in precedenza dall'utente, in questo caso non verrà inserito.
                        //Per verificare ciò devp vedere se c'è una recensione con le stesse primary_key di quelle della recensione che l'utente inserire
                        $sql = "SELECT username, recensione FROM recensioni";
                        $verifica_rec = pg_query($db, $sql);

                        //Se la query da errore lo stampo
                        if(!$verifica_rec){
                            echo pg_last_error($db);
                        }else{
                            //Uso la variabile trovato per verificare se i campi inseriti che sono primary key(username e testo della recensione) corrispondono
                            //alle primary key di un recensione già presente nella table e quindi non è possibile inserire la nuova recensione
                            //con le stesse primary key
                            $trovato = false;

                            //Scorro la table e non appena vedo che la recensione che voglio inserire ha testo e username uguali a quelli di
                            //una recensione già presente nella table la variabile trovato diventa true e faccio break
                            while($row = pg_fetch_assoc($verifica_rec)){
                                if($row['username']==$username && $row['recensione']==$recensione){
                                    $trovato = true;
                                    break;
                                }
                            }

                            //Se trovato=false la recensione non è già presente dunque posso tranquillamente inserirla nella tabella delle recensioni
                            if($trovato == false){
                                $sql = "INSERT INTO recensioni(username, propic, recensione, stelle, data, universo)
                                VALUES($1, $2, $3, $4, $5, $6)";
                                $ret = pg_prepare($db,"InsertRecensioni", $sql);

                                if(!$ret){
                                    echo pg_last_error($db);
                                }else{
                                    $ret = pg_execute($db, "InsertRecensioni", array($username, $propic, $recensione, $stelle, $data, $universo));
                                }

                            }

                        }
                        //Chiudo la connessione
                        pg_close($db);
                    }

                ?>
            </div>
            <hr>

            <!--Sezione dove l'utente vede le recensioni degli altri utenti-->
            <div>
            <?php
                //Mi connetto al database
                $db = pg_connect($connection_string) or die('Impossibile connetersi al database: ' . pg_last_error());

                //Prendo le recensioni dalla tabella delle recensioni
                $sql = "SELECT * FROM recensioni";
                $recensioni = pg_query($db, $sql);

                //Se la query non va a buon fine stampo l'errore
                if(!$recensioni){
                    echo pg_last_error($db);

                }else{
                    //Scorro le righe della table e ogni volta che trovo una recensione che ha universo="Hp",dunque deve essere mostrata nella pagina di Harry
                    //Potter, creo un div con all'interno i valori della recensione che otteng mediante la funzione pg_fetch_result()
                    $count_row = 0;
                    while($row = pg_fetch_assoc($recensioni)){
                            if(pg_fetch_result($recensioni, $count_row, 'universo') == "db"){
                                ?>

                                <!--Contenitore recensione-->
                                <div class="recensione">
                                    <!--Contenitore con propic dell'utente che ha scritto la recensione-->
                                    <div class="propic_recensione">
                                        <img src="../login/<?php echo str_replace("'", "", pg_fetch_result($recensioni, $count_row, 'propic')); ?>">
                                    </div>

                                    <!--Contenitore con in alto username, stelle e data della recensione e sotto il testo della recensione-->
                                    <div class="text_recensione">
                                        <span class="username_rec">
                                            <?php
                                                //Levo gli apici all'inizio e alla fine dell'username
                                                $lunghezza = strlen(pg_fetch_result($recensioni, $count_row, 'username'));
                                                $rec = substr(pg_fetch_result($recensioni, $count_row, 'username'), 1, $lunghezza - 2);
                                                echo $rec;
                                            ?>
                                        </span>

                                        <span>
                                            <?php
                                                //Metto tante stelle quanto è il valore che si trova nella colonna stelle della recensione-->
                                                for($i = 0; $i < pg_fetch_result($recensioni, $count_row, 'stelle'); $i++){
                                            ?>
                                                <img src="immagini/star.png" alt="" class="star">
                                            <?php
                                                }
                                            ?>
                                        </span>

                                        <span class="data_rec">
                                            in data <?php echo pg_fetch_result($recensioni, $count_row, 'data'); ?>
                                        </span>

                                        <p>
                                            <?php
                                                //Levo gli apici all'inizio e alla fine della recensione
                                                $lunghezza = strlen(pg_fetch_result($recensioni, $count_row, 'recensione'));
                                                $rec = substr(pg_fetch_result($recensioni, $count_row, 'recensione'), 1, $lunghezza - 2);
                                                echo $rec;
                                            ?>
                                        </p>
                                    </div>
                                </div>

                                <?php
                            }
                            //Ogni volta che scorro una riga counter_row incrementa
                            $count_row++;
                        }

                    //Chiudo la connessione
                    pg_close($db);
                }
            ?>

            </div>

            <?php
            //Se l'utente non è loggato esce una stringa che indica che per poter vedere la sezione commenti è necessario effettuare l'accesso
            }else{
            ?>
                <p>Per poter inserire una recensione è necessario aver fatto l'accesso</p>
            <?php
            }
            ?>
        </div>

        </div>

      </div>


    </div>
    <script type="text/javascript">
      function nascondiLuoghi(event) {
        var luoghi = document.getElementsByClassName('luoghi');
          if (luoghi.length > 0) {
            for (var i = 0; i < luoghi.length; i++) {
              luoghi[i].style.display = 'none';
            }
          }


          //se clicco su namecc, compare la pagina approfondita di namecc
          if (event.target.id == "namecc") {
            var prenotazione1 =  document.getElementsByClassName('prenotazione1');
            if (prenotazione1.length > 0) {
              for (var i = 0; i < prenotazione1.length; i++) {
                prenotazione1[i].style.display = '';
              }
            }
          }

          //se clicco sulla stanza dello spirito e del tempo, compare la pagina approfondita della stanza dello spirito e del tempo
          if (event.target.id == "stanza") {
            var prenotazione2 =  document.getElementsByClassName('prenotazione2');
            if (prenotazione2.length > 0) {
              for (var i = 0; i < prenotazione2.length; i++) {
                prenotazione2[i].style.display = '';
              }
            }
          }

          //se clicco sul torneo tenkaichi, compare la pagina approfondita del torneo
          if (event.target.id == "torneo") {
            var prenotazione3 =  document.getElementsByClassName('prenotazione3');
            if (prenotazione3.length > 0) {
              for (var i = 0; i < prenotazione3.length; i++) {
                prenotazione3[i].style.display = '';
              }
            }

          }

        }

      function disabilitaFinestre(){

        var prenotazione1 =  document.getElementsByClassName('prenotazione1');
        if (prenotazione1.length > 0) {
          for (var i = 0; i < prenotazione1.length; i++) {
            prenotazione1[i].style.display = 'none';
          }
        }
        var prenotazione2 =  document.getElementsByClassName('prenotazione2');
        if (prenotazione2.length > 0) {
          for (var i = 0; i < prenotazione2.length; i++) {
            prenotazione2[i].style.display = 'none';
          }
        }
        var prenotazione3 =  document.getElementsByClassName('prenotazione3');
        if (prenotazione3.length > 0) {
          for (var i = 0; i < prenotazione3.length; i++) {
            prenotazione3[i].style.display = 'none';
          }
        }
      }

      function tornaIndietro(){
        disabilitaFinestre();

        var luoghi = document.getElementsByClassName('luoghi');
          if (luoghi.length > 0) {
            for (var i = 0; i < luoghi.length; i++) {
              luoghi[i].style.display = '';
            }
          }
      }

      // function inserisciPreferiti(event){
      //   event.target.style.display= "none";
      //
      // }


    </script>

    <script>
      const canvas = document.getElementById('animazione1');
      const ctx = canvas.getContext('2d');

      const image = new Image();
      image.src = 'immagini\\sfera_del_drago-removebg-preview.png';

      const velocita = 2; // Velocità dell'immagine
      const spostamento = 50; // quanto l'immagine si sposta
      let angolo = 3000; // Angolo iniziale

      function animazione_sfera() {
        // serve a eliminare l'immagine precedente che si crea all'animazione, altrimenti si creerebbero delle immagini sovrapposte
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        // Calcola la posizione dell'immagine in base al movimento
        const x = muoviAsseX(angolo, spostamento);
        const y = canvas.height / 2 - (image.height / 4) / 2;

        ctx.drawImage(image, x, y, image.width / 4, image.height / 4); // imposta le dimensioni dell'immagine

        // Aggiorna l'angolo per il prossimo frame
        angolo = angolo + velocita * 0.02;

        // serve effettivamente a animare l'immagine chiamando se stessa ricorsivamente
        requestAnimationFrame(animazione_sfera);
      }

      function muoviAsseX(angolo, spostamento) {
        return Math.sin(angolo) * spostamento + canvas.width / 4; // crea il movimento sull'asse x
      }

      // avvia le animazioni
      animazione_sfera();

      const canvas2 = document.getElementById('animazione2');
      const ctx2 = canvas2.getContext('2d');

      const image2 = new Image();
      image2.src = 'immagini\\sfera_del_drago-removebg-preview.png';

      let angolo2 = 3000; // Angolo iniziale per il secondo canvas

      function animazione_sfera2() {
        ctx2.clearRect(0, 0, canvas2.width, canvas2.height);
        const x2 = muoviAsseX(angolo2, spostamento);
        const y2 = canvas2.height / 2 - (image2.height / 4) / 2;
        ctx2.drawImage(image2, x2, y2, image2.width / 4, image2.height / 4);
        angolo2 = angolo2 + velocita * 0.02;
        requestAnimationFrame(animazione_sfera2);
      }

      animazione_sfera2(); // Avvia l'animazione per il secondo canvas

      //per il movimento verticale
      // function animazione_sfera2() {
      //   ctx2.clearRect(0, 0, canvas2.width, canvas2.height);
      //   const x2 = canvas2.width / 2 - (image2.width / 4) / 2;
      //   const y2 =  muoviAsseY(angolo2, spostamento);
      //   ctx2.drawImage(image2, x2, y2, image2.width / 4, image2.height / 4);
      //   angolo2 = angolo2 + velocita2 * 0.02;
      //   requestAnimationFrame(animazione_sfera2);
      // }
      //
      // function muoviAsseY(angolo, spostamento) {
      //   return Math.sin(angolo) * spostamento + canvas.height / 2; //parto da più in basso (con il diviso 2) altrimenti l'immagine viene tagliata
      // }
    </script>

    <!-- FOOTER-------------------------------------------------------------------------------------------------------------------------------- -->
    <footer>
        <?php include '../footer/footer.php';?>
    </footer>
  </body>
</html>

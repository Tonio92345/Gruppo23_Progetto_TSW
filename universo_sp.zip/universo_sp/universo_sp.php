<?php require "../logindb.php";
session_start();
?>

<!DOCTYPE html>
<html lang="<?php echo $lan;?>">
<head>
    <?php include '../language/language.php'; ?>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Universo Harry Potter</title>
    <base href=""/>
    <link rel="icon" href="../header/img/C.png" type="image/X-icon"/>
    <link rel="stylesheet" type="text/css" href="style.css">
    <meta name="author" content="Gruppo21"/>
    <meta name="keywords" content="Spongebob, bolle di sapone, krabby patty, krusty krab, Patrick Stella"/>
    <meta name="description" content="Pagina riguardante l'universo di Spongebob che presenta quattro mete: Bikkini Bottom, Glove World, Krusty Krab, Via della Conchiglia"/>
</head>
<body>


<header>
  <!-- Ho modificato, prima era solo include -->
  <?php
    include('../header/header.php');
  ?>
</header>
<?php include("funzioniScript.php"); ?>

<!-- Sezione Autore -->
<section id="sezioneAutore" class="sezione">
  <img src="ImmaginiSP/author_spongebob.png" alt="Spongebob Squarepants" height="150" width="100" class="BoxShadow">
  <div class="descrizioneAutore">
      <?php echo $dizionario['descrizioneAutoreSP']; ?>
  </div>
  <img src="ImmaginiSP/patrick_stella.jpg" alt="Patrick Stella" height="150" width="100" class="BoxShadow">
</section>

<section class="sezione">
  <div id="destinazioniPopolariID">
    <h2 class="destinazioniPopolari"><?php echo $dizionario['destinazioniPopolariSP']; ?></h2>
  <div class="sezioneDestinazioni">
    <div class="descrizione" onclick="sceltaDestinazione(this, 'bikiniBottom');">
      <img src="ImmaginiSP/bikini_bottom.jpg" alt="Bikini Bottom">
      <h3 class="destinazione">Bikini Bottom</h3>
      <br>
      <?php echo $dizionario['destinazioneBBSP']; ?>
    </div>
    <div class="descrizione" onclick="sceltaDestinazione(this, 'krustyKrab');">
      <img src="ImmaginiSP/krusty_krab.jpg" alt="Krusty Krab">
      <h3 class="destinazione">Krusy Krab</h3>
      <br>
      <?php echo $dizionario['destinazioneKKSP']; ?>
    </div>
    <div class="descrizione" onclick="sceltaDestinazione(this, 'gloveWorld');">
      <img src="ImmaginiSP/glove_world.jpg" alt="Glove World">
      <h3 class="destinazione">Glove World</h3>
      <br>
      <?php echo $dizionario['destinazioneGWSP']; ?>
    </div>
    <div class="descrizione" onclick="sceltaDestinazione(this, 'viaConchiglia');">
      <img src="ImmaginiSP/via_conchiglia.jpg" alt="Via Conchiglia">
      <h3 class="destinazione">Via Conchiglia</h3>
      <br>
      <?php echo $dizionario['destinazioneVCSP']; ?>
    </div>
    </div>
  </div>
  <!-- Ho modificato, prima era solo include -->
  <?php include('dettagli.php');?>
</section>


<!-- Sezione Commenti -->
<?php if($_SESSION['logged']){
?>
<article class="sezione" >
  <h2><?php echo $dizionario['sezioneRecensioniSP']; ?></h2>
  <div class="sezioneCommenti">
  <div class="sottoCommenti">
  <form  action="<?php echo $_SERVER['PHP_SELF']?>?lan=<?php echo $lan; ?>" method="post">
    <textarea name="recensione" rows="8" cols="50" id="textareaAggiungiRecensione" hidden onchange="abilitaInvio(this);" maxlength="500"></textarea>
    
  <div id="sezioneStelle">
    <img id="stella1" onclick="background_stelle(1)" src="ImmaginiSP/not_selected_star.png" alt="stellina_recensioni1" height="30cm" width="30cm">
    <img id="stella2" onclick="background_stelle(2)" src="ImmaginiSP/not_selected_star.png" alt="stellina_recensioni2" height="30cm" width="30cm">
    <img id="stella3" onclick="background_stelle(3)" src="ImmaginiSP/not_selected_star.png" alt="stellina_recensioni3" height="30cm" width="30cm">
    <img id="stella4" onclick="background_stelle(4)" src="ImmaginiSP/not_selected_star.png" alt="stellina_recensioni4" height="30cm" width="30cm">
    <img id="stella5" onclick="background_stelle(5)" src="ImmaginiSP/not_selected_star.png" alt="stellina_recensioni5" height="30cm" width="30cm">
    <input type="hidden" name="stelle" id="num_stelle" min="1" max="5" required>
  </div>

  <p><?php echo $dizionario['aggiungiCommentoSP']; ?>: <button type="button" id="bottoneAggiungiCommento" onclick="mostraCommento(this);"><?php echo $dizionario['scriviCommentoSP']; ?></button><input type="submit" id="bottoneInviaCommento" hidden disabled onclick="inviaCommento(this);" value="<?php echo $dizionario['inviaCommentoSP']; ?>"></p>
  </form>
    
  <p id="ringraziamentoCommento" hidden><?php echo $dizionario['ringraziamentoRecensioneSP'] ?></p>
  <img src="ImmaginiSP/spongebobRainbow.jpg" alt="Spongebob Rainbow" id="spongebobRainbow" hidden>
</div>

</div>

<?php
//Procedura per aggiungere un commento che viene avviata dopo che l'utente ha compilato e inviato i campi del form
if(!empty($_POST)){
    //Mi connetto al database
    $db = pg_connect($connection_string) or die('Impossibile connetersi al database: ' . pg_last_error());

    //Prendo i valori dei campi che dovrò inserire nella tabella recensioni del database
    $username = $_SESSION['username'];
    $propic = $_SESSION['propic'];
    $recensione = pg_escape_literal($_POST['recensione']);
    $stelle = $_POST['stelle'];
    date_default_timezone_set('Europe/Rome');
    $data = date('Y-m-d H:i:s');
    $universo = "Sp";

    //Verifico se il commento dell'utente è stato già scritto in precedenza dall'utente, in questo caso non verrà inserito.
    //Per verificare ciò devp vedere se c'è una recensione con le stesse primary_key di quelle della recensione che l'utente inserire
    $sql = "SELECT username, recensione, universo FROM recensioni";
    $verifica_rec = pg_query($db, $sql);

    //Se la query da errore lo stampo
    if(!$verifica_rec){
        echo pg_last_error($db);
    }else{
        //Uso la variabile trovato per verificare se i campi inseriti che sono primary key(username e testo della recensione) corrispondono
        //alle primary key di un recensione già presente nella table e quindi non è possibile inserire la nuova recensione
        //con le stesse primary key
        $trovato = false;

        //Scorro la table e non appena vedo che la recensione che voglio inserire ha testo e username uguali a quelli di 
        //una recensione già presente nella table la variabile trovato diventa true e faccio break
        while($row = pg_fetch_assoc($verifica_rec)){
            if($row['username'] == $username && $row['recensione'] == $recensione && $row['universo'] == $universo){
                $trovato = true;
                break;
            }
        }

        //Se trovato=false la recensione non è già presente dunque posso tranquillamente inserirla nella tabella delle recensioni
        if($trovato == false){
            $sql = "INSERT INTO recensioni(username, propic, recensione, stelle, data, universo)
            VALUES($1, $2, $3, $4, $5, $6)";
            $ret = pg_prepare($db,"InsertRecensioni", $sql);
            
            if(!$ret){
                echo pg_last_error($db);
            }else{
                $ret = pg_execute($db, "InsertRecensioni", array($username, $propic, $recensione, $stelle, $data, $universo));
            }
            
        }
        
    }
    //Chiudo la connessione
    pg_close($db);
}

  ?>
    <!--Sezione dove l'utente vede le recensioni degli altri utenti-->
    <div>
        <?php
            //Mi connetto al database
            $db = pg_connect($connection_string) or die('Impossibile connetersi al database: ' . pg_last_error());
            
            //Prendo le recensioni dalla tabella delle recensioni
            $sql = "SELECT * FROM recensioni";
            $recensioni = pg_query($db, $sql);
            
            //Se la query non va a buon fine stampo l'errore
            if(!$recensioni){
                echo pg_last_error($db);
            
            }else{
              //Scorro le righe della table e ogni volta che trovo una recensione che ha universo="Hp",dunque deve essere mostrata nella pagina di Harry
              //Potter, creo un div con all'interno i valori della recensione che otteng mediante la funzione pg_fetch_result()
              $count_row = 0;
              while($row = pg_fetch_assoc($recensioni)){
                if(pg_fetch_result($recensioni, $count_row, 'universo') == "Sp"){
                    ?>

                  <!--Contenitore recensione-->
                  <div class="recensione">
                      <!--Contenitore con propic dell'utente che ha scritto la recensione-->
                      <div class="propic_recensione">
                          <img src="../login/<?php echo str_replace("'", "", pg_fetch_result($recensioni, $count_row, 'propic')); ?>">
                      </div>

                  <!--Contenitore con in alto username, stelle e data della recensione e sotto il testo della recensione-->
                  <div class="text_recensione">
                      <span class="username_rec">
                          <?php
                              //Levo gli apici all'inizio e alla fine dell'username
                              $lunghezza = strlen(pg_fetch_result($recensioni, $count_row, 'username'));
                              $rec = substr(pg_fetch_result($recensioni, $count_row, 'username'), 1, $lunghezza - 2);
                              echo $rec;
                          ?>
                      </span>
                  
                      <span>
                          <?php
                              //Metto tante stelle quanto è il valore che si trova nella colonna stelle della recensione-->
                              for($i = 0; $i < pg_fetch_result($recensioni, $count_row, 'stelle'); $i++){
                          ?>
                              <img src="immaginiSP/star.png" alt="" class="star">
                          <?php
                              }
                          ?>
                      </span>
                      
                      <span class="data_rec">
                          <?php echo $dizionario['data_hp']; ?><?php echo pg_fetch_result($recensioni, $count_row, 'data'); ?>
                      </span>

                      <p>
                          <?php
                              //Levo gli apici all'inizio e alla fine della recensione
                              $lunghezza = strlen(pg_fetch_result($recensioni, $count_row, 'recensione'));
                              $rec = substr(pg_fetch_result($recensioni, $count_row, 'recensione'), 1, $lunghezza - 2);
                              echo $rec;
                          ?>
                      </p>
                  </div>
              </div>
                            
                            <?php
                        }
                        //Ogni volta che scorro una riga counter_row incrementa
                        $count_row++;
                    }
                
                //Chiudo la connessione
                pg_close($db);
            }
        ?>
        
        </div>

</article>
<?php
}else{

?>
<article class="sezione">
  <div class="">
    <?php echo $dizionario['accessoNecessarioSP'];?>
  </div>
</article>
<?php
}
 ?>

  <!-- FOOTER-------------------------------------------------------------------------------------------------------------------------------- -->
  <footer>
        <?php include '../footer/footer.php';?>
  </footer>

</body>
</html>

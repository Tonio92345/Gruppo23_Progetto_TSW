<script type="text/javascript">
	/* Funzione che passa da index.php a dettagli.php modificndo il suo contenuto in base alla destinazione selezionata (accade in idnex.php)*/
	function sceltaDestinazione(evento, nomeLuogo){
    var sezioneAutore = document.getElementById("sezioneAutore");
    var destinazioni = document.getElementById('destinazioniPopolariID');
    var dettagli = document.getElementById('corpoDettagliID');
    destinazioni.hidden = true;
    dettagli.hidden = false;
    if(nomeLuogo == "bikiniBottom"){
      var luogo = document.querySelector(".nomeLuogoDettagli");
      luogo.textContent = "Bikini Bottom";
      var breveDescrizioneLuogo = document.querySelector(".breveDescrizioneDettagli");
      breveDescrizioneLuogo.textContent = "<?php echo $dizionario['breveDescrizioneDettagliBBSP'];?>";
      var descrizione = document.querySelector(".descrizioneDettagli");
      descrizione.textContent = "<?php echo $dizionario['descrizioneProfondaBBSP'];?>";
      var img = document.getElementById("immagine1");
      img.src = "ImmaginiSP/BikiniBottomImg/bikiniBottomImg1.jpg";
      var img = document.getElementById("immagine2");
      img.src = "ImmaginiSP/BikiniBottomImg/bikiniBottomImg2.jpg";
      var img = document.getElementById("immagine3");
      img.src = "ImmaginiSP/BikiniBottomImg/bikiniBottomImg3.png";
      var img = document.getElementById("immagine4");
      img.src = "ImmaginiSP/BikiniBottomImg/bikiniBottomImg4.jpg";
      var img = document.getElementById("immagine5");
      img.src = "ImmaginiSP/BikiniBottomImg/bikiniBottomImg5.jpg";
      var img = document.getElementById("immagine6");
      img.src = "ImmaginiSP/BikiniBottomImg/bikiniBottomImg6.jpg";
	  	var prenotazione = document.getElementById("prenotazionePrenotazione");
	  	prenotazione.textContent = "<?php echo $dizionario['prenotazioneSP'];?>:";
	  	var nome = document.getElementById("nomePrenotazione");
	  	nome.textContent = "<?php echo $dizionario['nomeSP'];?>:";
	  	var dataArrivo = document.getElementById("dataArrivoPrenotazione");
	  	dataArrivo.textContent = "<?php echo $dizionario['dataArrivoSP'];?>:";
	  	var dataPartenza = document.getElementById("dataPartenzaPrenotazione");
	  	dataPartenza.textContent = "<?php echo $dizionario['dataPartenzaSP'];?>:";
	  	var prenota = document.getElementById("prenotaPrenotazione");
	  	prenota.value = "<?php echo $dizionario['prenotaSP'];?>"
	  	var bottone = document.getElementById("bottonePrenotazione");
	  	bottone.textContent = "<?php echo $dizionario['bottoneIndietroSP'];?>";
			var formDettagli = document.getElementById("formDettagli");
			formDettagli.action = "mailto:multiversus.tsw21@gmail.com?subject=voglio_prenotarmi_a_bikini_bottom";
    }
    if(nomeLuogo == "krustyKrab"){
      var luogo2 = document.querySelector(".nomeLuogoDettagli");
      luogo2.textContent = "Krusty Krab";
      var breveDescrizioneLuogo2 = document.querySelector(".breveDescrizioneDettagli");
      breveDescrizioneLuogo2.textContent = "<?php echo $dizionario['breveDescrizioneDettagliKKSP'];?>";
      var descrizione2 = document.querySelector(".descrizioneDettagli");
      descrizione2.textContent = "<?php echo $dizionario['descrizioneProfondaKKSP'];?>";
      var img2 = document.getElementById("immagine1");
      img2.src = "ImmaginiSP/KrustyKrabImg/krustyKrabImg1.jpg";
      var img2 = document.getElementById("immagine2");
      img2.src = "ImmaginiSP/KrustyKrabImg/krustyKrabImg2.jpg";
      var img2 = document.getElementById("immagine3");
      img2.src = "ImmaginiSP/KrustyKrabImg/krustyKrabImg3.png";
      var img2 = document.getElementById("immagine4");
      img2.src = "ImmaginiSP/KrustyKrabImg/krustyKrabImg4.jpg";
      var img2 = document.getElementById("immagine5");
      img2.src = "ImmaginiSP/KrustyKrabImg/krustyKrabImg5.jpg";
      var img2 = document.getElementById("immagine6");
      img2.src = "ImmaginiSP/KrustyKrabImg/krustyKrabImg6.png";
		  var prenotazione2 = document.getElementById("prenotazionePrenotazione");
		  prenotazione2.textContent = "<?php echo $dizionario['prenotazioneSP'];?>:";
		  var nome2 = document.getElementById("nomePrenotazione");
		  nome2.textContent = "<?php echo $dizionario['nomeSP'];?>:";
		  var dataArrivo2 = document.getElementById("dataArrivoPrenotazione");
		  dataArrivo2.textContent = "<?php echo $dizionario['dataArrivoSP'];?>:";
		  var dataPartenza2 = document.getElementById("dataPartenzaPrenotazione");
		  dataPartenza2.textContent = "<?php echo $dizionario['dataPartenzaSP'];?>:";
		  var prenota2 = document.getElementById("prenotaPrenotazione");
		  prenota2.value = "<?php echo $dizionario['prenotaSP'];?>";
		  var bottone2 = document.getElementById("bottonePrenotazione");
		  bottone2.textContent = "<?php echo $dizionario['bottoneIndietroSP'];?>";
			var formDettagli2 = document.getElementById("formDettagli");
			formDettagli2.action = "mailto:multiversus.tsw21@gmail.com?subject=voglio_prenotarmi_a_krusty_krab";

    }
    if(nomeLuogo == "gloveWorld"){
      var luogo3 = document.querySelector(".nomeLuogoDettagli");
      luogo3.textContent = "Glove World";
      var breveDescrizioneLuogo3 = document.querySelector(".breveDescrizioneDettagli");
      breveDescrizioneLuogo3.textContent = "<?php echo $dizionario['breveDescrizioneDettagliGWSP'];?>";
      var descrizione3 = document.querySelector(".descrizioneDettagli");
      descrizione3.textContent = "<?php echo $dizionario['descrizioneProfondaGWSP'];?>";
      var img3 = document.getElementById("immagine1");
      img3.src = "ImmaginiSP/GloveWorldImg/gloveWorldImg1.png";
      var img3 = document.getElementById("immagine2");
      img3.src = "ImmaginiSP/GloveWorldImg/gloveWorldImg6.png";
      var img3 = document.getElementById("immagine3");
      img3.src = "ImmaginiSP/GloveWorldImg/gloveWorldImg3.png";
      var img3 = document.getElementById("immagine4");
      img3.src = "ImmaginiSP/GloveWorldImg/gloveWorldImg4.png";
      var img3 = document.getElementById("immagine5");
      img3.src = "ImmaginiSP/GloveWorldImg/gloveWorldImg5.png";
      var img3 = document.getElementById("immagine6");
      img3.src = "ImmaginiSP/GloveWorldImg/gloveWorldImg2.jpg";
		  var prenotazione3 = document.getElementById("prenotazionePrenotazione");
		  prenotazione3.textContent = "<?php echo $dizionario['prenotazioneSP'];?>:";
		  var nome3 = document.getElementById("nomePrenotazione");
		  nome3.textContent = "<?php echo $dizionario['nomeSP'];?>:";
		  var dataArrivo3 = document.getElementById("dataArrivoPrenotazione");
		  dataArrivo3.textContent = "<?php echo $dizionario['dataArrivoSP'];?>:";
		  var dataPartenza3 = document.getElementById("dataPartenzaPrenotazione");
		  dataPartenza3.textContent = "<?php echo $dizionario['dataPartenzaSP'];?>:";
		  var prenota3 = document.getElementById("prenotaPrenotazione");
		  prenota3.value = "<?php echo $dizionario['prenotaSP'];?>";
		  var bottone3 = document.getElementById("bottonePrenotazione");
		  bottone3.textContent = "<?php echo $dizionario['bottoneIndietroSP'];?>";
			var formDettagli3 = document.getElementById("formDettagli");
			formDettagli3.action = "mailto:multiversus.tsw21@gmail.com?subject=voglio_prenotarmi_a_glove_world";

    }
    if(nomeLuogo == "viaConchiglia"){
      var luogo4 = document.querySelector(".nomeLuogoDettagli");
      luogo4.textContent = "Via Conchiglia";
      var breveDescrizioneLuogo4 = document.querySelector(".breveDescrizioneDettagli");
      breveDescrizioneLuogo4.textContent = "<?php echo $dizionario['breveDescrizioneDettagliVCSP'];?>";
      var descrizione4 = document.querySelector(".descrizioneDettagli");
      descrizione4.textContent = "<?php echo $dizionario['descrizioneProfondaVCSP'];?>";
      var img4 = document.getElementById("immagine1");
      img4.src = "ImmaginiSP/ViaConchigliaImg/viaConchigliaImg6.png";
      var img4 = document.getElementById("immagine2");
      img4.src = "ImmaginiSP/ViaConchigliaImg/viaConchigliaImg1.jpg";
      var img4 = document.getElementById("immagine3");
      img4.src = "ImmaginiSP/ViaConchigliaImg/viaConchigliaImg4.png";
      var img4 = document.getElementById("immagine4");
      img4.src = "ImmaginiSP/ViaConchigliaImg/viaConchigliaImg3.jpg";
      var img4 = document.getElementById("immagine5");
      img4.src = "ImmaginiSP/ViaConchigliaImg/viaConchigliaImg5.jpg";
      var img4 = document.getElementById("immagine6");
      img4.src = "ImmaginiSP/ViaConchigliaImg/viaConchigliaImg2.jpg";
		  var prenotazione4 = document.getElementById("prenotazionePrenotazione");
		  prenotazione4.textContent = "<?php echo $dizionario['prenotazioneSP'];?>:";
		  var nome4 = document.getElementById("nomePrenotazione");
		  nome4.textContent = "<?php echo $dizionario['nomeSP'];?>:";
		  var dataArrivo4 = document.getElementById("dataArrivoPrenotazione");
		  dataArrivo4.textContent = "<?php echo $dizionario['dataArrivoSP'];?>:";
		  var dataPartenza4 = document.getElementById("dataPartenzaPrenotazione");
		  dataPartenza4.textContent = "<?php echo $dizionario['dataPartenzaSP'];?>:";
		  var prenota4 = document.getElementById("prenotaPrenotazione");
		  prenota4.value = "<?php echo $dizionario['prenotaSP'];?>";
		  var bottone4 = document.getElementById("bottonePrenotazione");
		  bottone4.textContent = "<?php echo $dizionario['bottoneIndietroSP'];?>";
			var formDettagli4 = document.getElementById("formDettagli");
			formDettagli4.action = "mailto:multiversus.tsw21@gmail.com?subject=voglio_prenotarmi_a_via_della_conchiglia";
    }

  }

	/* funzione per passare da dettagli.php a index.php (accade in dettagli.php)*/
  function tornaIndietro(evento){
    let destinazioni = document.getElementById('destinazioniPopolariID');
    let dettagli = document.getElementById('corpoDettagliID');
    destinazioni.hidden = false;
    dettagli.hidden = true;
  }

	/* funzioni successive per la gestione di Recensioni & Commenti (accade in index.php)*/
  function mostraCommento(evento){
    let bottoneInviaCommento = document.getElementById("bottoneInviaCommento");
    let textareaAggiungiRecensione = document.getElementById("textareaAggiungiRecensione");
    let ringraziamentoCommento = document.getElementById("ringraziamentoCommento");
		let sezioneStelle = document.getElementById("sezioneStelle");
		let spongebobRainbow = document.getElementById("spongebobRainbow");
		spongebobRainbow.hidden = true;
		sezioneStelle.hidden = false;
    ringraziamentoCommento.hidden = true;
    textareaAggiungiRecensione.value = "";
    evento.hidden = true;
    bottoneInviaCommento.hidden = false;
    textareaAggiungiRecensione.hidden = false;
    bottoneInviaCommento.disabled = true;
  }

  function abilitaInvio(evento){
    if(evento.value != ""){
      let bottoneInviaCommento = document.getElementById("bottoneInviaCommento");
      bottoneInviaCommento.disabled = false;
    }
    else{
      bottoneInviaCommento.disabled = true;
    }
  }

  function inviaCommento(evento){
    let textareaAggiungiRecensione = document.getElementById("textareaAggiungiRecensione");
    textareaAggiungiRecensione.hidden = true;
    let bottoneAggiungiCommento = document.getElementById("bottoneAggiungiCommento");
    evento.hidden = true;
    let ringraziamentoCommento = document.getElementById("ringraziamentoCommento");
		let sezioneStelel = document.getElementById("sezioneStelle");
		let spongebobRainbow = document.getElementById("spongebobRainbow");
		spongebobRainbow.hidden = false;
		sezioneStelle.hidden = true;
    ringraziamentoCommento.hidden = false;
    bottoneAggiungiCommento.hidden = false;
  }
  //Funzione che serve per far inserire all'utente un numero di stelle nella recensione
  //e inserire il numero di stelle nel database
  //Come parametri gli vien passato il num di stelle che dipende dalla stella che clicco
  function background_stelle(x){
    //Array dove prendo le 5 img stelle 
    var stelle = new Array();
    stelle[0] = document.querySelector("#stella1");
    stelle[1] = document.querySelector("#stella2");
    stelle[2] = document.querySelector("#stella3");
    stelle[3] = document.querySelector("#stella4");
    stelle[4] = document.querySelector("#stella5");
    
    //Prendo il numero di stelle e lo metto nell'input nascosto che poi mando col form
    //per inserire una recensione
    var num_stelle = document.getElementById('num_stelle');
    num_stelle.value = x;

    //Prendo il bottone per inviare la recensione
    var btn = document.getElementById('bottoneInviaCommento');

    //Coloro le stelle in base a quella che clicco e quando le stelle diventano gialle abilito il
    //bottone per inserire la recensione
    if(stelle[x-1].style.backgroundColor === 'transparent'){
      while(x !== 0){
        stelle[x-1].style.backgroundColor = 'yellow';
        x--;
      }
      btn.disabled = false;
      btn.style.backgroundColor = "";
      btn.style.color = "";

    }
    //Funzione che fa tornare le stelle trasparenti quando clicco una stella colorata di giallo
    //Quando poi le stelle diventano trasparenti torno a disabilitare il bottone
    else{
      x = stelle.length;
      while(x !== 0){
        stelle[x-1].style.backgroundColor = 'transparent';
        x--;
      }
      btn.disabled = true;
      btn.style.backgroundColor = 'grey';
      btn.style.color = 'white';
      }
  }

</script>

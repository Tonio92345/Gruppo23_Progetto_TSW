<div class="" id="corpoDettagliID" hidden>
    <div class="corpoDettagli">
      <div class="dettagliDestra">
        <h3 class="nomeLuogoDettagli">Nome Luogo</h3>
        <div class="breveDescrizioneDettagli">
          <div>Breve Descrizione Luogo</div>
        </div>
      </div>
      <div class="dettagliSinistra">
        <img id="immagine1" src="" alt="Immagine 1" height="auto" width="300">
        <img id="immagine2" src="" alt="Immagine 2" height="auto" width="300">
        <img id="immagine3" src="" alt="Immagine 3" height="auto" width="300">
        <img id="immagine4" src="" alt="Immagine 4" height="auto" width="200">
        <img id="immagine5"src="" alt="Immagine 5" height="auto" width="200">
        <img id="immagine6" src="" alt="Immagine 6" height="auto" width="200">
      </div>
    </div>

    <div class="profondaDettagli">
      <div class="descrizioneDettagli">
            Descrizione più profonda.
      </div>
      <div class="contenutoImmagine">
        <div class="biglietto">
          <h3 id="prenotazionePrenotazione">Prenotazione</h3>
            <?php if($_SESSION['logged']){
            ?>
            <div class="formPersonalizzato">
              <form id="formDettagli" method="post">
              <label for="nome" id="nomePrenotazione">Nome:</label>
              <input type="text" id="nome" name="nome" required><br><br>

              <label for="email">Email:</label>
              <input type="email" id="email" name="email" required><br><br>

              <label for="data_arrivo" id="dataArrivoPrenotazione">Data di arrivo:</label>
              <input type="date" id="data_arrivo" name="data_arrivo" required><br><br>

              <label for="data_partenza" id="dataPartenzaPrenotazione">Data di partenza:</label>
              <input type="date" id="data_partenza" name="data_partenza" required>
  			      <br/>
  			      <br/>

              <input type="submit" id="prenotaPrenotazione"/>
            </form>
            </div>
          <?php }else{?>
            <div class="">
              <?php echo $dizionario['accessoNecessarioSP'];?>
            </div>


            <?php
            }
            ?>

        </div>
      </div>
    </div>
    <div class="divBottone">
      <button class="spongebobButton" onclick="tornaIndietro(this);" id="bottonePrenotazione">Torna Indietro</button>
    </div>
  </div>

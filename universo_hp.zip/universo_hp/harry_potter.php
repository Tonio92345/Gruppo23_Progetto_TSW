
<?php
    require_once "../logindb.php";

    //Do inizio alla sessione che mi servirà per la variabile $_SESSION['logged']
    session_start();
?>
<!DOCTYPE html>
<html lang="<?php echo $lan;?>">
<head>
    <?php include '../language/language.php'; ?>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Universo Harry Potter</title>
    <base href=""/>
    <link rel="icon" href="../header/img/C.png" type="image/X-icon"/>
    <link rel="stylesheet" type="text/css" href="stili_hp.css">
    <meta name="author" content="Gruppo21"/>
    <meta name="keywords" content="harry potter, fantasy, bacchetta, magia, hogwarts"/>
    <meta name="description" content="Pagina riguardante l'universo di Harry Potter che presenta tre mete: Hogwarts, Hogsmade, Diagon Alley"/>

    <script type="text/javascript" >
        //Funzione che nasconde le parti complete dei luoghi e mette gli eventi agli elementi
        function assegna_eventi(){
            var elementi_nascosti = document.getElementsByClassName('parte_nascosta');
            for(var i=0; i<elementi_nascosti.length; i++){
                elementi_nascosti[i].style.display = "none";
            }

            var espandi_luogo = document.getElementsByClassName('img_luogo');
            for(var i=0; i<espandi_luogo.length; i++){
                espandi_luogo[i].addEventListener("click", espandi);
                espandi_luogo[i].style.cursor = "pointer";
            }

            var riduci_luogo = document.getElementsByClassName('goBackButton');
            for(var i=0; i<riduci_luogo.length; i++){
                riduci_luogo[i].addEventListener("click", riduci);
            }

            var bottone_espandi = document.getElementsByClassName('expandButton');
            for(var i=0; i<bottone_espandi.length; i++){
                bottone_espandi[i].addEventListener("click", espandi);
            }
            
            var btn = document.getElementById('rec_button');
            btn.disabled = true;
            btn.style.backgroundColor = 'grey';
            btn.style.color = 'white';
        }

        //Funzione che quando clicco sull'immagine del luogo nasconde la parte introduttiva del luogo e 
        //ne mostra la scheda completa
        function espandi(event){
            var elem_id = event.target.id;
            if(elem_id == "hogwarts_img" || elem_id == "expandHogwarts"){
                var elem_hidden = document.getElementById('hogwarts_completo');
                elem_hidden.style.display = "";
                var elem_shown = document.getElementById('hogwarts');
                elem_shown.style.display = "none";
            }

            if(elem_id == "hogsmade_img" || elem_id == "expandHogsmade"){
                var elem_hidden = document.getElementById('hogsmade_completo');
                elem_hidden.style.display = "";
                var elem_shown = document.getElementById('hogsmade');
                elem_shown.style.display = "none";
            }
            if(elem_id == "diagonAlley_img" || elem_id == "expandDiagonAlley"){
                var elem_hidden = document.getElementById('diagonAlley_completo');
                elem_hidden.style.display = "";
                var elem_shown = document.getElementById('diagonAlley');
                elem_shown.style.display = "none";
            }
        }

        //Funzione che quando clicco sul bottone "Torna indietro"del luogo nasconde la scheda
        //completa del luogo e ne mostra la parte introduttiva
        function riduci(event){
            var id = event.target.id;
            if(id == "goBackHogwarts"){
                var elem_hidden = document.getElementById('hogwarts');
                elem_hidden.style.display = "";
                var elem_shown = document.getElementById('hogwarts_completo');
                elem_shown.style.display = "none";
            }
            if(id == "goBackHogsmade"){
                var elem_hidden = document.getElementById('hogsmade');
                elem_hidden.style.display = "";
                var elem_shown = document.getElementById('hogsmade_completo');
                elem_shown.style.display = "none";
            }
            if(id == "goBackDiagonAlley"){
                var elem_hidden = document.getElementById('diagonAlley');
                elem_hidden.style.display = "";
                var elem_shown = document.getElementById('diagonAlley_completo');
                elem_shown.style.display = "none";
            }
        }

        //Funzione che serve per far inserire all'utente un numero di stelle nella recensione
        //e inserire il numero di stelle nel database
        //Come parametri gli vien passato il num di stelle che dipende dalla stella che clicco
        function background_stelle(x){
            //Array dove prendo le 5 img stelle 
            var stelle = new Array();
            stelle[0] = document.querySelector("#stella1");
            stelle[1] = document.querySelector("#stella2");
            stelle[2] = document.querySelector("#stella3");
            stelle[3] = document.querySelector("#stella4");
            stelle[4] = document.querySelector("#stella5");
            
            //Prendo il numero di stelle e lo metto nell'input nascosto che poi mando col form
            //per inserire una recensione
            var num_stelle = document.getElementById('num_stelle');
            num_stelle.value = x;

            //Prendo il bottone per inviare la recensione
            var btn = document.getElementById('rec_button');

            //Coloro le stelle in base a quella che clicco e quando le stelle diventano gialle abilito il
            //bottone per inserire la recensione
            if(stelle[x-1].style.backgroundColor === 'transparent'){
            while(x !== 0){
                stelle[x-1].style.backgroundColor = 'yellow';
                x--;
            }
            btn.disabled = false;
            btn.style.backgroundColor = "";
            btn.style.color = "";

            }
            //Funzione che fa tornare le stelle trasparenti quando clicco una stella colorata di giallo
            //Quando poi le stelle diventano trasparenti torno a disabilitare il bottone
            else{
            x = stelle.length;
            while(x !== 0){
                stelle[x-1].style.backgroundColor = 'transparent';
                x--;
            }
            btn.disabled = true;
            btn.style.backgroundColor = 'grey';
            btn.style.color = 'white';
            }
        }
        </script>
    </head>
    
    <body onload="assegna_eventi()">
    <header>
        <?php
            include '../header/header.php';
        ?>
    </header>
        <!--Contenitore della descrizione iniziale-->
        <div id="universo">
            <!--Contenitore con animazione canvas-->
            <div class="animazione">
                <div id="harryAnimation_container">
                    <canvas id="harryAnimation">
                        <?php echo $dizionario['animazione_non_supportata_hp']; ?>
                    </canvas>
                </div>

                <div id="boccinoAnimation_container">
                    <canvas id="boccinoAnimation">
                        <?php echo $dizionario['animazione_non_supportata_hp']; ?>
                    </canvas>
                </div>
            </div>
            
            <!--Contenitore con fumetto narratore-->
            <div class="descr_universo">                
                <div id="container_logo">
                    <img src="img_sito/logoHarryPotter_white.png" alt=""> 
                </div>

                <p>
                    <?php echo $dizionario['descrizione_iniziale_hp']; ?>   
                </p>
            </div>
            
            <!--Img narratore-->
            <div class="img_universo">
                <img src="img_sito/narratore.png" alt="">
            </div>
                 
        </div>

        <!--Contenitore con i luoghi presenti-->
        <div id="luoghi_presenti">

            <!--Container Hogwarts-->
            <section class="container_luogo">
                
                <!--Parte mostrata di Hogwarts-->
                <div id="hogwarts">
                    <h2 class="title_luogo">Hogwarts</h2>
                    <div class="luogo">
                        <img src="Hogwarts_img/Hogwarts.jpg" alt="" class="img_luogo" id="hogwarts_img">
                        <p class="descr_luogo">
                            <?php echo $dizionario['descrizione_breve_hogwarts_hp']; ?>
                        </p>
                    </div>
                    
                    <input type="button" value="<?php echo $dizionario['tasto_espandi_hp']; ?>" class="expandButton" id="expandHogwarts">
                </div>
                
                <!--Parte nascosta di Hogwarts che viene mostrata cliccando il tasto "Vedi nel dettaglio" o l'immagine del luogo-->
                <div class="parte_nascosta" id="hogwarts_completo">
                    <div class="scheda_luogo">
                        <div class="introduzione_luogo">
                            <h1>HOGWARTS</h1>
                            <p>
                                <?php echo $dizionario['posizione_hogwarts_hp']; ?> 
                            </p>
                            <p> 
                                <?php echo $dizionario['introduzione_hogwarts_hp']; ?>  
                            </p>
                        </div>

                        <div class="collage">
                            <img src="Hogwarts_img/Hogwarts_giorno.jpg" alt="Hogwarts di giorno" class="collage_img">
                            <img src="Hogwarts_img/SalaGrande.jpg" alt="Sala Grande di Hogwarts" class="collage_img">
                            <img src="Hogwarts_img/campo_quidditch.jpg" alt="Campo da quidditch di Hogwarts" class="collage_img">
                            <img src="Hogwarts_img/torre_orologio.jpg" alt="Torre dell'orologio di Hogwarts" class="collage_img">
                        </div>
                    </div>
                    
                    <div class="descr_completa">
                        <p>
                            <?php echo $dizionario['descrizione_totale_hogwarts_hp']; ?>    
                        </p>
                    </div>

                    <div class="sezione_prenotazione">
                        <h2><?php echo $dizionario['invito_prenotazione_hp']; ?></h2>
                        
                        <?php
                            if($_SESSION['logged']){
                        ?>
                        
                        <div class="prenotazione">
                            <form action="mailto:multiversus.tsw21@gmail.com?subject=Prenotazione viaggio a Hogwarts" method="post" enctype="text/plain">
                                <p>
                                    <label for="nome"><?php echo $dizionario['nome_prenotazione_hp']; ?>: </label>
                                    <input type="text" name="nome" class="campo_prenotazione" required>
                                </p>
                                
                                <p>
                                    <label for="cognome"><?php echo $dizionario['cognome_prenotazione_hp']; ?>: </label>
                                    <input type="text" name="cognome" class="campo_prenotazione" required>
                                </p>
                                
                                <p>
                                    <label for="mail">Email: </label>
                                    <input type="email" name="mail" class="campo_prenotazione" required>
                                </p>
                            
                                <p>
                                    <label for="initialDate"><?php echo $dizionario['data_partenza_hp']; ?>: </label>
                                    <input type="date" name="initialDate" required>

                                    <label for="finalDate"><?php echo $dizionario['data_arrivo_hp']; ?>: </label>
                                    <input type="date" name="finalDate" required>
                                </p>

                                <input type="submit" value="<?php echo $dizionario['tasto_invio_prenotazione_hp']; ?>">
                                
                            </form>
                        </div>
                        
                        <?php
                            }else{
                        ?>
                        
                        <div>
                            <p><?php echo $dizionario['prenotazione_non_loggato']; ?></p>
                        </div>
                        
                        <?php
                            }
                        ?>
                    </div>

                    <input type="button" value="<?php echo $dizionario['tasto_go_back_hp']; ?>" class="goBackButton" id="goBackHogwarts">
                </div>
            </section>
            
            <!--Container Hogsmade-->
            <section class="container_luogo">

                <!--Parte mostrata di Hogsmade-->
                <div id="hogsmade">
                    <h2 class="title_luogo">Hogsmade</h2>
                    <div class="luogo">
                        <img src="Hogsmade_img/hogsmade.jpg" alt="" class="img_luogo" id="hogsmade_img">
                        <p class="descr_luogo">
                            <?php echo $dizionario['descrizione_breve_hogsmade_hp']; ?>
                        </p>
                    </div>
                    
                    <input type="button" value="<?php echo $dizionario['tasto_espandi_hp']; ?>" class="expandButton" id="expandHogsmade">
                </div>

                <!--Parte nascosta di Hogsmade che viene mostrata cliccando il tasto "Vedi nel dettaglio" o l'immagine del luogo-->
                <div class="parte_nascosta" id="hogsmade_completo">
                    <div class="scheda_luogo">
                        <div class="introduzione_luogo">
                            <h1>HOGSMADE</h1>
                            <p> 
                                <?php echo $dizionario['posizione_hogsmade_hp']; ?> 
                            </p>
                            <p> 
                                <?php echo $dizionario['introduzione_hogsmade_hp']; ?>  
                            </p>
                        </div>

                        <div class="collage">
                            <img src="Hogsmade_img/hogsmade.jpg" alt="" class="collage_img">
                            <img src="Hogsmade_img/mielandia.jpg" alt="" class="collage_img">
                            <img src="Hogsmade_img/zonko.jpg" alt="" class="collage_img">
                            <img src="Hogsmade_img/i_tre_manici_di_scopa.jpg" alt="" class="collage_img">
                            
                        </div>
                    </div>
                    
                    <div class="descr_completa">
                        <p>
                        <?php echo $dizionario['descrizione_totale_hogsmade_hp']; ?>
                        </p>
                    </div>

                    <div class="sezione_prenotazione">
                        <h2><?php echo $dizionario['invito_prenotazione_hp']; ?></h2>
                        
                        <?php
                            if($_SESSION['logged']){
                        ?>

                        <div class="prenotazione">
                            <form action="mailto:multiversus.tsw21@gmail.com?subject=Prenotazione viaggio a Hogsmade" method="post">
                                <p>
                                    <label for="nome"><?php echo $dizionario['nome_prenotazione_hp']; ?>: </label>
                                    <input type="text" name="nome" class="campo_prenotazione" required>
                                </p>
                                
                                <p>
                                    <label for="cognome"><?php echo $dizionario['cognome_prenotazione_hp']; ?>: </label>
                                    <input type="text" name="cognome" class="campo_prenotazione" required>
                                </p>
                                
                                <p>
                                    <label for="mail">Email: </label>
                                    <input type="email" name="mail" class="campo_prenotazione" required>
                                </p>
                            
                                <p>
                                    <label for="initialDate"><?php echo $dizionario['data_partenza_hp']; ?>: </label>
                                    <input type="date" name="initialDate" required>

                                    <label for="finalDate"><?php echo $dizionario['data_arrivo_hp']; ?>: </label>
                                    <input type="date" name="finalDate" required>
                                </p>

                                <input type="submit" value="<?php echo $dizionario['tasto_invio_prenotazione_hp']; ?>">
                                
                            </form>
                        </div>

                        <?php
                            }else{
                        ?>
                        
                        <div>
                            <p><?php echo $dizionario['prenotazione_non_loggato']; ?></p>
                        </div>
                        
                        <?php
                            }
                        ?>

                    </div>

                    <input type="button" value="<?php echo $dizionario['tasto_go_back_hp']; ?>" class="goBackButton" id="goBackHogsmade">
                </div>
            </section>
                    
            <!--Container Diagon Alley-->
            <section class="container_luogo">

            <!--Parte mostrata di Diagon Alley-->
                <div id="diagonAlley">
                    <h2 class="title_luogo">Diagon Alley</h2>
                    <div class="luogo">
                        <img src="DiagonAlley_img/DiagonAlley.jpg" alt="" class="img_luogo" id="diagonAlley_img">
                        <p class="descr_luogo">
                            <?php echo $dizionario['descrizione_breve_diagonAlley_hp']; ?>
                        </p>
                    </div>
                    
                    <input type="button" value="<?php echo $dizionario['tasto_espandi_hp']; ?>" class="expandButton" id="expandDiagonAlley">
                </div>

                <!--Parte nascosta di Diagon Alley che viene mostrata cliccando il tasto "Vedi nel dettaglio" o l'immagine del luogo-->
                <div class="parte_nascosta" id="diagonAlley_completo">
                    <div class="scheda_luogo">
                        <div class="introduzione_luogo">
                            <h1>DIAGON ALLEY</h1>
                            <p> 
                                <?php echo $dizionario['posizione_diagonAlley_hp']; ?> 
                            </p>
                            <p> 
                                <?php echo $dizionario['introduzione_diagonAlley_hp']; ?>  
                            </p>
                        </div>

                        <div class="collage">
                            <img src="DiagonAlley_img/diagon_Alley.jpg" alt="" class="collage_img">
                            <img src="DiagonAlley_img/olivander.jpg" alt="" class="collage_img">
                            <img src="DiagonAlley_img/tiri_vispi_weasley.jpg" alt="" class="collage_img">
                            <img src="DiagonAlley_img/gringott.jpg" alt="" class="collage_img">
                            
                        </div>
                    </div>
                    
                    <div class="descr_completa">
                        <p>
                            <?php echo $dizionario['descrizione_totale_diagonAlley_hp']; ?>
                        </p>
                    </div>

                    <div class="sezione_prenotazione">
                        <h2><?php echo $dizionario['invito_prenotazione_hp']; ?></h2>

                        <?php
                            if($_SESSION['logged']){
                        ?>
                        
                        <div class="prenotazione">
                            <form action="mailto:multiversus.tsw21@gmail.com?subject=Prenotazione viaggio a Diagon Alley" method="post">
                                <p>
                                    <label for="nome"><?php echo $dizionario['nome_prenotazione_hp']; ?>: </label>
                                    <input type="text" name="nome" class="campo_prenotazione" required>
                                </p>
                                
                                <p>
                                    <label for="cognome"><?php echo $dizionario['cognome_prenotazione_hp']; ?>: </label>
                                    <input type="text" name="cognome" class="campo_prenotazione" required>
                                </p>
                                
                                <p>
                                    <label for="mail">Email: </label>
                                    <input type="email" name="mail" class="campo_prenotazione" required>
                                </p>
                            
                                <p>
                                    <label for="initialDate"><?php echo $dizionario['data_partenza_hp']; ?>: </label>
                                    <input type="date" name="initialDate" required>

                                    <label for="finalDate"><?php echo $dizionario['data_arrivo_hp']; ?>: </label>
                                    <input type="date" name="finalDate" required>
                                </p>

                                <input type="submit" value="<?php echo $dizionario['tasto_invio_prenotazione_hp']; ?>">
                                
                            </form>
                        </div>
                        
                        <?php
                            }else{
                        ?>
                        
                        <div>
                            <p><?php echo $dizionario['prenotazione_non_loggato']; ?></p>
                        </div>
                        
                        <?php
                            }
                        ?>
                        
                        
                    </div>
                    
                    <input type="button" value="<?php echo $dizionario['tasto_go_back_hp']; ?>" class="goBackButton" id="goBackDiagonAlley">
                </div>
            </section>
        </div>
        <hr>

        <!--Sezione recensioni-->
        <div id="sez_recensioni">
            <h2><?php echo $dizionario['sezione_recensioni_hp']; ?></h2>

            <?php
            //Se l'utente è loggato vengono mostrati i commenti e viene data la possibilità di inserire un commento
            if($_SESSION['logged'] == true){
            ?>
            
            <!--Contenitore col form dove mettere i campi per inserire una recensione-->
            <div>
                <form action="<?php echo $_SERVER['PHP_SELF']?>?lan=<?php echo $lan; ?>" method="post">
                    
                    <!--Area di testo dove inserire la recensione-->
                    <p class="campo_rec">
                        <label for="recensione"><?php echo $dizionario['inserisci_recensione_hp']; ?></label> <br>
                        <textarea name="recensione" cols="30" rows="5" required></textarea>
                    </p>
                    
                    <!--Campo dove inserire le stelle della recensione-->
                    <p class="campo_rec">
                        <label for="stelle"><?php echo $dizionario['inserisci_stelle_hp']; ?></label>
                        <img id="stella1" onclick="background_stelle(1)" src="img_sito/not_selected_star.png" alt="stellina_recensioni1" height="30cm" width="30cm">
                        <img id="stella2" onclick="background_stelle(2)" src="img_sito/not_selected_star.png" alt="stellina_recensioni2" height="30cm" width="30cm">
                        <img id="stella3" onclick="background_stelle(3)" src="img_sito/not_selected_star.png" alt="stellina_recensioni3" height="30cm" width="30cm">
                        <img id="stella4" onclick="background_stelle(4)" src="img_sito/not_selected_star.png" alt="stellina_recensioni4" height="30cm" width="30cm">
                        <img id="stella5" onclick="background_stelle(5)" src="img_sito/not_selected_star.png" alt="stellina_recensioni5" height="30cm" width="30cm">

                        <!--Quando clicco una stella per indicare quante stelle ha la recensione viene aggiornato il valore di questo input nascosto
                            che poi mado tramite il form e mi permette di conservare il numero di stelle del commento-->
                        <input type="hidden" name="stelle" id="num_stelle" min="1" max="5" required>
                    </p>

                    <input type="submit" value="Invia recensione" id="rec_button">
                </form>

                <?php
                    //Procedura per aggiungere un commento che viene avviata dopo che l'utente ha compilato e inviato i campi del form
                    if(!empty($_POST)){
                        //Mi connetto al database
                        $db = pg_connect($connection_string) or die('Impossibile connetersi al database: ' . pg_last_error());
            
                        //Prendo i valori dei campi che dovrò inserire nella tabella recensioni del database
                        $username = $_SESSION['username'];
                        $propic = $_SESSION['propic'];
                        $recensione = pg_escape_literal($_POST['recensione']);
                        $stelle = $_POST['stelle'];
                        date_default_timezone_set('Europe/Rome');
                        $data = date('Y-m-d H:i:s');
                        $universo = "Hp";

                        //Verifico se il commento dell'utente è stato già scritto in precedenza dall'utente, in questo caso non verrà inserito.
                        //Per verificare ciò devp vedere se c'è una recensione con le stesse primary_key di quelle della recensione che l'utente inserire
                        $sql = "SELECT username, recensione FROM recensioni";
                        $verifica_rec = pg_query($db, $sql);

                        //Se la query da errore lo stampo
                        if(!$verifica_rec){
                            echo pg_last_error($db);
                        }else{
                            //Uso la variabile trovato per verificare se i campi inseriti che sono primary key(username e testo della recensione) corrispondono
                            //alle primary key di un recensione già presente nella table e quindi non è possibile inserire la nuova recensione
                            //con le stesse primary key
                            $trovato = false;

                            //Scorro la table e non appena vedo che la recensione che voglio inserire ha testo e username uguali a quelli di 
                            //una recensione già presente nella table la variabile trovato diventa true e faccio break
                            while($row = pg_fetch_assoc($verifica_rec)){
                                if($row['username']==$username && $row['recensione']==$recensione){
                                    $trovato = true;
                                    break;
                                }
                            }

                            //Se trovato=false la recensione non è già presente dunque posso tranquillamente inserirla nella tabella delle recensioni
                            if($trovato == false){
                                $sql = "INSERT INTO recensioni(username, propic, recensione, stelle, data, universo)
                                VALUES($1, $2, $3, $4, $5, $6)";
                                $ret = pg_prepare($db,"InsertRecensioni", $sql);
                                
                                if(!$ret){
                                    echo pg_last_error($db);
                                }else{
                                    $ret = pg_execute($db, "InsertRecensioni", array($username, $propic, $recensione, $stelle, $data, $universo));
                                }
                                
                            }
                            
                        }
                        //Chiudo la connessione
                        pg_close($db);
                    }

                ?>
            </div>
            <hr>

            <!--Sezione dove l'utente vede le recensioni degli altri utenti-->
            <div>
            <?php
                //Mi connetto al database
                $db = pg_connect($connection_string) or die('Impossibile connetersi al database: ' . pg_last_error());
                
                //Prendo le recensioni dalla tabella delle recensioni
                $sql = "SELECT * FROM recensioni";
                $recensioni = pg_query($db, $sql);
                
                //Se la query non va a buon fine stampo l'errore
                if(!$recensioni){
                    echo pg_last_error($db);
                
                }else{
                    //Scorro le righe della table e ogni volta che trovo una recensione che ha universo="Hp",dunque deve essere mostrata nella pagina di Harry
                    //Potter, creo un div con all'interno i valori della recensione che otteng mediante la funzione pg_fetch_result()
                    $count_row = 0;
                    while($row = pg_fetch_assoc($recensioni)){
                            if(pg_fetch_result($recensioni, $count_row, 'universo') == "Hp"){
                                ?>

                                <!--Contenitore recensione-->
                                <div class="recensione">
                                    <!--Contenitore con propic dell'utente che ha scritto la recensione-->
                                    <div class="propic_recensione">
                                        <img src="../login/<?php echo str_replace("'", "", pg_fetch_result($recensioni, $count_row, 'propic')); ?>">
                                    </div>

                                    <!--Contenitore con in alto username, stelle e data della recensione e sotto il testo della recensione-->
                                    <div class="text_recensione">
                                        <span class="username_rec">
                                            <?php
                                                //Levo gli apici all'inizio e alla fine dell'username
                                                $lunghezza = strlen(pg_fetch_result($recensioni, $count_row, 'username'));
                                                $utente = substr(pg_fetch_result($recensioni, $count_row, 'username'), 1, $lunghezza - 2);
                                                echo $utente;
                                            ?>
                                        </span>
                                    
                                        <span>
                                            <?php
                                                //Metto tante stelle quanto è il valore che si trova nella colonna stelle della recensione-->
                                                for($i = 0; $i < pg_fetch_result($recensioni, $count_row, 'stelle'); $i++){
                                            ?>
                                                <img src="img_sito/star.png" alt="" class="star">
                                            <?php
                                                }
                                            ?>
                                        </span>
                                        
                                        <span class="data_rec">
                                            <?php echo $dizionario['data_hp']; ?><?php echo pg_fetch_result($recensioni, $count_row, 'data'); ?>
                                        </span>

                                        <p>
                                            <?php
                                                //Levo gli apici all'inizio e alla fine della recensione
                                                $lunghezza = strlen(pg_fetch_result($recensioni, $count_row, 'recensione'));
                                                $rec = substr(pg_fetch_result($recensioni, $count_row, 'recensione'), 1, $lunghezza - 2);
                                                echo $rec;
                                            ?>
                                        </p>
                                    </div>
                                </div>
                                
                                <?php
                            }
                            //Ogni volta che scorro una riga counter_row incrementa
                            $count_row++;
                        }
                    
                    //Chiudo la connessione
                    pg_close($db);
                }
            ?>
            
            </div>

            <?php
            //Se l'utente non è loggato esce una stringa che indica che per poter vedere la sezione commenti è necessario effettuare l'accesso
            }else{
            ?>
                <p><?php echo $dizionario['recensioni_non_loggato_hp']; ?></p>
            <?php
            }
            ?>
        </div>

        </div>
       
        <!--SCRIPT CHE FA FARE ANIMAZIONI-->
        <script>
            //SCRIPT PER FARE ANIMAZIONE HARRY
            const canvas = document.getElementById('harryAnimation');   //Prendo il tag canvas relativo all'animazione tramite ID con getElementById
            const ctx = canvas.getContext('2d');                //Preso l'elemento canvas da quell'elemento predno il contesto 2d
            
            const image = new Image();
            image.src = 'img_sito/hp.png'; // Creo nuovva immagine e assegno l'url dell'immagine di harry potter
            
            const velocita = 2; // Velocità dell'immagine
            const spostamento = 50; // quanto l'immagine si sposta
            let angolo = Math.PI/4; // Angolo iniziale

            function animazione_harry() {
                // serve a eliminare l'immagine precedente che si crea all'animazione, altrimenti si creerebbero delle immagini sovrapposte
                ctx.clearRect(0, 0, canvas.width, canvas.height);

                // Calcola la posizione dell'immagine in base al movimento
                const x = muoviAsseX(angolo, spostamento);
                const y = muoviAsseY(angolo, spostamento);

                ctx.drawImage(image, x, y, 150, 50); // imposta le dimensioni dell'immagine

                // Aggiorna l'angolo per il prossimo frame
                angolo = angolo + velocita * 0.02;

                // serve effettivamente a animare l'immagine chiamando se stessa ricorsivamente
                requestAnimationFrame(animazione_harry);
            }

            //Funzione che crea il movimento sull'asse x
            function muoviAsseX(angolo, spostamento){
                return 70 + Math.cos(angolo) * spostamento; //ottengo 70 + un valore che va da 0 a 50(lo spostamento)
            }
            
            //Funzione che crea il movimento sull'asse y
            function muoviAsseY(angolo, spostamento) {
                return Math.sin(angolo) * spostamento + 50; //ottengo 70 + un valore che va da 0 a 50(lo spostamento)
            }


            //SCRIPT PER FARE ANIMAZIONE BOCCINO
            const canvas_boc = document.getElementById('boccinoAnimation');
            const ctx_boc = canvas_boc.getContext('2d');
            const boc_img = new Image();
            boc_img.src = 'img_sito/boccino.png';

            const velocita_boc = 2;
            const spostamento_boc = 50;
            let angolo_boc = -Math.PI/4;    //L'unica cosa che cambia rispetto alla prima animazione e l'angolo, che essendo opposto mi da sin e cos
                                            //negativi dandomi quindi un movimento opposto/in ritardo rispetto al movimento dell'animazione di harry
            function animazione_boccino(){
                // serve a eliminare l'immagine precedente che si crea all'animazione, altrimenti si creerebbero delle immagini sovrapposte
                ctx_boc.clearRect(0, 0, canvas.width, canvas.height);

                // Calcola la posizione dell'immagine in base al movimento
                const x = muoviAsseX(angolo_boc, spostamento_boc);
                const y = muoviAsseY(angolo_boc, spostamento_boc);

                ctx_boc.drawImage(boc_img, x, y, 100, 50); // imposta le dimensioni dell'immagine

                // Aggiorna l'angolo per il prossimo frame
                angolo_boc = angolo_boc + velocita_boc * 0.02;

                // serve effettivamente a animare l'immagine chiamando se stessa ricorsivamente
                requestAnimationFrame(animazione_boccino);
            }

            // avvia le animazioni
            animazione_harry();
            animazione_boccino();


        </script>

    <!-- FOOTER-------------------------------------------------------------------------------------------------------------------------------- -->
    <footer>
        <?php include '../footer/footer.php';?>
    </footer>
    </body>
</html>
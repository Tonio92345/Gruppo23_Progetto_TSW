<link rel="stylesheet" type="text/css" href="recensione.css">

<?php

//Levo gli apici all'inizio e alla fine dell'username
$lunghezza_propic = strlen($propic);
$propic_rec = substr($propic, 1, $lunghezza_propic - 2);


//Levo gli apici all'inizio e alla fine dell'username
$lunghezza_username = strlen($username);
$utente = substr($username, 1, $lunghezza_username - 2);


//Levo gli apici all'inizio e alla fine dell'username
$lunghezza_recensione = strlen($recensione);
$testo_rec = substr($recensione, 1, $lunghezza_recensione - 2);
?>

<div class="recensione">
    <div class="fir_column">
        <img src="../login/<?php echo $propic_rec; ?>" class="propic_rec" alt="foto profilo">
    </div>
    <div class="sec_column">
        <p id="username"><strong>@<?php echo $utente; ?></strong><span><?php echo date("Y-m-d", strtotime($data)); ?></span></p>
        <div id="quote"><q> <?php echo $testo_rec; ?> </q></div>
    </div>
</div>


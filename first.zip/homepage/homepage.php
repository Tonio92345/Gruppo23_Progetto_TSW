<?php
    require_once "../logindb.php";

    //Do inizio alla sessione che mi servirà per la variabile $_SESSION['logged']
    session_start();
?>
<!DOCTYPE html>
<head>
    <html lang="<?php echo $dizionario['lang'];?>">
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>MULTIVERSUS</title>
    <base href=""/>
    <link rel="icon" href="img/logos/C.png" type="image/X-icon"/>
    <link rel="stylesheet" type="text/css" href="homepage.css">
    <link rel="stylesheet" type="text/css" href="recensione.css">
    <meta name="author" content="Progetto_TSW_Gruppo21"/>
    <meta name="keywords" content="Viaggi, prenotazioni, recensioni, multiversi, dragonball, spongebob, harry potter, fantasy"/>
    <meta name="description" content="Il sito web realizzato rientra nella categoria Viaggi e turismo. L'utente ha la possibilità di scegliere di visitare uno tra i 3 universi fantasy proposti. Qui ha accesso ad una scheda descrittiva delle varie mete, con tanto di recensioni, curiosità e la possibilità di potersi prenotare per un eventuale soggiorno-evento."/>
    <script src="homepage.js"></script>
    <?php require('../language/language.php');?>
</head>
<body onload="currentSlide(1); showPromo()">

<!-- HEADER-------------------------------------------------------------------------------------------------------------------------------- -->
    <header>
        <?php include '../header/header.php';?>
    </header>
<!-- -------------------------------------------------------------------------------------------------------------------------------------- -->

<!-- MAIN---------------------------------------------------------------------------------------------------------------------------------- -->
    <main>
    <!-- ASIDE ------------------------------------------------------------------------ -->
        <aside>
            <p id="tit_aside"><?php echo $dizionario['aside_p_titaside'];?></p>
            <div class="narr">
                <img id="reg_dbz" onclick="disappearREG(1)" src="img/reg_dbz_.png" alt="regalo1" width="200px">
                <img id="narr_dbz" src="img/NUNZIATA/goku_presenta-removebg.png" width="200px" onload="appearNuvola(1)">
                <p id="txt_dbz"><?php echo $dizionario['aside_narr_p_txtdbz'];?></p>
                <img id="nuv_dbz" src="img/Nuvoletta.png" width="270px">
            </div>
            <div class="narr">
                <img id="reg_spsq" onclick="disappearREG(2)" src="img/reg_spsq_.png" alt="regalo2" width="200px">
                <img id="narr_spsq" src="img/TUCCILLO/author_spongebob.png" width="130px">
                <p id="txt_spsq"><?php echo $dizionario['aside_narr_p_txtspsq'];?></p>
                <img id="nuv_spsq" src="img/Nuvoletta.png" width="270px">
            </div>
            <div class="narr">
                <img id="reg_hp" onclick="disappearREG(3)" src="img/reg_hp_.png" alt="regalo3" width="200px">
                <img id="narr_hp" src="img/ALESSANDRO/narratore.png" width="150px">
                <p id="txt_hp"><?php echo $dizionario['aside_narr_p_txthp'];?></p>
                <img id="nuv_hp" src="img/Nuvoletta.png" width="270px">   
            </div>
        </aside>
    <!-- ------------------------------------------------------------------------------ -->

    <!-- OFFERTE PROMO----------------------------------------------------------------- -->
        <?php
            if($_SESSION['logged'] == true){
        ?>    
        <section class="offertepromo">
            <div id="titolo_ofp">
                <h2><?php echo $dizionario['section_offertepromo_div_titoloofp_h2'];?></h2>
            </div>
            
            <div class="slideshow-container">
                <div class="mySlides fade">
                    <div class="img_slide">
                        <img id="lun" src="img/ALESSANDRO/Hogsmade.jpg" width="500px">
                        <img id="mar" src="img/NUNZIATA/namecc.jpg" width="500px">
                        <img id="mer" src="img/TUCCILLO/via_conchiglia.jpg" width="500px">
                        <img id="gio1" src="img/TUCCILLO/glove_world.jpg" width="500px">
                        <img id="ven" src="img/TUCCILLO/krusty_krab.jpg" width="500px">
                        <img id="sab1" src="img/ALESSANDRO/Hogwarts.jpg" width="500px">
                        <img id="dom1" src="img/NUNZIATA/stanza_dello_spirito.jpg" width="500px">
                        <div class="sale"><img src="img/pngwing.com.png" width="100px"></div>
                        <div class="special_offer"><img src="img/pngwingc.png" width="100px"></div>
                    </div>
                    <div class="desc_slide"><p id="desc1"></p></div>
                </div>

                <div class="mySlides fade">
                    <div class="img_slide">
                        <img id="gio2" src="img/ALESSANDRO/DiagonAlley.jpg" width="500px">
                        <img id="sab2" src="img/NUNZIATA/torneo_tenkaichi.jpeg" width="500px">
                        <img id="dom2" src="img/TUCCILLO/bikini_bottom.jpg" width="500px">
                        <img id="no_more_it" src="img/no_more.png" width="500px">
                        <img id="no_more_en" src="img/no_more_en.png" width="500px">
                        <img id="no_more_fr" src="img/no_more_fr.png" width="500px">
                        <div class="sale"><img src="img/pngwing.com.png" width="100px"></div>
                        <div class="special_offer"><img src="img/pngwingc.png" width="100px"></div>
                    </div>
                    <div class="desc_slide" id="desc_s2"><p id="desc2"></p></div>
                </div>

                <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
                <a class="next" onclick="plusSlides(1)">&#10095;</a>
            </div>

            <br>

            <div style="text-align:center">
                <span class="dot" onclick="currentSlide(1)"></span>
                <span class="dot" onclick="currentSlide(2)"></span>
            </div>
        </section>
        <?php 
           }else{
        ?>
        <section class="offertepromo">
            <div id="titolo_ofp">
                <h2><?php echo $dizionario['section_offertepromo_div_titoloofp_h2'];?></h2>
            </div>
            
            <div class="slideshow-container">
                <div class="mySlides fade">
                    <div class="img_slide">
                        <img class="slide" src="img/blur_nl.jpg">
                    </div>
                    <div class="desc_slide">
                        <p id="desc1">
                        <?php
                            echo $dizionario['offerte_non_loggato'];
                        ?>
                        </p>
                    </div>
                </div>

                <div class="mySlides fade">
                    <div class="img_slide">
                        <img class="slide" src="img/blur_nl.jpg">
                    </div>
                    <div class="desc_slide">
                        <p id="desc1">
                        <?php
                            echo $dizionario['offerte_non_loggato'];
                        ?>
                        </p>
                    </div>
                </div>

                <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
                <a class="next" onclick="plusSlides(1)">&#10095;</a>
            </div>

            <br>

            <div style="text-align:center">
                <span class="dot" onclick="currentSlide(1)"></span>
                <span class="dot" onclick="currentSlide(2)"></span>
            </div>
        </section>
        <?php 
           }
        ?>
    <!-- ------------------------------------------------------------------------------ -->

    <!-- EVENTI DATA------------------------------------------------------------------ -->
        <?php
            if($_SESSION['logged'] == true){
        ?>
        <section class="eventidata">
            <fieldset>    
                <legend class="titolo_sec"><?php echo $dizionario['section_eventidata_legend_titolosec'];?></legend>
                <div id="form_eventi">
                    <form method="GET">
                        <p id="p_mese"><input id="monthInput" type="month"></p>
                        <p id="p_bottoni">
                            <input type="button" value="<?php echo $dizionario['section_eventidata_form_p_pbottoni_input1'];?>" onclick="showEvento()">
                            <input type="reset" value="<?php echo $dizionario['section_eventidata_form_p_pbottoni_input2'];?>">
                        </p>
                    </form>
                </div>
                <div id="evento">
                    <img id="gen" src="img/ALESSANDRO/Hogsmade.jpg" width="600px">
                    <img id="dic" src="img/NUNZIATA/namecc.jpg" width="600px">
                    <img id="sett" src="img/TUCCILLO/via_conchiglia.jpg" width="600px">
                    <img id="apr" src="img/TUCCILLO/glove_world.jpg" width="600px">
                    <img id="mar" src="img/TUCCILLO/krusty_krab.jpg" width="600px">
                    <img id="ott" src="img/ALESSANDRO/Hogwarts.jpg" width="600px">
                    <img id="ago" src="img/NUNZIATA/stanza_dello_spirito.jpg" width="600px">
                    <img id="nov" src="img/ALESSANDRO/DiagonAlley.jpg" width="600px">
                    <img id="giu" src="img/NUNZIATA/torneo_tenkaichi.jpeg" width="600px">
                    <img id="lug" src="img/TUCCILLO/bikini_bottom.jpg" width="600px">
                    <img id="n_e_it" src="img/no_eventi.jpg" width="600px">
                    <img id="n_e_en" src="img/no_eventi_en.jpg" width="600px">
                    <img id="n_e_fr" src="img/no_eventi_fr.jpg" width="600px">
                    <img id="def" src="img/left_pointer.gif" width="400px">
                    <div class="desc_evento"><p id="p_de"></p></div>
                </div>
            </fieldset>
        </section>

        <?php
            }else{
        ?>

        <section class="eventidata">
            <fieldset>    
                <legend class="titolo_sec"><?php echo $dizionario['section_eventidata_legend_titolosec'];?></legend>
                <div id="form_eventi">
                    <p><?php echo $dizionario['section_eventidata_p'];?></p>
                </div>
                <div id="evento_nl">
                    <img src="img/blur_nl.jpg" width="600px">
                </div>
            </fieldset>
        </section>

        <?php
            }
        ?>
    <!-- ------------------------------------------------------------------------------ -->

    <!--Scheda Utente--------------------------------------------------------------------->
    <?php
    if($_SESSION['logged']){
    ?>

    
    <div id="scheda_user">
    <h2><?php echo $dizionario['scheda_utente']; ?></h2>
    <form action="" onclick="mostra_scheda_utente(<?php echo $_SESSION['email']; ?>)" id="scheda_button"> 
        <input type="button" value="<?php echo $dizionario['bottone_info_utente']; ?>">
    </form>
    <br>
    <div id="txtHint"></div>
    <form action="" onclick="mostra_scheda_utente('')" id="chiudi_scheda_button"> 
        <input type="button" value="<?php echo $dizionario['bottone_chiudi_scheda']; ?>">
    </form>

    <script>
    function mostra_scheda_utente(str) {
    var chiudi_scheda = document.getElementById('chiudi_scheda_button');
    var scheda = document.getElementById('scheda_button');
    if (str == "") {
        scheda.style.display = "";
        chiudi_scheda.style.display = "none";
        document.getElementById("txtHint").innerHTML = "";
        return;
    }
    const xhttp = new XMLHttpRequest();
    scheda.style.display = "none";
    chiudi_scheda.style.display = "";

    xhttp.onload = function() {
        document.getElementById("txtHint").innerHTML = this.responseText;
    }
    xhttp.open("GET", "vai_al_database.php?lan=<?php echo $lan; ?>&q="+str);
    xhttp.send();
    }
    </script>
    </div>

    <?php
    }
    ?>

    <!-- RECENSIONI-------------------------------------------------------------------- -->
        <?php
            if($_SESSION['logged'] == true){
        ?>

        <article class="migliorirecensioni">
            <table border="1">
                <caption class="titolo_sec"><?php echo $dizionario['article_migliorirecensioni_table_caption_titolo_sec'];?></caption>
                <thead>
                    <tr>
                        <th id="r1_c1"><?php echo $dizionario['article_migliorirecensioni_table_thead_r1c1'];?></th>
                        <th id="r1_c2"><?php echo $dizionario['article_migliorirecensioni_table_thead_r1c2'];?></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td rowspan="4">
                            <p><?php echo $dizionario['article_migliorirecensioni_table_tbody_p'];?></p>
                            <img id="stella1" onclick="background_stelle(1)" src="img/not_selected_star.png" alt="stellina_recensioni1" height="30cm" width="30cm">
                            <img id="stella2" onclick="background_stelle(2)" src="img/not_selected_star.png" alt="stellina_recensioni2" height="30cm" width="30cm">
                            <img id="stella3" onclick="background_stelle(3)" src="img/not_selected_star.png" alt="stellina_recensioni3" height="30cm" width="30cm">
                            <img id="stella4" onclick="background_stelle(4)" src="img/not_selected_star.png" alt="stellina_recensioni4" height="30cm" width="30cm">
                            <img id="stella5" onclick="background_stelle(5)" src="img/not_selected_star.png" alt="stellina_recensioni5" height="30cm" width="30cm">
                            <form action="<?php echo $_SERVER['PHP_SELF']?>?lan=<?php echo $lan; ?>" id="form_filter" method="post">
                                
                                <!--Quando clicco una stella per indicare quante stelle ha la recensione viene aggiornato il valore di questo input nascosto
                                che poi mado tramite il form e mi permette di conservare il numero di stelle del commento-->
                                <input type="hidden" name="stelle" id="num_stelle" min="1" max="5" required>

                                <input type="submit" id="filter_submit" value="<?php echo $dizionario['tasto_invio_prenotazione_hp']; ?>">
                            </form>
                        </td>
                    </tr>
                    <?php
                    if(empty($_POST)){
                        //Mi connetto al database
                        $db = pg_connect($connection_string) or die('Impossibile connetersi al database: ' . pg_last_error());
                                    
                        //Prendo le recensioni dalla tabella delle recensioni
                        $sql = "SELECT * FROM recensioni ORDER BY data DESC";
                        $recensioni = pg_query($db, $sql);

                        //Se la query non va a buon fine stampo l'errore
                        if(!$recensioni){
                            echo pg_last_error($db);
                        
                        }else{
                            $count_recensioni = 0;
                            $count_row = 0;
                            while($row = pg_fetch_assoc($recensioni) && $count_recensioni < 3){
                                //Prendo i valori dei campi che dovrò inserire nella tabella recensioni del database
                                $username = pg_fetch_result($recensioni, $count_row, 'username');
                                $propic = pg_fetch_result($recensioni, $count_row, 'propic');
                                $recensione = pg_fetch_result($recensioni, $count_row, 'recensione');
                                $stelle = pg_fetch_result($recensioni, $count_row, 'stelle');
                                $data = pg_fetch_result($recensioni, $count_row, 'data');
                                $universo = pg_fetch_result($recensioni, $count_row, 'universo');
                                ?>
                                <tr>
                                    <td>
                                        <?php include 'recensione.php';?>
                                    </td>
                                </tr>
                                <?php
                                $count_row++;
                                $count_recensioni++;

                            }
                        }
                    }else{
                        $stelle_filtro = $_POST['stelle'];

                        //Mi connetto al database
                        $db = pg_connect($connection_string) or die('Impossibile connetersi al database: ' . pg_last_error());
                                    
                        //Prendo le recensioni dalla tabella delle recensioni
                        $sql = "SELECT * FROM recensioni ORDER BY data DESC";
                        $recensioni = pg_query($db, $sql);

                        //Se la query non va a buon fine stampo l'errore
                        if(!$recensioni){
                            echo pg_last_error($db);
                        
                        }else{
                            $count_recensioni = 0;
                            $count_row = 0;
                            while($row = pg_fetch_assoc($recensioni) && $count_recensioni < 3){
                                //Prendo i valori dei campi che dovrò inserire nella tabella recensioni del database
                                $username = pg_fetch_result($recensioni, $count_row, 'username');
                                $propic = pg_fetch_result($recensioni, $count_row, 'propic');
                                $recensione = pg_fetch_result($recensioni, $count_row, 'recensione');
                                $stelle = pg_fetch_result($recensioni, $count_row, 'stelle');
                                $data = pg_fetch_result($recensioni, $count_row, 'data');
                                $universo = pg_fetch_result($recensioni, $count_row, 'universo');

                                if($stelle == $stelle_filtro){
                                ?>
                                <tr>
                                    <td>
                                        <?php include 'recensione.php';?>
                                    </td>
                                </tr>
                                <?php
                                $count_recensioni++;
                                }
                                $count_row++;
                                
                            }
                        }
                        //Chiudo la connessione
                        pg_close($db);
                    }
                    
                    ?>
                    
                </tbody>
            </table>
        </article>

        <?php
            }else{
        ?>

        <article class="migliorirecensioni">
            <table border="1">
                <caption class="titolo_sec"><?php echo $dizionario['article_migliorirecensioni_table_caption_titolo_sec'];?></caption>
                <thead>
                    <tr>
                        <th id="r1_c1"><?php echo $dizionario['article_migliorirecensioni_table_thead_r1c1'];?></th>
                        <th id="r1_c2"><?php echo $dizionario['article_migliorirecensioni_table_thead_r1c2'];?></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td rowspan="3">
                            <p><?php echo $dizionario['article_migliorirecensioni_table_tbody_p_extra'];?></p>
                        </td>
                        <td>
                            <img id= "it" src="img/blur_rec_<?php echo $lan; ?>.png">
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <img id= "it" src="img/blur_rec_<?php echo $lan; ?>.png">
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <img id= "it" src="img/blur_rec_<?php echo $lan; ?>.png">
                        </td>
                    </tr>
                </tbody>
            </table>
        </article>

        <?php
            }
        ?>
    <!-- ------------------------------------------------------------------------------ -->
    </main>
<!-- -------------------------------------------------------------------------------------------------------------------------------------- -->

<!-- FOOTER-------------------------------------------------------------------------------------------------------------------------------- -->
    <footer>
        <?php include '../footer/footer.php';?>
    </footer>
<!-- -------------------------------------------------------------------------------------------------------------------------------------- -->
</body>
</html>
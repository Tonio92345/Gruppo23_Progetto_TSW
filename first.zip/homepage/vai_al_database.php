<?php
require_once "../logindb.php";
require_once "../language/language.php";

$db = pg_connect($connection_string) or die('Impossibile connetersi al database: ' . pg_last_error());

$sql = "SELECT * FROM utenti";
$utente = pg_query($db, $sql);

//Se la query da errore lo stampo
if(!$utente) {
    echo pg_last_error($db);
}else{

while($row = pg_fetch_assoc($utente)){
    if(str_replace("'", "", $row['email']) == $_GET['q']){
        ?>
        <img src="../login/<?php echo str_replace("'", "", $row['propic']); ?>" alt="" width="80">
        <?php
        echo "<table>";
        echo "<tr>";
        echo "<th>". $dizionario['username_login']. "</th>";
        echo "<th>". $dizionario['nome_login']. "</th>";
        echo "<th>". $dizionario['cognome_login']. "</th>";
        echo "<th>". $dizionario['sesso_login']. "</th>";
        echo "<th>". $dizionario['data_login']. "</th>";
        echo "<th>Email</th>";
        echo "</tr>";
        echo "<tr>";
        echo "<td>" . $row['username'] . "</td>";
        echo "<td>" . $row['nome'] . "</td>";
        echo "<td>" . $row['cognome'] . "</td>";
        echo "<td>" . $row['sesso'] . "</td>";
        echo "<td>" . $row['data'] . "</td>";
        echo "<td>" . $row['email'] . "</td>";
        echo "</tr>";
        echo "</table>";
        break;
        }
    }
}

// Chiudi la connessione
pg_close($db);
?>

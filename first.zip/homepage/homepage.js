/* -ASIDE------------------------------------------------------------------------------------------------ */

function disappearREG(y){
    if(y===1){
        var regalo = document.querySelector("#reg_dbz");
        var nuvoletta = document.querySelector("#nuv_dbz");
        var narratore = document.querySelector("#narr_dbz");
        var blur = document.querySelector("#blur_dbz");
        var text = document.querySelector("#txt_dbz");
        narratore.style.setProperty("top", "30%");
    }else if(y===2){
        var regalo = document.querySelector("#reg_spsq");
        var nuvoletta = document.querySelector("#nuv_spsq");
        var narratore = document.querySelector("#narr_spsq");
        var blur = document.querySelector("#blur_spsq");
        var text = document.querySelector("#txt_spsq");
        narratore.style.setProperty("top", "56%");
        narratore.style.setProperty("left", "30%");
    }
    else{
        var regalo = document.querySelector("#reg_hp");
        var nuvoletta = document.querySelector("#nuv_hp");
        var narratore = document.querySelector("#narr_hp");
        var blur = document.querySelector("#blur_hp");
        var text = document.querySelector("#txt_hp");
        narratore.style.setProperty("top", "80%");
        narratore.style.setProperty("left", "26%");
    }
    regalo.style.cursor = "none";
    regalo.style.opacity = "25%";
    nuvoletta.style.opacity = "100%";
    text.style.opacity = "100%";
    narratore.style.display = "block";
    blur.style.display = "none";
}
/* -OFFERTE E PROMO----------------------------------------------------------------------------------------------------- */

function showPromo(){
    var oggi = new Date();
    var giornoSettimana = oggi.getDay();

    var lun = document.querySelector(".img_slide #lun");
    var mar = document.querySelector(".img_slide #mar");
    var mer = document.querySelector(".img_slide #mer");
    var gio1 = document.querySelector(".img_slide #gio1");
    var gio2 = document.querySelector(".img_slide #gio2");
    var ven = document.querySelector(".img_slide #ven");
    var sab1 = document.querySelector(".img_slide #sab1");
    var sab2 = document.querySelector(".img_slide #sab2");
    var dom1 = document.querySelector(".img_slide #dom1");
    var dom2 = document.querySelector(".img_slide #dom2");
    var nm_it = document.querySelector(".img_slide #no_more_it");
    var nm_en = document.querySelector(".img_slide #no_more_en");
    var nm_fr = document.querySelector(".img_slide #no_more_fr");
    var desc1 = document.querySelector(".desc_slide #desc1");
    var desc2 = document.querySelector(".desc_slide #desc2");
    var desc_s2 = document.querySelector("#desc_s2");

    var currentSearchParams = new URLSearchParams(window.location.search);
    var param1Value = currentSearchParams.get('lan');

    switch (giornoSettimana) {
        case 0:
            dom1.style.display = "block";
            dom2.style.display = "block";
            if(param1Value === "it"){
                desc1.textContent = "Oggi è Domenica, super offerta! 50% di sconto se prenoterai la Stanza dello spirito e del tempo.";
                desc2.textContent = "Inoltre.. 50% di sconto per la tua visita a Bikini Bottom.";
            }
            else if(param1Value === "en"){
                desc1.textContent = "Today is Sunday, super offer! 50% discount if you book the Room of spirit and time.";
                desc2.textContent = "Plus.. 50% discount for your visit to Bikini Bottom.";
            }
            else if(param1Value === "fr"){
                desc1.textContent = "Aujourd’hui c’est dimanche, super offre! 50% de réduction si vous réservez la Chambre de l’esprit et du temps.";
                desc2.textContent = "Aussi. 50% de réduction pour votre visite à Bikini Bottom.";
            }
            else{
                desc1.textContent = "Oggi è Domenica, super offerta! 50% di sconto se prenoterai la Stanza dello spirito e del tempo.";
                desc2.textContent = "Inoltre.. 50% di sconto per la tua visita a Bikini Bottom.";
            }
            break;
        case 1:
            lun.style.display = "block";
            if(param1Value === "it"){
                nm_it.style.display = "block";
                desc1.textContent = "Lunedì, la tua offerta: 20% di sconto per la tua passeggiata a Hogsmade.";
            }
            else if(param1Value === "en"){
                nm_en.style.display = "block";
                desc1.textContent = "Monday, your offer: 20% discount for your walk in Hogsmade.";
            }
            else if(param1Value === "fr"){
                nm_fr.style.display = "block";
                desc1.textContent = "Lundi, votre offre: 20% de réduction pour votre promenade à Hogsmade.";
            }
            else{
                nm_it.style.display = "block";
                desc1.textContent = "Lunedì, la tua offerta: 20% di sconto per la tua passeggiata a Hogsmade.";
            }
            desc_s2.style.display = "none";
            break;
        case 2:
            mar.style.display = "block";
            if(param1Value === "it"){
                nm_it.style.display = "block";
                desc1.textContent = "Martedì, ottima offerta: 35% di sconto per un viaggio su Namecc.";
            }
            else if(param1Value === "en"){
                nm_en.style.display = "block";
                desc1.textContent = "Tuesday, great offer: 35% discount for a trip to Namek.";
            }
            else if(param1Value === "fr"){
                nm_fr.style.display = "block";
                desc1.textContent = "Mardi, excellente offre: 35% de réduction pour un voyage sur Namek.";
            }
            else{
                nm_it.style.display = "block";
                desc1.textContent = "Martedì, ottima offerta: 35% di sconto per un viaggio su Namecc.";
            }
            desc_s2.style.display = "none";
            break;
        case 3:
            mer.style.display = "block";
            if(param1Value === "it"){
                nm_it.style.display = "block";
                desc1.textContent = "Mercoledì, gran bella offerta: 60% di sconto per una visita a Via della Conchiglia.";
            }
            else if(param1Value === "en"){
                nm_en.style.display = "block";
                desc1.textContent = "Wednesday, great offer: 60% discount for a visit to Via della Conchiglia.";
            }
            else if(param1Value === "fr"){
                nm_fr.style.display = "block";
                desc1.textContent = "Mercredi, grande offre: 60% de réduction pour une visite à Via della Conchiglia.";
            }
            else{
                nm_it.style.display = "block";
                desc1.textContent = "Mercoledì, gran bella offerta: 60% di sconto per una visita a Via della Conchiglia.";
            }
            desc_s2.style.display = "none";
            break;
        case 4:
            gio1.style.display = "block";
            gio2.style.display = "block";
            if(param1Value === "it"){
                desc1.textContent = "Giovedì, la tua promozione: 15% di sconto per Glove World.";
                desc2.textContent = "Inoltre.. 15% di sconto per DiagonAlley.";
            }
            else if(param1Value === "en"){
                desc1.textContent = "Thursday, your promotion: 15% discount for Glove World.";
                desc2.textContent = "Plus.. 15% discount for DiagonAlley.";
            }
            else if(param1Value === "fr"){
                desc1.textContent = "Jeudi, votre promotion: 15% de réduction pour Glove World.";
                desc2.textContent = "Aussi. 15% de réduction pour DiagonAlley..";
            }
            else{
                desc1.textContent = "Giovedì, la tua promozione: 15% di sconto per Glove World.";
                desc2.textContent = "Inoltre.. 15% di sconto per DiagonAlley.";
            }
            break;
        case 5:
            ven.style.display = "block";
            if(param1Value === "it"){
                nm_it.style.display = "block";
                desc1.textContent = "Venerdì, la tua offerta: 10% di sconto per acquistare al Krusty Krub.";
            }
            else if(param1Value === "en"){
                nm_en.style.display = "block";
                desc1.textContent = "Friday, your offer: 10% discount to buy at Krusty Krub.";
            }
            else if(param1Value === "fr"){
                nm_fr.style.display = "block";
                desc1.textContent = "Vendredi, votre offre: 10% de réduction pour acheter au Krusty Krub.";
            }
            else{
                nm_it.style.display = "block";
                desc1.textContent = "Venerdì, la tua offerta: 10% di sconto per acquistare al Krusty Krub.";
            }
            desc_s2.style.display = "none";
            break;
        case 6:
            sab1.style.display = "block";
            sab2.style.display = "block";
            if(param1Value === "it"){
                desc1.textContent = "Oggi è Sabato, super offerta! 50% di sconto per Hogwarts.";
                desc2.textContent = "Inoltre.. 50% di sconto per assistere ad un incontro del Torneo Tenkaichi!";
            }
            else if(param1Value === "en"){
                desc1.textContent = "Today is Saturday, super offer! 50% discount for Hogwarts.";
                desc2.textContent = "Plus.. 50% discount to attend a Tenkaichi Tournament match!";
            }
            else if(param1Value === "fr"){
                desc1.textContent = "Aujourd’hui c’est samedi, super offre! 50% de réduction pour Hogwarts.";
                desc2.textContent = "Aussi. 50% de réduction pour assister à un match du tournoi Tenkaichi!";
            }
            else{
                desc1.textContent = "Oggi è Sabato, super offerta! 50% di sconto per Hogwarts.";
                desc2.textContent = "Inoltre.. 50% di sconto per assistere ad un incontro del Torneo Tenkaichi!";
            }
            break;
        default:
            sab1.style.display = "block";
            sab2.style.display = "block";
            if(param1Value === "it"){
                desc1.textContent = "Oggi è Sabato, super offerta! 50% di sconto per Hogwarts.";
                desc2.textContent = "Inoltre.. 50% di sconto per assistere ad un incontro del Torneo Tenkaichi!";
            }
            else if(param1Value === "en"){
                desc1.textContent = "Today is Saturday, super offer! 50% discount for Hogwarts.";
                desc2.textContent = "Plus.. 50% discount to attend a Tenkaichi Tournament match!";
            }
            else if(param1Value === "fr"){
                desc1.textContent = "Aujourd’hui c’est samedi, super offre! 50% de réduction pour Hogwarts.";
                desc2.textContent = "Aussi. 50% de réduction pour assister à un match du tournoi Tenkaichi!";
            }
            else{
                desc1.textContent = "Oggi è Sabato, super offerta! 50% di sconto per Hogwarts.";
                desc2.textContent = "Inoltre.. 50% di sconto per assistere ad un incontro del Torneo Tenkaichi!";
            }
    }
}

let slideIndex = 1;

let slideTimeout;

showSlides(slideIndex);

function plusSlides(n) {
    showSlides(slideIndex += n);
}
  
function currentSlide(n) {
    showSlides(slideIndex = n);
}

function showSlides(n) {
    let i;
    let slides = document.getElementsByClassName("mySlides");
    let dots = document.getElementsByClassName("dot");

    if (n > slides.length) {slideIndex = 1}    

    if (n < 1) {slideIndex = slides.length}

    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";  
    }

    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }

    slides[slideIndex-1].style.display = "block";  

    dots[slideIndex-1].className += " active";

    clearTimeout(slideTimeout);

    slideTimeout = setTimeout(function() {
        plusSlides(1);
    }, 30000);
}

/* --MOSTRA EVENTO DEL MESE---------------------------------------------------------------------------------------------------- */

function showEvento(){
    var monthInput = document.getElementById("monthInput").value;
    var mese = monthInput.split("-")[1];

    var gen = document.querySelector("#evento #gen");
    var mar = document.querySelector("#evento #mar");
    var apr = document.querySelector("#evento #apr");
    var giu = document.querySelector("#evento #giu");
    var lug = document.querySelector("#evento #lug");
    var ago = document.querySelector("#evento #ago");
    var sett = document.querySelector("#evento #sett");
    var ott = document.querySelector("#evento #ott");
    var nov = document.querySelector("#evento #nov");
    var dic = document.querySelector("#evento #dic");
    var n_e_it = document.querySelector("#evento #n_e_it");
    var n_e_en = document.querySelector("#evento #n_e_en");
    var n_e_fr = document.querySelector("#evento #n_e_fr");
    var def = document.querySelector("#evento #def");
    var desc_evento = document.querySelector(".desc_evento");
    var desc_evento_p = document.querySelector(".desc_evento #p_de");

    gen.style.display = "none";
    mar.style.display = "none";
    apr.style.display = "none";
    giu.style.display = "none";
    lug.style.display = "none";
    ago.style.display = "none";
    sett.style.display = "none";
    ott.style.display = "none";
    nov.style.display = "none";
    dic.style.display = "none";
    n_e_it.style.display = "none";
    n_e_en.style.display = "none";
    n_e_fr.style.display = "none";
    def.style.display = "none";

    var currentSearchParams = new URLSearchParams(window.location.search);
    var param1Value = currentSearchParams.get('lan');

    switch (parseInt(mese)) {
        case 1:
            gen.style.display = "block";
            desc_evento.style.display = "block";
            if(param1Value === "it"){
                desc_evento_p.textContent = "Gennaio, cioccolata calda? NO! Goditi una tazza schiumosa di BURROBIRRA, la bevanda magica venduta da \"I Tre Manici di Scopa\", famosissimo negozio di Hogsmade.";
            }
            else if(param1Value === "en"){
                desc_evento_p.textContent = "January, hot chocolate? NO! Enjoy a foamy cup of BURROBIRRA, the magic drink sold by \"The Three Broomsticks\", famous Hogsmade store.";
            }
            else if(param1Value === "fr"){
                desc_evento_p.textContent = "Janvier, chocolat chaud ? NON ! Profitez d’une tasse mousseuse de BURROBIRRA, la boisson magique vendue par \"I Tre Manici di Scopa\", célèbre magasin de Hogsmade.";
            }
            else{
                desc_evento_p.textContent = "Gennaio, cioccolata calda? NO! Goditi una tazza schiumosa di BURROBIRRA, la bevanda magica venduta da \"I Tre Manici di Scopa\", famosissimo negozio di Hogsmade.";
            }
            break;
        case 2:
            if(param1Value === "it"){
                n_e_it.style.display = "block";
            }
            else if(param1Value === "en"){
                n_e_en.style.display = "block";
            }
            else if(param1Value === "fr"){
                n_e_fr.style.display = "block";
            }
            else{
                n_e_it.style.display = "block";
            }
            desc_evento.style.display = "none";
            break;
        case 3:
            mar.style.display = "block";
            desc_evento.style.display = "block";
            if(param1Value === "it"){
                desc_evento_p.textContent = "Spring-days del McDonald? Scopri invece le super offerte del Krusty Krab! Prova per la primissima volta il succulento Krabby Patty!";
            }
            else if(param1Value === "en"){
                desc_evento_p.textContent = "McDonald's Spring-days? Discover instead the super offers of Krusty Krab! Try for the very first time the succulent Krabby Patty!";
            }
            else if(param1Value === "fr"){
                desc_evento_p.textContent = "Spring-days au McDonald? Découvrez les super offres du Krusty Krab! Essayez le délicieux Krabby Patty pour la toute première fois!";
            }
            else{
                desc_evento_p.textContent = "Spring-days del McDonald? Scopri invece le super offerte del Krusty Krab! Prova per la primissima volta il succulento Krabby Patty!";
            }
            break;
        case 4:
            apr.style.display = "block";
            desc_evento.style.display = "block";
            if(param1Value === "it"){
                desc_evento_p.textContent = "Aprile è il mese con più turisti al parco divertimenti di Glove World, prova anche tu le più belle attrazioni del mare!";
            }
            else if(param1Value === "en"){
                desc_evento_p.textContent = "April is the month with the most tourists at Glove World amusement park, try also the most beautiful attractions of the sea!";
            }
            else if(param1Value === "fr"){
                desc_evento_p.textContent = "Avril est le mois avec le plus de touristes au parc d’attractions de Glove World, essayez aussi les plus belles attractions de la mer!";
            }
            else{
                desc_evento_p.textContent = "Aprile è il mese con più turisti al parco divertimenti di Glove World, prova anche tu le più belle attrazioni del mare!";
            }
            break;
        case 5:
            if(param1Value === "it"){
                n_e_it.style.display = "block";
            }
            else if(param1Value === "en"){
                n_e_en.style.display = "block";
            }
            else if(param1Value === "fr"){
                n_e_fr.style.display = "block";
            }
            else{
                n_e_it.style.display = "block";
            }
            desc_evento.style.display = "none";
            break;
        case 6:
            giu.style.display = "block";
            desc_evento.style.display = "block";
            if(param1Value === "it"){
                desc_evento_p.textContent = "In questo periodo il più sfavorito è sicuramente Crilin che non potrà sfruttare il suo \"Colpo del sole\", prova a batterlo! Partecipa al torneo!";
            }
            else if(param1Value === "en"){
                desc_evento_p.textContent = "In this period the most underdog is definitely Kulilin who will not be able to exploit his \"Taiyoken\", try to beat him! Participate in the tournament!";
            }
            else if(param1Value === "fr"){
                desc_evento_p.textContent = "Dans cette période, le plus défavorisé est certainement Kulilin qui ne pourra pas profiter de son \"Tayoken\", essayez de le battre! Participez au tournoi!";
            }
            else{
                desc_evento_p.textContent = "In questo periodo il più sfavorito è sicuramente Crilin che non potrà sfruttare il suo \"Colpo del sole\", prova a batterlo! Partecipa al torneo!";
            }
            break;
        case 7:
            lug.style.display = "block";
            desc_evento.style.display = "block";
            if(param1Value === "it"){
                desc_evento_p.textContent = "Luglio vuol dire soltanto tre cose: sole, estate, mare! Quindi? Visita anche tu la più famosa città sottomarina: Bikini Bottom!";
            }
            else if(param1Value === "en"){
                desc_evento_p.textContent = "July means only three things: sun, summer, sea! So? Visit the most famous underwater city: Bikini Bottom!";
            }
            else if(param1Value === "fr"){
                desc_evento_p.textContent = "Juillet ne signifie que trois choses: soleil, été, mer! Alors? Visitez la ville sous-marine la plus célèbre: Bikini Bottom!";
            }
            else{
                desc_evento_p.textContent = "Luglio vuol dire soltanto tre cose: sole, estate, mare! Quindi? Visita anche tu la più famosa città sottomarina: Bikini Bottom!";
            }
            break;
        case 8:
            ago.style.display = "block";
            desc_evento.style.display = "block";
            if(param1Value === "it"){
                desc_evento_p.textContent = "Mentre ti alleni il troppo caldo fa girare la testa, ecco il motivo per cui allenarsi/rilassarsi nella freschissima stanza dello Spirito e del Tempo è la miglior scelta!";
            }
            else if(param1Value === "en"){
                desc_evento_p.textContent = "While you train too hot makes your head spin, that’s why you train/relax in the cool room of Spirit and Time is the best choice!";
            }
            else if(param1Value === "fr"){
                desc_evento_p.textContent = "Pendant que vous vous entraînez, la chaleur vous fait tourner la tête, c’est pourquoi vous devez vous entraîner/vous détendre dans la chambre fraîche de l’Esprit et du Temps!";
            }
            else{
                desc_evento_p.textContent = "Mentre ti alleni il troppo caldo fa girare la testa, ecco il motivo per cui allenarsi/rilassarsi nella freschissima stanza dello Spirito e del Tempo!";
            }
            break;
        case 9:
            sett.style.display = "block";
            desc_evento.style.display = "block";
            if(param1Value === "it"){
                desc_evento_p.textContent = "Ricomincia la scuola! Quale miglior periodo per farsi anche nuovi hobby. A Via della Conchiglia c'è Squiddy, pronto a impartirti lezioni di clarinetto. Occhio però a non farti distrarre da Spongebob e Patrick che catturano meduse!";
            }
            else if(param1Value === "en"){
                desc_evento_p.textContent = "Start school again! What better time to get new hobbies. In Via della Conchiglia there is Squiddy, ready to teach you clarinet lessons. But be careful not to be distracted by Spongebob and Patrick who catch jellyfish!";
            }
            else if(param1Value === "fr"){
                desc_evento_p.textContent = "Reprenez l’école! Quelle meilleure période pour se faire de nouveaux passe-temps. A Via della Conchiglia il y a Squiddy, prêt à vous donner des leçons de clarinette. Mais attention à ne pas vous laisser distraire par Spongebob et Patrick qui attrapent des méduses!";
            }
            else {
                desc_evento_p.textContent = "Ricomincia la scuola! Quale miglior periodo per farsi anche nuovi hobby. A Via della Conchiglia c'è Squiddy, pronto a impartirti lezioni di clarinetto. Occhio però a non farti distrarre da Spongebob e Patrick che catturano meduse!";
            }
            break;
        case 10:
            ott.style.display = "block";
            desc_evento.style.display = "block";
            if(param1Value === "it"){
                desc_evento_p.textContent = "Non hai ancora scelto il tuo percorso di studi? Hogwarts è considerata una delle migliori istituzioni nel mondo dei maghi. Pensaci, vivrai sicuramente belle avventure!";
            }
            else if(param1Value === "en"){
                desc_evento_p.textContent = "Haven’t you chosen your studies yet? Hogwarts is considered one of the best institutions in the world of magicians. Think about it, you will definitely have great adventures!";
            }
            else if(param1Value === "fr"){
                desc_evento_p.textContent = "Vous n’avez pas encore choisi votre chemin d’études? Poudlard est considéré comme l’une des meilleures institutions dans le monde des magiciens. Pensez-y, vous vivrez certainement de belles aventures!";
            }
            else{
                desc_evento_p.textContent = "Non hai ancora scelto il tuo percorso di studi? Hogwarts è considerata una delle migliori istituzioni nel mondo dei maghi. Pensaci, vivrai sicuramente belle avventure!";
            }
            break;
        case 11:
            nov.style.display = "block";
            desc_evento.style.display = "block";
            if(param1Value === "it"){
                desc_evento_p.textContent = "Fra un mese è Natale, pensato ai regali? Passa per DiagonaAlley dove ci sono negozi che vendono abiti, altri telescopi altri ancora bizzarri strumenti d'argento che non hai sicuramente visto prima!";
            }
            else if(param1Value === "en"){
                desc_evento_p.textContent = "In a month it’s Christmas, what about gifts? Go to DiagonaAlley where there are shops that sell clothes, other telescopes still bizarre silver instruments that you definitely have not seen before!";
            }
            else if(param1Value === "fr"){
                desc_evento_p.textContent = "Dans un mois, c’est Noël ? Passez par DiagonaAlley où il y a des magasins qui vendent des vêtements, d’autres télescopes d’autres instruments d’argent bizarres que vous n’avez certainement pas vu avant!";
            }
            else{
                desc_evento_p.textContent = "Fra un mese è Natale, pensato ai regali? Passa per DiagonaAlley dove ci sono negozi che vendono abiti, altri telescopi altri ancora bizzarri strumenti d'argento che non hai sicuramente visto prima!";
            }
            break;
        case 12:
            dic.style.display = "block";
            desc_evento.style.display = "block";
            if(param1Value === "it"){
                desc_evento_p.textContent = "Capodanno alternativo? Namecc può essere la tua meta! Inizia però già a pensare all'idea di non poter fare il cenone... qui gli abitanti si nutrono solo d'acqua!";
            }
            else if(param1Value === "en"){
                desc_evento_p.textContent = "Alternative New Year’s Eve? Namecc can be your destination! But he already starts thinking about the idea of not being able to make the dinner... here the inhabitants feed only on water!";
            }
            else if(param1Value === "fr"){
                desc_evento_p.textContent = "Le Nouvel An alternatif? Namecc peut être votre destination! Mais il commence déjà à penser à l’idée de ne pas pouvoir faire le dîner... ici les habitants ne se nourrissent que d’eau!";
            }
            else{
                desc_evento_p.textContent = "Capodanno alternativo? Namecc può essere la tua meta! Inizia però già a pensare all'idea di non poter fare il cenone... qui gli abitanti si nutrono solo d'acqua!";
            }
            break;
        default:
            def.style.display = "block";
            desc_evento.style.display = "none";
    }
}

/* --RECENSIONI---------------------------------------------------------------------------------------------------- */

//Funzione che serve per far inserire all'utente un numero di stelle nella recensione
    //e inserire il numero di stelle nel database
    //Come parametri gli vien passato il num di stelle che dipende dalla stella che clicco
    function background_stelle(x){
        //Array dove prendo le 5 img stelle 
        var stelle = new Array();
        stelle[0] = document.querySelector("#stella1");
        stelle[1] = document.querySelector("#stella2");
        stelle[2] = document.querySelector("#stella3");
        stelle[3] = document.querySelector("#stella4");
        stelle[4] = document.querySelector("#stella5");
        
        //Prendo il numero di stelle e lo metto nell'input nascosto che poi mando col form
        //per inserire una recensione
        var num_stelle = document.getElementById('num_stelle');
        num_stelle.value = x;

        //Coloro le stelle in base a quella che clicco e quando le stelle diventano gialle abilito il
        //bottone per inserire la recensione
        if(stelle[x-1].style.backgroundColor === 'transparent'){
            while(x !== 0){
                stelle[x-1].style.backgroundColor = 'yellow';
                x--;
            }

        }
        //Funzione che fa tornare le stelle trasparenti quando clicco una stella colorata di giallo
        else{
            x = stelle.length;
            while(x !== 0){
                stelle[x-1].style.backgroundColor = 'transparent';
                x--;
            }
        }
    }

/* ------------------------------------------------------------------------------------------------------ */
function appear(){
    var elementoNascosto1 = document.querySelector(".about_us img");
    var elementoNascosto2 = document.querySelector(".about_us #testo_aboutus");

    if (elementoNascosto1.style.display === "none" && elementoNascosto2.style.display === "none") {
        elementoNascosto1.style.display = "block";
        elementoNascosto2.style.display = "block";
    } else {
        elementoNascosto1.style.display = "none";
        elementoNascosto2.style.display = "none";
    }
};

function submitDisabled(i){
    var textContent = document.getElementsByClassName("inputText")[i].value;
    var submitButton = document.getElementsByClassName("buttonInvia")[i];

    if (textContent !== ""){
        submitButton.disabled = false;
        submitButton.style.cursor = "pointer";
    }
    else{
        submitButton.disabled = true;
        submitButton.style.cursor = "not-allowed";
    }
};

function mailSubmitted(i){
    var advice_universo = document.getElementById("adv_uni").value;
    var advice_meta = document.getElementById("adv_meta").value;

    var mailtoLink;
    if (i === 0) {
        mailtoLink = "mailto:multiversus.tsw21@gmail.com?subject=Universo_suggerito&body=" + encodeURIComponent(advice_universo);
    } else {
        mailtoLink = "mailto:multiversus.tsw21@gmail.com?subject=Meta_suggerita&body=" + encodeURIComponent(advice_meta);
    }

    var tempLink = document.createElement("a");
    tempLink.href = mailtoLink;

    tempLink.click();

    var grazie = document.querySelector("li[value=\"3\"]");
    grazie.style.display = "block";

    setTimeout(function(){
        grazie.style.display = "none";
    }, 5000);

    var textContent = document.getElementsByClassName("inputText")[i].value;
    textContent = "";
}
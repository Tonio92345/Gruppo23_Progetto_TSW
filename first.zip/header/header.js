function checkText(){
    var searchTerm = document.getElementById('searchInput').value.trim().toLowerCase();
    if(searchTerm === ""){
        document.getElementById('searchResults').style.display = "none";
    }
}

function gestisciRicerca(evento) {
    evento.preventDefault();

    var searchResultsContainer = document.getElementById('searchResults');
    searchResultsContainer.innerHTML = "";

    var searchTerm = document.getElementById('searchInput').value.trim().toLowerCase();
    var elements = document.querySelectorAll('p, h1, h2, th, q');
    var searchResults = new Array();

    for (var i = 0; i < elements.length; i++) {
        var element = elements[i];
        var text = element.textContent.toLowerCase();
        if (text.includes(searchTerm)) {
            searchResults.push(text);
        }
    }

    displaySearchResults(searchResults);
}

function displaySearchResults(results) {
    var searchResultsContainer = document.getElementById('searchResults');
    searchResultsContainer.style.display = "block";

    var currentSearchParams = new URLSearchParams(window.location.search);
    var param1Value = currentSearchParams.get('lan');

    if (results.length > 0) {
        var resultHTML;
        if(param1Value === "it"){
            resultHTML = "<p><strong>Risultati della Ricerca:</strong></p>";
        }
        else if(param1Value === "en"){
            resultHTML = "<p><strong>Results:</strong></p>";
        }
        else if(param1Value === "fr"){
            resultHTML = "<p><strong>Résultat:</strong></p>";
        }
        else{
            resultHTML = "<p><strong>Risultati della Ricerca:</strong></p>";
        }
        
        for (var i = 0; i < results.length; i++) {
            resultHTML += results[i];
            resultHTML += "<hr/>";
        }
        searchResultsContainer.innerHTML = resultHTML;
    } else {
        if(param1Value === "it"){
            searchResultsContainer.innerHTML = "<p><strong>Nessun risultato trovato.</strong></p>";
        }
        else if(param1Value === "en"){
            searchResultsContainer.innerHTML = "<p><strong>No matches found.</strong></p>";
        }
        else if(param1Value === "fr"){
            searchResultsContainer.innerHTML = "<p><strong>Aucun résultat trouvé.</strong></p>";
        }
        else{
            searchResultsContainer.innerHTML = "<p><strong>Nessun risultato trovato.</strong></p>";
        }
    }
}
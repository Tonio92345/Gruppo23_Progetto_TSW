<?php
    if(!isset($_SESSION['logged'])){
        $_SESSION['logged'] = false;
    }

    if(!isset($_GET['logout'])){
        $_GET['logout'] = false;
    }

    if($_GET['logout'] == true){
        $_SESSION['logged'] = false;
        //$sname = session_name();
        session_destroy();

        /*
        if(isset($_COOKIE[$sname])){
            setcookie($sname, "", time()-3600);
        }
        */
        
        
    }
    
?>

<link rel="stylesheet" type="text/css" href="../header/header.css">
<div class="header">
    <div class="logo_header">
        <a href="../homepage/homepage.php?lang=<?php echo $lan;?>"><img src="../header/img/C.png" alt="logo_multiversus" width="350px"></a>
    </div>
    <div class="lingua">
        <a href="?lan=en"><img src="../header/img/united-kingdom.png" alt="uk_flag" width="40px"></a>
        <a href="?lan=it"><img src="../header/img/italy.png" alt="italy_flag" width="40px"></a>
        <a href="?lan=fr"><img src="../header/img/france.png" alt="france_flag" width="40px"></a>
    </div>
    <div class="searchBox">
        <img src="../header/img/lente_cerca.png" alt="search_lente_ingrandimento" width="30px" height="30px">
        <form id="searchForm" onsubmit="gestisciRicerca(event)">
            <input id="searchInput" type="text" placeholder="<?php echo $dizionario['header_searchForm_input_placeholder'];?>" oninput="checkText()">
            <button type="submit"><?php echo $dizionario['header_searchForm_button_value'];?></button>
        </form>
        <div id="searchResults"></div>
    </div>
    <div class="accessButton">
        <?php
            if(!$_SESSION['logged']){
        ?>
        <a href="../login/login.php?lan=<?php echo $lan; ?>" >
            <input type="button" id="acc_button" value="<?php echo $dizionario['tasto_accedi']; ?>">
        </a>
        
        <?php
            }else{
        ?>

        <a href="?logout=true&lan=<?php echo $lan; ?>">
            <input type="button" id="acc_button" value="Logout">
        </a>

        <?php
            }
        ?>
    </div>
</div>

<!-- BARRA DI NAVIGAZIONE------------------------------------------------------------->
<nav class="navbar">
    <a href="../universo_db/universo_db.php?lan=<?php echo $lan; ?>">
        <div id="dragonball">
            <img src="../header/img/Dragon-Ball-Logo.png" alt="logo_dragonball" width="250" height="70">
            <img class="anim" src="../header/img/detnsfd-cb6a28c3-bdcf-46e8-8941-6bb4e94be31dfds.gif" alt="" width="250" height="70">
        </div>
    </a>
    <a href="../universo_sp/universo_sp.php?lan=<?php echo $lan; ?>">
        <div id="spongebob">
            <img src="../header/img/Spongebob_logo.png" alt="logo_spongebob" width="190" height="70">
            <img class="anim" src="../header/img/cbc-kids-bubbles-transition-p4s1wf2kuws1zcp2.gif" alt="" width="200" height="70">
        </div>
    </a>
    <a href="../universo_hp/harry_potter.php?lan=<?php echo $lan; ?>">
        <div id="harrypotter">
            <img src="../header/img/Harry_Potter_logo.png" alt="logo_harrypotter" width="200" height="70">
            <img class="anim" src="../header/img/Animation - 1707497977672l.gif" alt="" width="200" height="70">
        </div>
    </a>
</nav>
<!-- ------------------------------------------------------------------------------ -->

<script src="../header/header.js"></script>
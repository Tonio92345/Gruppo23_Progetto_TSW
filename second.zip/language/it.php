<?php
    $dizionario = array("descrizione_iniziale_hp" => "Benvenuto nel mio Universo , un mondo incantato di magia, avventura e meraviglia!
    Vieni con me ed esploriamo questo universo straordinario, 
    dove creature fantastiche, incantesimi potenti e avventure epiche ti aspettano ad ogni angolo.", 

    "animazione_non_supportata_hp" => "L'animazione che doveva essere presente qui non è supportata dal browser che si stava usando",

    "descrizione_breve_hogwarts_hp" => "Vivi anche tu la magica avventura del castello di Hogwarts. Con noi esplorare uno dei luoghi più magici che sia 
    mai esistito, potrai camminare per gli antichi corridoi del castello, esplorare aule incantate respirare l'aria intrisa di storia e magia. 
    Al suo interno, troverai la Sala Grande con le 
    sue quattro case distintive, aule di classe come la classe di Pozioni e Trasfigurazione, 
    e luoghi iconici come la Torre dell'orologio e la Foresta Proibita. Non aspettare, prenota ora e inizia il 
    tuo viaggio verso il castello più iconico del mondo magico! Hogwarts ti attende per darti il benvenuto nel suo regno incantato",
    
    "tasto_espandi_hp" => "Vedi nel dettaglio", 

    "posizione_hogwarts_hp" => "<strong>Posizione: </strong>Highlands scozzesi, Regno Unito", 
    
    "introduzione_hogwarts_hp" => "<strong>Introduzione: </strong>La Scuola di Magia e Stregoneria di Hogwarts è una scuola di magia situata in Scozia,
    che accoglie la maggior parte degli studenti delle Isole britanniche di età compresa tra gli undici e i diciassette anni.",
    
    "descrizione_totale_hogwarts_hp" => "Hogwarts venne fondata verso la fine del X secolo dai quattro maghi e streghe britannici più influenti del loro tempo, ovvero Godric Grifondoro,Tosca Tassorosso,Priscilla Corvonero e 
    Salazar Serpeverde,i quali divisero gli studenti in quattro casate che portavano i loro cognomi, ognuna con le sue caratteristiche.
    <ul>
        <li>La casa di Grifondoro valorizza coraggio, audacia e nobiltà d'animo</li>
        <li>La casa di Tassorosso richiede duro lavoro, pazienza, lealtà, giustizia e tenacia</li>
        <li>La casa di Corvonero dà grande valore a intelligenza, creatività, apprendimento e saggezza</li>
        <li>La casa di Serpeverde tiene in grande considerazione ambizione, astuzia e intraprendenza</li>
    </ul>
    Hogwarts è un grande castello che si trova in prossimità del villaggio di Hogsmade, sorge su una scogliera in riva ad un lago detto Lago nero, nel quale risiede una comunità di maridi, 
    una piovra gigante e numerose specie magiche acquatiche, essa inoltre è il luogo dove io(Harry) ho svolto la seconda prova del Torneo Tremaghi.
    Nelle vicinanze si estende un bosco vasto, tetro, pericoloso e interdetto agli studenti, chiamato Foresta proibita.
    La scuola è inoltre circondata da un ampio parco con prati, aiuole, orti, serre, un campo da quidditch e alcuni edifici minori, come la capanna del guardiacaccia Rubeus Hagrid.
    Per quanto riguarda l'edificio scolastico principale il castello ha sette piani e dei sotterranei, il tutto collegato da 142 scalinate, e ospita numerose aule, dormitori per gli 
    studenti e per il personale, sale comuni, cortili, corridoi, sale di rappresentanza, le cucine, una biblioteca e un'infermeria.
    Su alcune scalinate sono presenti gradini che scompaiono quando calpestati; inoltre, le stesse scale e alcune aule hanno la tendenza a spostarsi, 
    infatti, come si dice a Hogwarts \"alle scale piace cambiare\" dunque bisogna stare attenti ad orientarsi nel castello nella maniera giusta.
    Altra particolarità di Hogwarts sono alcuni passaggi segreti, sette in totale, che conducono fuori dal castello, o stanze misteriose, come la camera dei segreti o la Stanza delle necessità.
    Nessuno, si dice, è a conoscenza di tutti i misteri della scuola, sebbene il preside Albus Silente, il custode Argus Gazza e i gemelli Fred e George Weasley 
    ne abbiano una conoscenza molto approfondita.
    Hogwarts è avvolta da varie protezioni magiche. Alcune di queste servono a nascondere il castello e il parco ai babbani, i quali al loro posto vedono solo un cumulo di rovine
    e dei segnali di pericolo che dissuadono dall'avvicinarsi. La posizione esatta del castello è sconosciuta e non individuabile.
    Il motto che si legge nello stemma della scuola è Draco dormiens nunquam titillandus, che in latino significa \"Non stuzzicare il drago che dorme\".",
    
    "invito_prenotazione_hp" => "Prenota anche tu", 
    
    "nome_prenotazione_hp" => "Nome",
    
    "cognome_prenotazione_hp" => "Cognome",
    
    "data_partenza_hp" => "Da",
    
    "data_arrivo_hp" => "A",
    
    "tasto_invio_prenotazione_hp" => "invio",

    "tasto_go_back_hp" => "Torna indietro",
    
    "descrizione_breve_hogsmade_hp" => "Siamo pronti a darti il benvenuto nel villaggio di Hogsmade. Scopri 
    il primo e unico villaggio completamente magico in Gran Bretagna. Qui potrai 
    gustare un'ottima burrobirra alla Locanda dei Tre Manici di Scopa, potrai dirigerti all'Emporio di Scrivani e l'Iperbole per acquistare 
    oggetti magici, per poi fare un giro all'Emporio degli Scherzi di Zonko e vedere tanto altro ancora. Cosa stai aspettando? 
    Prenota ora il tuo viaggio per scoprire il villaggio più magico del Regno Unito e immergiti completamente nel mondo incantato di Harry Potter!",
    
    "posizione_hogsmade_hp" => "<strong>Posizione: </strong>Gran Bretagna, nelle vicinanze di Hogwarts", 
    
    "introduzione_hogsmade_hp" => "<strong>Introduzione: </strong>Hogsmeade è noto per essere l'unico centro abitato della Gran Bretagna popolato da soli maghi",
    
    "descrizione_totale_hogsmade_hp" => "Hogsmade venne fondata da Hengist il folletto dei boschi, che vi si rifugiò per sfuggire alle persecuzioni da parte dei babbani nel Northumberland.
    Il villaggio sorge molto vicino a Hogwarts, tanto che l'Espresso di Hogwarts fa capolinea alla stazione di Hogsmeade. Gli alunni a partire dal terzo anno, se in possesso di un'autorizzazione
    firmata da un genitore o un tutore, possono visitare il villaggio nei fine settimana, facendo acquisti nei vari negozi e svagandosi nei locali e pub.
    I negozi presetni a Hogsmade sono tanti e c'è molto da vedere ma tra i miei preferiti troviamo:
    <ul>
    <li>
        <strong>I tre manici di scopa</strong> <br>
        I Tre Manici di Scopa è un pub che funge anche da locanda, tra i più frequentati di Hogsmeade.
        Il locale ha una sala ampia, calda e confortevole.Oltre che dai maghi comuni il pub è molto frequentato da studenti, insegnanti e il personale di Hogwarts.
        La barista è Madama Rosmerta, una donna di bell'aspetto che suscita una notevole attrazione da parte dei clienti maschi del locale. Vi si possono bere molte bevande, tra
        cui la Burrobirra, bevanda famosissima e assolutamente da provare se ti trovi ad Hogsmade.
    </li>
    <br>

    <li>
        <strong>Mielandia</strong> <br>
        Mielandia è un negozio di dolci molto frequentato da noi studenti di Hogwarts. I proprietari Ambrosius Flume e la moglie vivono nel piano superiore dello stesso edificio.
        Vende un'enorme gamma di dolci magici molto particolari, come gelatine tuttigusti+1(molto buone ma attenzione, una caramella vomito può arrivare quando meno te l'aspetti), api
        frizzole, fildimenta interdentali, piperille nere, topoghiacci, rospi alla menta e tanto altro ancora.
        Se ti piacciono i dolci è una tappa che ti consiglio assolutamente di fare.
    </li>
    <br>

    <li>
        <strong>L'emporio degli scherzi di Zonko</strong> <br>
        Zonko è un negozio di scherzi, i cui articoli sono molto popolari tra noi studenti di Hogwarts.
        Potrai trovare articoli unici perfetto per fare uno scherzo divertente ai tuoi amici
    </li>
    </ul>",
    
    "descrizione_breve_diagonAlley_hp" => "Benvenuto nella magica Diagon Alley, la strada segreta situata dietro 
    il Calderone Fumante a Londra che porta al cuore del mondo magico. 
    Ti invitiamo a venire con noi in questo posto pieno di negozi magici. Potrai vedere dal vivo la Gringott's, da cui Harry Ron e 
    Hermione scapparono in groppa ad un drago, il Banco dei Maghi, il negozio di Olivander dove poter acquistare la tua bacchetta magica, e tanti altri negozi 
    dove poter fare i tuoi acquisti magici. Che aspetti?Prenota ora il tuo viaggio e preparati a scoprire i segreti nascosti di questa straordinaria via magica!",
    
    "posizione_diagonAlley_hp" => "<strong>Posizione: </strong>Londra, Regno Unito", 
    
    "introduzione_diagonAlley_hp" => "<strong>Introduzione: </strong>Diagon Alley è una via di Londra dove i maghi di tutta la Gran Bretagna fanno i loro acquisti in negozi di ogni genere",
    
    "descrizione_totale_diagonAlley_hp" => "Diagon Alley è una via nascosta alla popolazione babbana e vi si accede attraverso un passaggio nel retro del
    Paiolo Magico, oppure grazie alla Metropolvere o alla materializzazione.Oltre che essere una via piena di negozi dove i maghi fanno i loro acquisti magici a
    Diagon Alley ha sede la Gringott, la banca dei maghi, la stessa dalla quale io(Harry), Ron ed Hermione siamo scappati in volo su un drago.
    Tra le tappe più interessanti di Diagon Alley troviamo:
    <ul>
    <li>
        <strong>Gringott</strong> <br>
        La Gringott è la banca magica in cui maghi e streghe depositano i loro averi.
        Si presenta come un edificio bianco e imponente situato alla congiunzione di Notturn Alley e Diagon Alley.
        L'ingresso è delimitato da una doppia serie di portoni in bronzo e argento. L'atrio è lastricato in marmo ed è percorso da un lungo bancone al quale siedono numerosi impiegati e 
        dove avvengono le transazioni.
        La Gringott è gestita dai folletti, sebbene vi lavorino anche dipendenti umani, come Bill Weasley, che è impiegato come Spezzaincantesimi per conto della
        banca, o Fleur Delacour, che vi svolge un tirocinio al termine dei suoi studi per migliorare il suo inglese. 
        La banca è considerata uno dei luoghi più sicuri nel mondo magico. Le ricchezze dei clienti sono depositate in apposite camere blindate, tutte a prova di scasso e protette
        da sofisticati incantesimi di sicurezza, io stesso insieme ai miei amici ho potuto(io, Harry) testarlo quando dovevamo recuperare un horcrux di Voldemort dalla 
        camera blindata della famiglia Lestrange.
        Le camere si trovano sottoterra e si estendono per chilometri nel sottosuolo di Londra, in un labirinto di passaggi sotterranei e grotte.
        Le camere blindate più importanti, come quella della famiglia Lestrange, sono sorvegliate da draghi e sfingi. Per muoversi all'interno ci sono dei binari su cui
        viaggiano dei carrelli e per aprire le porte sono essenziali delle piccole chiavi d'oro, mentre alcune porte possono essere aperte toccandole solo dai folletti.
        Chiunque non sia un folletto della banca e provi a fare questo verrebbe rinchiuso dentro la camera per sempre.
    </li>
    <br>

    <li>
        <strong>Olivander</strong> <br>
        Olivander è il negozio di bacchette magiche di Garrick Olivander. Sembra non essere il solo negozio di bacchette magiche presente a Diagon Alley, anche
        se è certamente quello più conosciuto e apprezzato, nonchè quello dove sono andato io(Harry) a prendere la mia prima bacchetta magica.
        Il suo aspetto è però poco appariscente, con in vetrina solo una bacchetta adagiata su un cuscinetto sbiadito e impolverato, e l'interno composto da lunghe
        fila di scatole ammucchiate ordinatamente fino al soffitto.
        Olivander, i cui familiari sono fabbricanti di bacchette da secoli, ricorda le caratteristiche di ogni singola bacchetta che ha venduto negli anni.
        Vieni qui e anche tu potrai acquistare la tua bacchetta magica e ricorda, non siamo noi a scegliere la bacchetta ma è la bacchetta a scegliere il mago.
    </li>
    <br>

    <li>
        <strong>Tiri vispi Weasley</strong> <br>
        Tiri Vispi Weasley è il negozio di scherzi magici di Fred e George Weasley, situato al 93 di Diagon Alley.
        Il negozio comincia a prendere forma nelle loro idee già quando i due a scuola iniziano a inventare, produrre e trafficare sotto banco una serie di articoli
        scherzosi, ma è solo con la loro fuga da Hogwarts che possono aprire il negozio.
        Nonostante la morte di Fred durante la battaglia di Hogwarts, il negozio è stato portato avanti sotto la gestione del solo George.
        Il negozio rimane ancora oggi dunque una tappa molto bella da vedere dove prendere articoli geniali e unici nel loro genere
    </li>
    </ul>",

    "sezione_recensioni_hp" => "SEZIONE RECENSIONI",

    "inserisci_recensione_hp" => "Inserisci una recensione: ",

    "inserisci_stelle_hp" => "Inserisci un numero di stelle: ",

    "data_hp" => " in data ",

    "prenotazione_non_loggato" => "Per prenotare è necessario aver effettuato l'accesso",

    "recensioni_non_loggato_hp" => "Per poter inserire una recensione è necessario aver fatto l'accesso",

    "descrizione_iniziale_db" => "Benvenuto nell'incredibile universo di Dragon Ball! Qui, l'avventura prende vita sotto cieli vibranti e mondi fantastici. Inizia il tuo sulla mitica Terra, esplorando le montagne e le pianure che hanno dato i natali a me e i miei compagni d'avventura. Qui sotto potrai esplorare mondi adatti solo per chi ha una forza fisica e spirituale adatta. Affronterai intemperie, alta gravità e altre difficoltà utili per i tuoi allenamenti.",
    
    "scelta_db" => "Scegli la tua destinazione...",
    
    "breve_descrizione1_db" => "Visita Namecc, un mondo extrattereste dai colori peculiari, abitato da alieni molto ospitali, i Namecciani.
    Ha una struttura rocciosa e una gravità del tutto analoga a quella della Terra, ma la superficie del pianeta si presenta come
    un immenso unico oceano costellato da migliaia  di piccole isole ed isolotti.",
    
    "stanza_db" => "Stanza dello spirito e del tempo",
    
    "breve_descrizione2_db" => "Prenota un viaggio nella Stanza dello Spirito e del Tempo, situata al Tempio di Dio.
      Un anno dentro in quella stanza equivale a un solo giorno all'esterno. La gravità è dieci volte superiore alla norma.
    Molto utile se non vuoi sprecare <span>tempo</span>!",
    
    "torneo_db" => "Torneo Tenkaichi",
    
    "breve_descrizione3_db" => "Assisti ai migliori scontri del pianeta Terra, solo qui, al torneo più famoso di tutti. Incontrerai i migliori combattenti,
    perché non ti metti alla prova e partecipi anche tu?",
    
    "caratteristiche1_db" => "<strong>Pianeta:</strong> Namecc <br> <strong>Abitanti:</strong> Namecciani <br> <strong>Pericolo:</strong> basso",
    
    "descrizione_approfondita1_db" => "Si tratta di un pianeta di tipo terrestre.
      Ha una struttura rocciosa e una gravità del tutto analoga a quella della Terra, ma si differenzia sotto numerosi aspetti.
      La superficie del pianeta si presenta come un'immenso unico oceano costellato da migliaia e migliaia di piccole isole ed isolotti,
      alcune dei semplici scogli, altre invece più estese, ma non c'è traccia di quello che si potrebbe definire un continente.
      La vegetazione, sia gli arbusti che le piante, è di colore azzurro e l'atmosfera e il cielo sono di color verde.
      La maggior parte della fauna è costituita da pesci o anfibi, e le uniche creature animali che vivono sulla terraferma sembrano essere i Namecciani.
      Il pianeta orbita intorno a tre soli, cosicché su Namecc non cala mai la notte. Un'anno Namecciano, inoltre, è composto da 130 giorni terrestri.",
    
    "prenota_biglietto_db" => "Prenota il tuo biglietto...",
    
    "nome_db" => "Nome: ",
    
    "cognome_db" => "Cognome: ",
    
    "email_db" => "Email: ",
    
    "da_db" => "Da: ",
    
    "a_db" => "A: ",
    
    "caratteristiche2_db" => "<strong>Pianeta:</strong> Terra <br> <strong>Abitanti:</strong> nessuno <br> <strong>Pericolo:</strong> inesistente",
    
    "descrizione_approfondita2_db" => "La Stanza dello Spirito e del Tempo è un mondo vuoto, con un solo edificio, in cui vi è l'ingresso alla stanza,
       con un alloggio, dei viveri, bagni e camere da letto. Nella stanza non ci sono il giorno e la notte, ma nei dintorni è tutto bianco.
       La dilatazione temporale che si verifica nella Stanza dello Spirito e del Tempo è che una giornata fuori dalla stanza equivale a 1 anno dentro,
       o 1 minuto fuori sono circa 6 ore dentro. A destra e sinistra dell'edificio vi sono 2 clessidre di sabbia smeraldo, una che fa cadere la sabbia in basso e una in alto.
        Al centro della piccola cupola nell'edificio, vi è anche un orologio. La temperatura varia dai +60 gradi a -40 gradi.
        Grazie a questo, qualsiasi persona, entrando nella Stanza Speciale, può ottenere un anno interno di allenamento speciale e severo,
        lasciando che passino solo 24 ore nella realtà.",
    
    "caratteristiche3_db" => "<strong>Pianeta:</strong> Terra <br> <strong>Partecipanti:</strong> chiunque è ammesso <br> <strong>Pericolo:</strong> alto",
    
    "descrizione_approfondita3_db" => "Affrettati! Il Torneo ha luogo in uno stadio sull'Isola di Papaya, ogni tre anni.
       Le iscrizioni al torneo avvengono il giorno stesso dell'apertura, e sono aperte a guerrieri di ogni età e sesso.
      Il Torneo si suddivide in due fasi, quella delle eliminatorie, nelle quali tutti gli iscritti si sfidano in combattimenti a porte chiuse, e la fase delle finali,
        alla quale accedono gli otto finalisti emersi vincitori dalle eliminatorie.
        Il Torneo Tenkaichi è famoso per le incredibili abilità dei partecipanti, le mosse spettacolari e le strategie di combattimento uniche. Alcuni dei personaggi più
         iconici di Dragon Ball hanno partecipato a questo torneo, come Goku, Piccolo, Vegeta, e molti altri. Durante il torneo, i partecipanti sono soggetti a regole
         specifiche, come la proibizione dell'uso di armi e la necessità di restare all'interno dell'arena.
         Prenotati anche tu, e decidi se essere uno spettatore o un partecipante!",
    
    "recensione_db" => "Lascia una recensione",
    
    "torna_indietro" => "Torna indietro",
    
    "invia_prenotazione" => "Invia prenotazione",

	
	"descrizioneAutoreSP" => "Ciao visitatore! Io e il mio fedele e migliore amico Patrick Stella siamo pronti a guidarti e mostrarti bellissimi luoghi abissali di Bikini Bottom. Più sotto troverai Destinazioni Popolari con le relative informazioni, Recensioni & Commenti e tanto altro! Se ancora non l'hai fatto accedi/registrati per scoprire offerte e prodotti imperdibili, ti aspetto!",
	
    "destinazioniPopolariSP" => "Destinazioni Popolari",
	
    "destinazioneBBSP" => "Esplora la città sottomarina di Spongebob e i suoi amici.",
	
    "destinazioneKKSP" => "Gusta il famoso Krabby Patty al ristorante di Spongebob.",
	
    "destinazioneGWSP" => "Divertiti con le giostre e le attrazioni al parco divertimenti.",
	
    "destinazioneVCSP" => "Alloggia nelle case protagoniste e amate di tutta Bikini Bottom.",
	
    "breveDescrizioneDettagliBBSP" => "Città situata sul fondo dell' Oceano Pacifico",
	
    "breveDescrizioneDettagliKKSP" => "Ristorante fast food",
	
    "breveDescrizioneDettagliGWSP" => "Parco divertimenti",
	
    "breveDescrizioneDettagliVCSP" => "Quartiere principale",
	
    "descrizioneProfondaBBSP" => "Bikini Bottom è una città sottomarina e il principale scenario della serie animata SpongeBob SquarePants È situata sul fondale marino dell'Oceano Pacifico, ed è il luogo di residenza dei protagonisti della serie, tra cui SpongeBob SquarePants, Patrick Star, Squidward Tentacles e Sandy Cheeks. La città è caratterizzata da una vibrante miscela di paesaggi marini e di strani habitat subacquei, che vanno dalle profondità oscure degli abissi alle più luminose e colorate barriere coralline. Bikini Bottom è costituita da una varietà di quartieri e luoghi iconici, ciascuno con la propria personalità e atmosfera unica. Cosa aspetti prenotati!",
	
    "descrizioneProfondaKKSP" => "Il Krusty Krab è un'iconica istituzione culinaria situata a Bikini Bottom. La struttura esterna ricorda le sembianze di un vecchio barile di aragosta. L'interno è caratterizzato da colori vivaci e luminosi, con un tema marino che include decorazioni come reti da pesca, timoni e dipinti di creature marine. La cucina è gestita dallo chef SpongeBob SquarePants ed è il cuore pulsante dell'operazione del Krusty Krab, dove vengono preparati i famosi Krabby Patty(un hamburger di qualità superiore preparato con ingredienti segreti e amato da tutti i residenti di Bikini Bottom)",
	
    "descrizioneProfondaGWSP" => "Glove World è un parco divertimenti tematico ed è uno dei luoghi più iconici e memorabili di Bikini Bottom, attirando visitatori da tutta la città sottomarina e oltre. Glove World è ispirato al concetto di guanto, con molti degli elementi del parco che richiamano l'idea di guanti e mani. è caratterizzata da torri a forma di dita di guanto, ingressi a forma di mano e decorazioni che richiamano guanti di varie forme e dimensioni. L'intero parco è progettato per creare un'atmosfera divertente e giocosa. Glove World offre una vasta gamma di attrazioni e giochi per divertire i suoi visitatori e una varietà di punti di ristoro e negozi che vendono souvenir a tema guanto e cibo divertente come il famoso Glove Burger(hamburger e patatine a tema guanto) ed il Finger Hat Stand(cappelli a forma di dita di guanto in una varietà di colori e stili)",
	
    "descrizioneProfondaVCSP" => "Via della Conchiglia è una delle strade più iconiche e caratteristiche di Bikini Bottom La sua posizione centrale la rende un punto di riferimento importante per i residenti della città. L'aspetto della strada è caratterizzato da una serie di edifici colorati e un'ampia varietà di attività commerciali lungo i suoi lati. È spesso mostrata con una vivace atmosfera e un via vai costante di personaggi. Lungo Via della Conchiglia si trovano una varietà di negozi, ristoranti e altre attività commerciali. Ci sono botteghe di souvenir che vendono articoli a tema marino, come conchiglie, giocattoli e oggetti decorativi. Inoltre, ci sono caffè e ristoranti che offrono cibo e bevande per i residenti e i visitatori di Bikini Bottom. Alcuni dei negozi più iconici includono il negozio di burattini di giocattoli, la gelateria e la bancarella di popcorn. Via della Conchiglia è anche sede di numerose abitazioni e case. Queste dimore spesso presentano una varietà di stili architettonici e design, da casette di legno a edifici più elaborati. Alcuni dei personaggi principali della serie vivono lungo questa strada o nelle vicinanze.",
	
    "prenotazioneSP" => "Prenotazione",
	
    "nomeSP" => "Nome",
	
    "dataArrivoSP" => "Data di arrivo",
	
    "dataPartenzaSP" => "Data di partenza",
	
    "prenotaSP" => "Prenota",
	
    "bottoneIndietroSP" => "Torna Indietro",
	
    "sezioneRecensioniSP" => "Recensioni & commenti",
	
    "aggiungiCommentoSP" => "Aggiungi un commento",
	
    "scriviCommentoSP" => "Scrivi Commento",
	
    "inviaCommentoSP" => "Invia Commento",
	
    "ringraziamentoRecensioneSP" => "Grazie per aver lasciato la tua recensione, a presto!",
	
    "article_migliorirecensioni_table_caption_titolo_sec" => "Migliori Recensioni",
	
    "article_migliorirecensioni_table_thead_r1c1" => "Voto Stella",
	
    "article_migliorirecensioni_table_thead_r1c2" => "Migliori 3 Commenti",
	
    "article_migliorirecensioni_table_tbody_p" => "Scegli Voto Stella",
	
    "accessoNecessarioSP" => "È necessario accedere per la visualizzazione !",

    //Dizionario login 
    "registrazione_login" => "Registrazione",

    "nome_login" => "Nome",

    "cognome_login" => "Cognome",

    "sesso_login" => "Sesso",

    "data_login" => "Data di nascita",

    "username_login" => "Nome utente",

    "email_login" => "Indirizzo e-mail",

    "conf_login" => "Conferma password",

    "submit_login" => "Invia",

    "linkAcc_login" => "Sei già registrato? <a href='?reg=true&lan=".$lan."'>Accedi</a>",

    "trascina_foto_login" => "Trascina l'immagine da usare come foto profilo",

    "linkReg_login" => "Non hai un account? <a href='?reg=false&lan=".$lan."'>Registrati</a>",

    "non_corrisponde_login" => "*Le due password non corrispondono",

    "utenteReg_login" => "Utente, registrato!",

    "caratteri_speciali_nome_cognome_login" => "*Nome e Cognome non devono contenere numeri o caratteri speciali",

    "valida_mail_login" => "*Inserire una mail con dominio gmail.com ,outlook.com o studenti.unisa.it",

    "criteri_password_login" => "*La password deve contenere un minimo di 8 e un massimo di 16 caratteri, inoltre deve contenere almeno una lettera minuscola, una lettera maiuscola e un carattere speciale",

    "accesso_login" => "Accesso",

    "accesso_effettuato_login" => "Accesso effettuato, vai alla <a href='../homepage/homepage.php?lan=". $lan."'>homepage</a>",

    "benvenuto_accesso_login" => "Benvenuto ",

    "password_errata_accesso_login" => "Password errata",

    "email_esistente_accesso_login" => "Email inesistente",

    "tasto_accedi" => "ACCEDI O REGISTRATI",

    //Dizionario Homepage
    "header_searchForm_input_placeholder" => "Cerca..",
    
    "header_searchForm_button_value" => "INVIA",
    
    "header_accessForm_button_value" => "ACCEDI O REGISTARTI",
    
    "footer_adviceForm_p" => "Inviaci una mail, suggerendoci..",
    
    "footer_adviceForm_ol_li1_p" => "..un nuovo <span>universo</span>:",
    
    "footer_adviceForm_ol_li1_button_value" => "INVIA",
    
    "footer_adviceForm_ol_li2_p" => "..o una nuova <span>meta</span>:",
    
    "footer_adviceForm_ol_li2_button_value" => "INVIA",
    
    "footer_adviceForm_ol_li3_p" => "Grazie, la mail sta per essere inviata!",
    
    "footer_aboutus_p_chisiamo" => "CHI SIAMO",
    
    "footer_aboutus_p_testoaboutus" => "Siamo Antonio, Francesco, Alessandro e Luigi, quattro studenti iscritti alla facoltà di Ingegneria Informatica dell'Università di Salerno che stanno per sostenere l'esame di \"Tecnologie Software per il Web\". Quello che vedete è il risultato del nostro progetto, speriamo sia di vostro gradimento!",
    
    "aside_p_titaside" => "SCORRI LA PAGINA E SCOPRI COSA C'&Egrave SOTTO OGNUNO DI QUESTI REGALI!",
    
    "aside_narr_p_txtdbz" => "Ehilà! Sono Goku, il campione della giustizia e il difensore del nostro universo! Puoi chiamarmi anche Kakarot, il mio nome da Sayan. Se andrai nel mio universo, ti farò da guida!",
    
    "aside_narr_p_txtspsq" => "Sono SpongeBob, la spugna più felice e allegra di tutta Bikini Bottom! Sono qui per condurti in un'avventura sottomarina che non dimenticherai. Presto.. seguimi amico mio!",
    
    "aside_narr_p_txthp" => "Mi chiamo Harry Potter, un piacere conoscerti! Sono qui per accompagnarti nel magico mondo di Hogwarts e oltre. Preparati a esplorare insieme a me i segreti dell'arte della magia!",
    
    "section_metepiuvisitate_div_titololpv_h2" => "METE PI&Ugrave VISITATE",
    
    "section_offertepromo_div_titoloofp_h2" => "OFFERTE E PROMOZIONI",
    
    "section_eventidata_legend_titolosec" => "<strong>INSERISCI IL PERIODO E SCOPRI L'EVENTO CORRISPONDENTE!</strong>",
    
    "section_eventidata_p" => "<strong>Funzione disabilitata!</strong>",
    
    "section_eventidata_form_p_pbottoni_input1" => "INSERISCI",
    
    "section_eventidata_form_p_pbottoni_input2" => "CANCELLA",
    
    "article_migliorirecensioni_table_caption_titolo_sec" => "<strong>RECENSIONI UNIVERSI</strong>",
    
    "article_migliorirecensioni_table_thead_r1c1" => "VALUTAZIONE",
    
    "article_migliorirecensioni_table_thead_r1c2" => "ULTIME TRE",
    
    "article_migliorirecensioni_table_tbody_p" => "<strong>Filtra in base <br> alle stelle:</strong>",
    
    "article_migliorirecensioni_table_tbody_p_extra" => "<strong>Non puoi filtrare per <br> valutazione!</strong>",

    "offerte_non_loggato" => "Accedi o registrati per poter visualizzare le offerte!",

    "bottone_info_utente" => "Informazioni Utente",

    "bottone_chiudi_scheda" => "Chiudi scheda",

    "scheda_utente" => "Scheda Utente");
?>
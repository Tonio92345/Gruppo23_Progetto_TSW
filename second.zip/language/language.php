<?php
    $language = array("it"=>"it.php", "en"=>"en.php", "fr"=>"fr.php");

    if(isset($_GET['lan'])){
        $lan = $_GET['lan'];
    }
    else{
        $lan = "it";
    }
    if($lan == "it"){
        require ($language['it']);
    }
    if($lan == "en"){
        require ($language['en']);
    }
    if($lan == "fr"){
        require ($language['fr']);
    }

?>
<?php
    $dizionario = array("descrizione_iniziale_hp" => "Welcome to my Universe, an enchanted world of magic, adventure and wonder!
    Come with me and let's explore this extraordinary universe, 
    where fantastic creatures, powerful spells and epic adventures await you at every turn.", 

    "animazione_non_supportata_hp" => "The animation that was supposed to be present here is not supported by the browser you were using",

    "descrizione_breve_hogwarts_hp" => "Experience the magical adventure of Hogwarts Castle. Explore one of the most magical places 
    never existed, you can walk through the ancient corridors of the castle, explore enchanted classrooms breathe the air full of history and magic. 
    Inside, you will find the Great Hall with 
    its four distinctive houses, classrooms like the class of Potions and Transfiguration, 
    and iconic places like the Clock Tower and the Forbidden Forest. Don't wait, book now and start the 
    your journey to the most iconic castle in the magical world! Hogwarts awaits you to welcome you to his enchanted kingdom",
    
    "tasto_espandi_hp" => "See in detail", 

    "posizione_hogwarts_hp" => "<strong>Position: </strong>Scottish Highlands, United Kingdom", 
    
    "introduzione_hogwarts_hp" => "<strong>Introduction: </strong>The Hogwarts School of Magic and Witchcraft is a school of magic located in Scotland,
    The British Government, which receives the majority of students in the British Isles aged between 11 and 17.",
    
    "descrizione_totale_hogwarts_hp" => "Hogwarts was founded in the late 10th century by the four most influential British magicians and witches of their time, namely
    Godric Gryffindor, Tosca Tassorosso, Priscilla Corvonero and Salazar Serpeverde, who divided the students into four families bearing their surnames, each with its own characteristics.
    <ul>
        <li>The house of Gryffindor enhances courage, boldness and nobility of mind</li>
        <li>The house of Hufflepuff requires hard work, patience, loyalty, justice and tenacity</li>
        <li>Corvonero's house gives great value to intelligence, creativity, learning and wisdom</li>
        <li>Serpeverde's house values ambition, cunning and resourcefulness</li>
    </ul>
    Hogwarts is a large castle that is located near the village of Hogsmade, stands on a cliff on the shore of a lake called Black Lake, in which resides a community of maridi, 
    a giant octopus and numerous magical aquatic species, it is also the place where I (Harry) played the second test of the Tournament Tremaghi.
    Nearby stretches a vast, bleak, dangerous and forbidden forest to students, called Forbidden Forest.
    The school is also surrounded by a large park with lawns, flower beds, vegetable gardens, greenhouses, a Quidditch field and some minor buildings, such as the hut of the gamekeeper Rubeus Hagrid.
    As for the main school building, the castle has seven floors and underground, all connected by 142 staircases, and houses numerous classrooms, dormitories for 
    students and staff, common rooms, courtyards, corridors, boardrooms, kitchens, a library and an infirmary.
    On some staircases there are steps that disappear when stepped; moreover, the same stairs and some classrooms have a tendency to move, 
    In fact, as Hogwarts says, \"the stairs like to change\" so you have to be careful to orient yourself in the castle in the right way.
    Other peculiarities of Hogwarts are some secret passages, seven in total, leading out of the castle, or mysterious rooms, such as the chamber of secrets or the Room of Need.
    Nobody, it is said, is aware of all the mysteries of the school, although the principal Albus Dumbledore, the custodian Argus Magpie and twins Fred and George Weasley 
    have a very thorough knowledge of them.
    Hogwarts is wrapped in various magical protections. Some of these serve to hide the castle and the park to the Babbani, who in their place see only a heap of ruins
    and warning signs that deter you from approaching. The exact location of the castle is unknown and undetectable.
    The motto that reads in the coat of arms of the school is Draco dormiens nunquam titillandus, which in Latin means  \"Do not tease the sleeping dragon\".",
     
    "invito_prenotazione_hp" => "Let's book", 
    
    "nome_prenotazione_hp" => "Name",
    
    "cognome_prenotazione_hp" => "Surname",
    
    "data_partenza_hp" => "From",
    
    "data_arrivo_hp" => "To",
    
    "tasto_invio_prenotazione_hp" => "submit",

    "tasto_go_back_hp" => "Go back",
    
    "descrizione_breve_hogsmade_hp" => "We are ready to welcome you to the village of Hogsmade. Discover 
    the first and only fully magical village in Britain. Here you can 
    enjoy an excellent burrobirra at the Locanda dei Tre Manici di Scopa, you can head to the Emporium of Scrivani and Iperbole to buy 
    magic items, and then take a tour of Zonko's Prank Emporium and see more. What are you waiting for? 
    Book your trip now to discover the most magical village in the UK and completely immerse yourself in the enchanted world of Harry Potter!",
    
    "posizione_hogsmade_hp" => "<strong>Position: </strong>Great Britain, near Hogwarts", 
    
    "introduzione_hogsmade_hp" => "<strong>Introduction: </strong>Hogsmeade is known to be the only settlement in Britain populated by wizards",
    
    "descrizione_totale_hogsmade_hp" => "The village was founded by Hengist the leprechaun of the woods, who took refuge there to escape persecution by the Babbans in Northumberland.
    The village is located very close to Hogwarts, so much so that the Hogwarts Express ends at Hogsmeade station. Pupils from the third year onwards, if they have a permit
    signed by a parent or a guardian, they can visit the village on weekends, shopping in various shops and having fun in pubs and clubs.
    There are many preset shops in Hogsmade and there is a lot to see but among my favorites we find:
    <ul>
    <li>
        <strong>The Three Broomsticks</strong> <br>
        The Three Broomsticks is a pub that also serves as an inn, one of the busiest in Hogsmeade.
        The restaurant has a large room, warm and comfortable.In addition to the common magicians the pub is very popular with students, teachers and staff of Hogwarts.
        The bartender is Madame Rosmerta, a good-looking woman who arouses considerable attraction from the male customers of the restaurant. There you can drink many drinks, including
        Burrobirra, famous drink and a must try if you are in Hogsmade.
    </li>
    <br>

    <li>
        <strong>Honeydukes</strong> <br>
        Mielandia is a sweet shop very frequented by us students of Hogwarts. The owners Ambrosius Flume and his wife live in the upper floor of the same building.
        It sells a huge range of very special magical sweets, such as all creams + 1 (very good but beware, a vomit candy can come when you least expect it), bees
        frizzole, interdental fildimenta, black piperille, topoghiacci, mint toads and much more.
        If you like sweets is a step that I absolutely recommend to do.
    </li>
    <br>

    <li>
        <strong>Zonko's Joke Shop</strong> <br>
        Zonko is a joke shop, whose items are very popular among us students of Hogwarts.
        You will find unique items perfect for making a fun joke to your friends
    </li>
    </ul>",
    
    "descrizione_breve_diagonAlley_hp" => "Welcome to the magical Diagon Alley, the secret street behind 
    The Steaming Cauldron in London that leads to the heart of the magical world. 
    We invite you to come with us to this place full of magical shops. You can see live Gringott's, from which Harry Ron and 
    Hermione escaped on a dragon, the Banco dei Maghi, Olivander's shop where you can buy your magic wand, and many other shops 
    where you can make your magic purchases. What are you waiting for? Book your trip now and get ready to discover the hidden secrets of this extraordinary magical route!",
    
    "posizione_diagonAlley_hp" => "<strong>Position: </strong>London, United Kindom", 
    
    "introduzione_diagonAlley_hp" => "<strong>Introduction: </strong>Diagon Alley is a street in London where wizards from all over Britain shop in all kinds of shops",
    
    "descrizione_totale_diagonAlley_hp" => "Diagon Alley is a hidden street to the Muggle people and is accessed through a passage in the back of the
    Paiolo Magico, or thanks to the Metropolvere or materialization. In addition to being a street full of shops where magicians make their magical purchases at
    Diagon Alley is home to the Gringotts, the magician's bank, the same bank from which I (Harry), Ron and Hermione escaped in flight on a dragon.
    Among the most interesting stages of Diagon Alley we find:
    <ul>
    <li>
        <strong>Gringott</strong> <br>
        The Gringott is the magic bank where wizaeds and witches deposit their belongings.
        It looks like a white and imposing building located at the junction of Nocturnal Alley and Diagon Alley.
        The entrance is bordered by a double series of doors in bronze and silver. The atrium is paved in marble and is crossed by a long counter where many employees and 
        where the transactions take place.
        The Gringott is run by leprechauns, though there are also human employees, such as Bill Weasley, who is employed as Spell Breaker on behalf of the
        bank, or Fleur Delacour, who carries out an internship there at the end of his studies to improve his English. 
        The bank is considered one of the safest places in the magical world. The riches of the customers are deposited in special vaults, all of which are safe and protected
        by sophisticated security spells, myself along with my friends I could(I, Harry) test it when we had to retrieve a Horcrux of Voldemort from the 
        Security room of the Lestrange family.
        The rooms are located underground and stretch for miles underground in London, in a maze of underground passages and caves.
        The most important vaults, such as the Lestrange family, are guarded by dragons and sphinxes. To move inside there are tracks on which
        trolleys travel and to open the doors are essential small golden keys, while some doors can be opened by touching them only by goblins.
        Anyone who is not a bank leprechaun and tries to do this would be locked inside the room forever.
    </li>
    <br>

    <li>
        <strong>Olivander</strong> <br>
        Olivander is Garrick Olivander's magic wand shop. It seems not to be the only magic wand shop in Diagon Alley, also
        if it is certainly the most known and appreciated, as well as the one where I went (Harry) to take my first magic wand.
        Its appearance, however, is inconspicuous, with in the showcase only a rod laid on a pad faded and dusty, and the interior consists of long
        row of boxes stacked neatly up to the ceiling.
        Olivander, whose family members have been making chopsticks for centuries, recalls the characteristics of every single wand he has sold over the years.
        Come here and you too can buy your magic wand and remember, we do not choose the wand but the wand to choose the magician.
    </li>
    <br>

    <li>
        <strong>Brisk shots Weasley</strong> <br>
        Vispi Weasley is Fred and George Weasley's magic prank shop, located at 93 Diagon Alley.
        The store begins to take shape in their ideas already when the two at school begin to invent, produce and traffic under the counter a series of items
        but it is only with their escape from Hogwarts that they can open the store.
        Despite Fred's death during the Battle of Hogwarts, the store was carried out under the management of only George.
        The store remains therefore a very nice stop to see where to get brilliant and unique items
    </li>
    </ul>",

    "sezione_recensioni_hp" => "REVIEW SECTION",

    "inserisci_recensione_hp" => "Post a review: ",

    "inserisci_stelle_hp" => "Enter a number of stars: ",

    "data_hp" => " on ",

    "recensioni_non_loggato_hp" => "You must be logged in to post a review",

    "prenotazione_non_loggato" => "To book you must be logged in",

    "descrizione_iniziale_db" => "Welcome to the incredible universe of Dragon Ball! Here, adventure comes to life under vibrant skies and fantastic worlds. Start yours on the mythical Earth, exploring the mountains and plains that gave birth to me and my fellow adventurers. Below you can explore worlds that are only suitable for those with suitable physical and spiritual strength. You will face bad weather, high severity and other difficulties useful for your workouts.",
    
    "scelta_db" => "Choose your destination...",
    
    "breve_descrizione1_db" => "Visit Namek, a world extrattereste with peculiar colors, inhabited by very hospitable aliens, the Nameks.
    It has a rocky structure and a gravity quite similar to that of the Earth, but the surface of the planet looks like
    an immense single ocean dotted with thousands of small islands and islets.",
    
    "stanza_db" => "Room of spirit and time",
    
    "breve_descrizione2_db" => "Book a trip to the Room of Spirit and Time, located at the Temple of God.
      One year inside that room is equivalent to one day outside. Gravity is ten times the norm.
    Very useful if you don’t want to waste <span>time</span>!",
    
    "torneo_db" => "Tenkaichi Tournament",
    
    "breve_descrizione3_db" => "Witness the best fights on planet Earth, only here, at the most famous tournament of all. You will meet the best fighters,
    Why don’t you test yourself and join in?",
    
    "caratteristiche1_db" => "<strong>Planet:</strong> Namecc <br> <strong>Viallagers:</strong> Namecciani <br> <strong>Danger:</strong> low",
    
    "descrizione_approfondita1_db" => "It is an Earth-like planet.
      It has a rocky structure and a gravity similar to that of the Earth, but differs in many respects.
      The surface of the planet looks like an immense single ocean dotted with thousands and thousands of small islands and islets,
      some of the simple rocks, others more extended, but there is no trace of what could be called a continent.
      The vegetation, both the shrubs and the plants, is blue and the atmosphere and the sky are green.
      Most of the fauna consists of fish or amphibians, and the only animal creatures living on land seem to be the Nameks.
      The planet orbits around three suns, so that night never falls on Namek. A Namek year also consists of 130 Earth days.",
    
    "prenota_biglietto_db" => "Get your ticket now.",
    
    "nome_db" => "Name: ",
    
    "cognome_db" => "Surname: ",
    
    "email_db" => "Email: ",
    
    "da_db" => "From: ",
    
    "a_db" => "To: ",
    
    "caratteristiche2_db" => "<strong>Planet:</strong> Earth <br> <strong>Villagers:</strong> nobody <br> <strong>Danger:</strong> nonexistent",
    
    "descrizione_approfondita2_db" => "The Room of Spirit and Time is an empty world, with only one building, where there is the entrance to the room,
       with accommodation, food, bathrooms and bedrooms. In the room there are no day and night, but in the surroundings everything is white.
       The time dilation that occurs in the Room of Spirit and Time is that a day outside the room is equivalent to 1 year inside,
       or 1 minute out is about 6 hours in. To the right and left of the building there are 2 hourglasses of emerald sand, one that makes the sand fall down and one at the top.
        At the center of the small dome in the building, there is also a clock. The temperature varies from +60 degrees to -40 degrees.
        Thanks to this, any person, entering the Special Room, can get an internal year of special and strict training,
        leaving only 24 hours in reality.",
    
    "caratteristiche3_db" => "<strong>Planet:</strong> Earth <br> <strong>Participants:</strong> anyone is allowed <br> <strong>Danger:</strong> high",
    
    "descrizione_approfondita3_db" => "Hurry! The Tournament takes place in a stadium on Papaya Island, every three years.
       Tournament registrations take place on the day of the opening, and are open to warriors of all ages and genders.
      The Tournament is divided into two phases, that of the preliminary, in which all the members compete in fights behind closed doors, and the stage of the finals,
        which is accessed by the eight finalists who emerged winners from the eliminations.
        The Tenkaichi Tournament is famous for its participants' incredible abilities, spectacular moves and unique combat strategies. Some of the most
         Dragon Ball’s iconic have participated in this tournament, such as Goku, Piccolo, Vegeta, and many more. During the tournament, participants are subject to rules
         specifications, such as the prohibition of the use of weapons and the need to stay inside the arena.
         Book yourself, and decide whether to be a spectator or a participant!",
    
    "recensione_db" => "Write a review",
    
    "torna_indietro" => "Back",
    
    "invia_prenotazione" => "Send booking",

	
	"descrizioneAutoreSP" => "Hello visitor! My faithful and best friend Patrick Star and I are ready to guide you and show you the beautiful underwater places of Bikini Bottom. Below you will find Popular Destinations with their information, Reviews & Comments, and much more! If you haven't already, login/register to discover unbeatable offers and products. I'm waiting for you!",
	
    "destinazioniPopolariSP" => "Popular Destinations",
	
    "destinazioneBBSP" => "Explore the underwater city of SpongeBob and his friends.",
	
    "destinazioneKKSP" => "Enjoy the famous Krabby Patty at SpongeBob's restaurant.",
	
    "destinazioneGWSP" => "Have fun with rides and attractions at the amusement park.",
	
    "destinazioneVCSP" => "Stay in the beloved and iconic homes throughout Bikini Bottom.",
	
    "breveDescrizioneDettagliBBSP" => "City located at the bottom of the Pacific Ocean.",
	
    "breveDescrizioneDettagliKKSP" => "Fast food restaurant",
	
    "breveDescrizioneDettagliGWSP" => "Amusement park",
	
    "breveDescrizioneDettagliVCSP" => "Main district",
	
    "descrizioneProfondaBBSP" => "Bikini Bottom is an underwater city and the main setting of the animated series SpongeBob SquarePants. It is located on the ocean floor of the Pacific Ocean and is the residence of the series' main characters, including SpongeBob SquarePants, Patrick Star, Squidward Tentacles, and Sandy Cheeks. The city is characterized by a vibrant mixture of marine landscapes and quirky underwater habitats, ranging from the dark depths of the abyss to the bright and colorful coral reefs. Bikini Bottom consists of a variety of neighborhoods and iconic locations, each with its own personality and unique atmosphere. What are you waiting for? Book now!",
	
    "descrizioneProfondaKKSP" => "The Krusty Krab is an iconic culinary institution located in Bikini Bottom. The exterior structure resembles the shape of an old lobster trap. The interior is characterized by vibrant and bright colors, with a marine theme that includes decorations such as fishing nets, ship wheels, and paintings of marine creatures. The kitchen is run by chef SpongeBob SquarePants and is the bustling heart of the Krusty Krab operation, where the famous Krabby Patty (a high-quality hamburger prepared with secret ingredients and beloved by all residents of Bikini Bottom) is prepared.",
	
    "descrizioneProfondaGWSP" => "Glove World is a themed amusement park and is one of the most iconic and memorable places in Bikini Bottom, attracting visitors from all over the underwater city and beyond. Inspired by the concept of gloves, Glove World features many elements throughout the park that evoke the idea of gloves and hands. It is characterized by tower structures shaped like glove fingers, entrances resembling hands, and decorations reminiscent of gloves of various shapes and sizes. The entire park is designed to create a fun and playful atmosphere. Glove World offers a wide range of attractions and games to entertain its visitors, as well as a variety of dining options and shops selling glove-themed souvenirs and fun food items such as the famous Glove Burger (hamburgers and fries with a glove theme) and the Finger Hat Stand (glove finger-shaped hats in a variety of colors and styles).",
	
    "descrizioneProfondaVCSP" => "Via della Conchiglia is one of the most iconic and characteristic streets of Bikini Bottom. Its central location makes it an important landmark for the city's residents. The street's appearance is characterized by a series of colorful buildings and a wide variety of commercial activities along its sides. It is often depicted with a lively atmosphere and a constant flow of characters. Along Via della Conchiglia, you'll find a variety of shops, restaurants, and other commercial establishments. There are souvenir shops selling marine-themed items like shells, toys, and decorative objects. Additionally, there are cafes and restaurants offering food and drinks for the residents and visitors of Bikini Bottom. Some of the most iconic shops include the toy puppet store, the ice cream parlor, and the popcorn stand. Via della Conchiglia is also home to numerous residences and houses. These homes often feature a variety of architectural styles and designs, ranging from wooden cottages to more elaborate buildings. Some of the main characters of the series live along this street or in the vicinity.",
	
    "prenotazioneSP" => "Booking",
	
    "nomeSP" => "Name",
	
    "dataArrivoSP" => "Arrival date",
	
    "dataPartenzaSP" => "Departure date",
	
    "prenotaSP" => "Book",
	
    "bottoneIndietroSP" => "Go back",
	
    "sezioneRecensioniSP" => "Reviews and Comments",
	
    "aggiungiCommentoSP" => "Add a comment",
	
    "scriviCommentoSP" => "Write Comment",
	
    "inviaCommentoSP" => "Send Comment",
	
    "ringraziamentoRecensioneSP" => "Thank you for leaving your review, see you soon!",
	
    "article_migliorirecensioni_table_caption_titolo_sec" => "Best Reviews",
	
    "article_migliorirecensioni_table_thead_r1c1" => "Star Rating",
	
    "article_migliorirecensioni_table_thead_r1c2" => "Top 3 Comments",
	
    "article_migliorirecensioni_table_tbody_p" => "Choose Star Rating",
	
    "accessoNecessarioSP" => "Login required for viewing!",

    //Dizionario login
    "registrazione_login" => "Registration",

    "nome_login" => "Name",

    "cognome_login" => "Surname",

    "sesso_login" => "Sex",

    "data_login" => "Date of birth",

    "username_login" => "Username",

    "email_login" => "E-mail address",

    "conf_login" => "Confirm password",

    "submit_login" => "Submit",

    "linkAcc_login" => "Already registered? <a href='? reg=true&lan=". $lan." '>Login</a>",

    "trascina_foto_login" => "Drag the image to use as a profile photo",

    "linkReg_login" => "Don't have an account? <a href='? reg=false&lan=". $lan." '>Register</a>",

    "non_corrisponde_login" => "*The two passwords do not match",

    "utenteReg_login" => "Registered user!",

    "caratteri_speciali_nome_cognome_login" => "*Name and Surname must not contain numbers or special characters",

    "valida_mail_login" => "*Enter an email with domain gmail.com ,outlook.com or students.unisa.it",

    "criteri_password_login" => "*The password must contain a minimum of 8 and a maximum of 16 characters, it must also contain at least a lowercase letter, a capital letter and a special character",

    "accesso_login" => "Login",

    "accesso_effettuato_login" => "Successfully logged in, go to <a href='../homepage/homepage.php?lan=". $lan."'>homepage</a>",

    "benvenuto_accesso_login" => "Welcome ",

    "password_errata_accesso_login" => "Wrong password",

    "email_esistente_accesso_login" => "Non-existent email",

    "tasto_accedi" => "LOGIN OR REGISTER",

    //Dizionario Homepage
    "header_searchForm_input_placeholder" => "Search..",
    
    "header_searchForm_button_value" => "SUBMIT",
    
    "header_accessForm_button_value" => "LOGIN OR REGISTER",
    
    "footer_adviceForm_p" => "Send us an email, suggesting..",
    
    "footer_adviceForm_ol_li1_p" => "..a new <span>universe</span>:",
    
    "footer_adviceForm_ol_li1_button_value" => "INVIA",
    
    "footer_adviceForm_ol_li2_p" => "..or a new <span>destination</span>:",
    
    "footer_adviceForm_ol_li2_button_value" => "SUBMIT",
    
    "footer_adviceForm_ol_li3_p" => "Thanks, the email is coing to be sent!",
    
    "footer_aboutus_p_chisiamo" => "ABOUT US",
    
    "footer_aboutus_p_testoaboutus" => "We are Antonio, Francesco, Alessandro and Luigi, four students enrolled in the faculty of Computer Engineering of the University of Salerno who are about to take an exam named \"TSW\". What you see here is the result of our project, we hope <br> you like it!",
    
    "aside_p_titaside" => "SCROLL THROUGH THE PAGE AND FIND OUT WHAT’S INSIDE THE GIFTS!",
    
    "aside_narr_p_txtdbz" => "Hello! I am Goku, the champion of justice and the defender of our universe! You can also call me Kakarotto, my Saiyan name. If you go to my universe, I’ll be your guide!",
    
    "aside_narr_p_txtspsq" => "I’m SpongeBob, the happiest and happiest sponge in all of Bikini Bottom! I’m here to take you on an underwater adventure that you won’t forget. Quick. Follow me, <br> my friend!",
    
    "aside_narr_p_txthp" => "My name is Harry Potter, a pleasure to meet you! I am here to accompany you to the magical world of Hogwarts and beyond. Get ready to explore the secrets of magic!",
    
    "section_metepiuvisitate_div_titololpv_h2" => "MOST VISITED DESTINATIONS",
    
    "section_offertepromo_div_titoloofp_h2" => "OFFERS AND PROMO",
    
    "section_eventidata_legend_titolosec" => "<strong>ENTER THE PERIOD AND DISCOVER THE CORRESPONDING EVENT!</strong>",
    
    "section_eventidata_p" => "<strong>Function disabled!</strong>",
    
    "section_eventidata_form_p_pbottoni_input1" => "ENTER",
    
    "section_eventidata_form_p_pbottoni_input2" => "DELETE",
    
    "article_migliorirecensioni_table_caption_titolo_sec" => "<strong>UNIVERSE REVIEWS</strong>",
    
    "article_migliorirecensioni_table_thead_r1c1" => "RATING",
    
    "article_migliorirecensioni_table_thead_r1c2" => "LAST THREE",
    
    "article_migliorirecensioni_table_tbody_p" => "<strong>Filter by stars:</strong>",
    
    "article_migliorirecensioni_table_tbody_p_extra" => "<strong>You can’t filter by rating!</strong>",

    "offerte_non_loggato" => "Sign in or register to view offers!",

    "bottone_info_utente" => "User information",

    "bottone_chiudi_scheda" => "Close tab",

    "scheda_utente" => "User card");
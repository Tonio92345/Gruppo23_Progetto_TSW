<?php
    $dizionario = array("descrizione_iniziale_hp" => "Bienvenue dans mon univers, un monde enchanté de magie, d'aventure et d'émerveillement !
    Viens avec moi et explorons cet univers extraordinaire, 
    où des créatures fantastiques, des sorts puissants et des aventures épiques vous attendent à chaque coin de rue.", 

    "animazione_non_supportata_hp" => "L'animation qui devait être présente ici n'est pas prise en charge par le navigateur que vous utilisiez",

    "descrizione_breve_hogwarts_hp" => "Vivez l'aventure magique du château de Poudlard. Avec nous, explorez l'un des endroits les plus magiques 
    Vous pourrez vous promener dans les anciens couloirs du château, explorer les salles de classe enchantées et respirer l'air chargé d'histoire et de magie. 
    A l'intérieur, vous trouverez la grande salle avec les 
    ses quatre maisons distinctives, des salles de classe comme la classe de Potions et Transfiguration, 
    et des lieux emblématiques tels que la tour de l'horloge et la forêt interdite. N'attendez pas, réservez maintenant et commencez le 
    votre voyage au château le plus emblématique du monde magique! Poudlard vous attend pour vous accueillir dans son royaume enchanté",
    
    "tasto_espandi_hp" => "Voir en détail", 

    "posizione_hogwarts_hp" => "<strong>Position: </strong>Highlands écossais, Royaume-Uni", 
    
    "introduzione_hogwarts_hp" => "<strong>Introductione: </strong>L'École de Magie et de Sorcellerie de Poudlard est une école de magie située en Écosse,
    qui accueille la plupart des étudiants des îles britanniques âgés de onze à dix-sept ans.",
    
    "descrizione_totale_hogwarts_hp" => "Poudlard a été fondée vers la fin du Xe siècle par les quatre sorcières et magiciens britanniques les plus influents de leur époque, à savoir Godric Gryffondor, Tosca Poufsouffle, Priscilla Corvonero et 
    Salazar Serpeverde, qui ont divisé les étudiants en quatre maisons portant leurs noms de famille, chacune avec ses propres caractéristiques.
    <ul>
        <li>La maison de Gryffondor valorise le courage, l'audace et la noblesse d'âme</li>
        <li>La maison de Poufsouffle exige du travail, de la patience, de la loyauté, de la justice et de la ténacité</li>
        <li>La maison de Corvonero valorise l'intelligence, la créativité, l'apprentissage et la sagesse</li>
        <li>La maison de Serpeverde attache une grande importance à l'ambition, la ruse et l'ingéniosité</li>
    </ul>
    Poudlard est un grand château situé à proximité du village de Pousmade, se dresse sur une falaise au bord d'un lac dit lac noir, dans lequel réside une communauté de marides, 
    une pieuvre géante et de nombreuses espèces magiques aquatiques, c'est aussi l'endroit où j'ai (Harry) effectué la deuxième épreuve du Tournoi des Trois Sorcières.
    A proximité s'étend une vaste forêt sombre, dangereuse et interdite aux étudiants, appelée Forêt interdite.
    L'école est également entourée d'un grand parc avec des pelouses, des parterres de fleurs, des jardins potagers, des serres, un terrain de Quidditch et quelques bâtiments mineurs, comme la cabane du garde-chasse Rubeus Hagrid.
    En ce qui concerne le bâtiment principal de l'école, le château a sept étages et des souterrains, tous reliés par 142 escaliers, et abrite de nombreuses salles de classe, des dortoirs pour les 
    les étudiants et le personnel, les salles communes, les cours, les couloirs, les salles de représentation, les cuisines, une bibliothèque et une infirmerie.
    Sur certains escaliers, il y a des marches qui disparaissent lorsqu'elles sont piétinées; en outre, les mêmes escaliers et certaines salles de classe ont tendance à se déplacer, 
    En fait, comme on dit à Poudlard  \"les escaliers aiment changer\" donc il faut faire attention à s'orienter dans le château de la bonne manière.
    Une autre particularité de Poudlard sont quelques passages secrets, sept au total, qui mènent hors du château, ou des salles mystérieuses, comme la chambre des secrets ou la salle des besoins.
    Personne, dit-on, est au courant de tous les mystères de l'école, bien que le principal Albus Dumbledore, le gardien Argus Pie et les jumeaux Fred et George Weasley 
    Ils en ont une connaissance approfondie.
    Poudlard est enveloppé de diverses protections magiques. Certaines d'entre elles servent à cacher le château et le parc aux Babbans, qui ne voient à leur place qu'un tas de ruines
    et des signes de danger qui dissuadent de s'approcher. L'emplacement exact du château est inconnu et non identifiable.
    La devise qui se lit dans les armoiries de l'école est Draco dormiens nunquam titillandus, qui en latin signifie  \"Ne pas taquiner le dragon qui dort\".",
     
    "invito_prenotazione_hp" => "Réservez vous aussi", 
    
    "nome_prenotazione_hp" => "Nom",
    
    "cognome_prenotazione_hp" => "Prénom",
    
    "data_partenza_hp" => "De",
    
    "data_arrivo_hp" => "à",
    
    "tasto_invio_prenotazione_hp" => "envoi",

    "tasto_go_back_hp" => "Reviens",
    
    "descrizione_breve_hogsmade_hp" => "Nous sommes prêts à vous accueillir dans le village de Hogsmade. Découvrez 
    le premier et le seul village complètement magique en Grande-Bretagne. Ici vous pouvez 
    déguster un excellent burrobirra à la Locanda dei Tre Manici di Scopa, vous pourrez vous rendre à l'Emporio di Scrivani et à l'Iperbole pour acheter 
    objets magiques, puis faire un tour à l'Emporium des Farces de Zonko et voir beaucoup plus. Qu'attendez-vous? 
    Réservez dès maintenant votre voyage pour découvrir le village le plus magique du Royaume-Uni et plongez dans le monde enchanté d'Harry Potter!",
    
    "posizione_hogsmade_hp" => "<strong>Position: </strong>Grande-Bretagne, près de Poudlard", 
    
    "introduzione_hogsmade_hp" => "<strong>Introduction: </strong>Hogsmeade est connu pour être le seul centre habité de la Grande-Bretagne peuplé de magiciens seuls",
    
    "descrizione_totale_hogsmade_hp" => "Il a été fondé par Hengist le lutin des bois, qui s'y est réfugié pour échapper aux persécutions des Babbans dans le Northumberland.
    Le village est situé très près de Poudlard, de sorte que l'Express de Poudlard se termine à la gare de Pousmeade. Les élèves à partir de la troisième année, s’ils possèdent une autorisation
    signé par un parent ou un tuteur, ils peuvent visiter le village le week-end, faire du shopping dans les différents magasins et se divertir dans les clubs et pubs.
    Il y a beaucoup de magasins à Hogsmade et il y a beaucoup à voir, mais parmi mes favoris:
    <ul>
    <li>
        <strong>Les trois manches de balai</strong> <br>
        I Tre Manici di Scopa est un pub qui sert aussi d'auberge, parmi les plus fréquentés de Hogsmeade.
        Le local dispose d'une salle spacieuse, chaleureuse et confortable.En plus des magiciens communs, le pub est très fréquenté par les étudiants, les enseignants et le personnel de Poudlard.
        La barmaid est Madame Rosmerta, une belle femme qui attire les clients masculins du restaurant. Vous pouvez y boire beaucoup de boissons, entre
        La Burrobirra, une boisson célèbre et incontournable à Hogsmade.
    </li>
    <br>
    
    <li>
        <strong>Mielandia</strong> <br>
        Mielandia è un negozio di dolci molto frequentato da noi studenti di Hogwarts. I proprietari Ambrosius Flume e la moglie vivono nel piano superiore dello stesso edificio.
        Vende un'enorme gamma di dolci magici molto particolari, come gelatine tuttigusti+1(molto buone ma attenzione, una caramella vomito può arrivare quando meno te l'aspetti), api
        frizzole, fildimenta interdentali, piperille nere, topoghiacci, rospi alla menta e tanto altro ancora.
        Se ti piacciono i dolci è una tappa che ti consiglio assolutamente di fare.
    </li>
    <br>

    <li>
        <strong>L'emporio degli scherzi di Zonko</strong> <br>
        Zonko è un negozio di scherzi, i cui articoli sono molto popolari tra noi studenti di Hogwarts.
        Potrai trovare articoli unici perfetto per fare uno scherzo divertente ai tuoi amici
    </li>
    </ul>",
     
    "descrizione_breve_diagonAlley_hp" => "Bienvenue dans le magique Chemin de Traverse, la route secrète située derrière 
    le chaudron fumant de Londres qui mène au cœur du monde magique. 
    Nous vous invitons à venir avec nous dans cet endroit plein de boutiques magiques. Vous pourrez voir en direct Gringott's, d'où Harry Ron et 
    Hermione s'enfuit sur un dragon, la Banque des Magiciens, la boutique d'Olivander où vous pouvez acheter votre baguette magique, et de nombreux autres magasins 
    où faire vos achats magiques. Qu'attendez-vous? Réservez dès maintenant votre voyage et préparez-vous à découvrir les secrets cachés de cette voie magique extraordinaire!",
    
    "posizione_diagonAlley_hp" => "<strong>Position: </strong>Londres, Royaume-Uni", 
    
    "introduzione_diagonAlley_hp" => "<strong>Introduction: </strong>Diagon Alley est une rue de Londres où les magiciens de toute la Grande-Bretagne font leurs achats dans toutes sortes de magasins",
    
    "descrizione_totale_diagonAlley_hp" => "Diagon Alley est une rue cachée à la population moldave et est accessible par un passage à l'arrière de la
    Le Chaudron Magique, ou grâce à la Métrologie ou à la matérialisation. En plus d'être une rue pleine de magasins où les magiciens font leurs achats magiques à
    Diagon Alley abrite le Gringott, la banque des magiciens, dont moi (Harry), Ron et Hermione nous sommes échappés en volant sur un dragon.
    Parmi les étapes les plus intéressantes de Diagon Alley se trouvent:
    <ul>
    <li>
        <strong>Gringott</strong> <br>
        Gringott est la banque magique où les magiciens et les sorcières déposent leurs biens.
        Il ressemble à un bâtiment blanc et imposant situé à la jonction de Night Alley et Diagon Alley.
        L'entrée est délimitée par une double série de portes en bronze et argent. L'atrium est pavé de marbre et est parcouru par un long comptoir où siègent de nombreux employés et 
        où se déroulent les transactions.
        Le Gringott est dirigé par des lutins, bien que des employés humains y travaillent, comme Bill Weasley, qui est employé comme Brise-sorts pour le compte de la
        banque, ou Fleur Delacour, qui y effectue un stage à la fin de ses études pour améliorer son anglais. 
        La banque est considérée comme l'un des endroits les plus sûrs dans le monde magique. Les richesses des clients sont déposées dans des chambres fortes spéciales, toutes à l'épreuve des effractions et protégées
        par des sorts de sécurité sophistiqués, moi-même et mes amis ont pu(moi, Harry) le tester quand nous devions récupérer un Horcrux de Voldemort 
        Chambre forte de la famille Lestrange.
        Les chambres sont situées sous terre et s'étendent sur des kilomètres dans le sous-sol de Londres, dans un labyrinthe de passages souterrains et de grottes.
        Les chambres fortes les plus importantes, comme celle de la famille Lestrange, sont gardées par des dragons et des sphinx. Pour se déplacer à l'intérieur il y a des voies sur lesquelles
        Des petites clés dorées sont essentielles pour ouvrir les portes, tandis que certaines ne peuvent être ouvertes que par les lutins.
        Celui qui n'est pas un lutin de la banque et qui essaie de faire ça serait enfermé dans la chambre pour toujours.
    </li>
    <br>
    <li>
        <strong>Olivander</strong> <br>
        Olivander est le magasin de baguettes magiques de Garrick Olivander. Il semble ne pas être le seul magasin de baguettes magiques présent à Diagon Alley, même
        si c'est certainement le plus connu et le plus apprécié, ainsi que celui où je suis allé (Harry) chercher ma première baguette magique.
        Son apparence est cependant discrète, avec dans la vitrine seulement une baguette posée sur un tampon délavé et poussiéreux, et l'intérieur composé de longues
        des rangées de boîtes soigneusement empilées jusqu'au plafond.
        Olivander, dont les membres de la famille fabriquent des baguettes depuis des siècles, rappelle les caractéristiques de chaque baguette qu'il a vendue au fil des ans.
        Venez ici et vous pourrez également acheter votre baguette magique et rappelez-vous que ce n'est pas nous qui choisissons la baguette mais la baguette qui choisit le magicien.
    </li>
    <br>

    <li>
        <strong>Tirs vispi Weasley</strong> <br>
        Tiri Vispi Weasley est le magasin de farces magiques de Fred et George Weasley, situé au 93 Chemin de Traverse.
        Le magasin commence à prendre forme dans leurs idées dès que les deux à l'école commencent à inventer, produire et trafiquer sous la table une série d'articles
        Mais c'est seulement en fuyant Poudlard qu'ils pourront ouvrir le magasin.
        Malgré la mort de Fred lors de la bataille de Poudlard, le magasin a été dirigé par George.
        Le magasin reste donc encore aujourd'hui une très belle étape pour voir où trouver des articles géniaux et uniques en leur genre
    </li>
    </ul>",
    
    "sezione_recensioni_hp" => "SECTION COMMENTAIRES",

    "inserisci_recensione_hp" => "Publier une revue: ",

    "inserisci_stelle_hp" => "Entrez un nombre d'étoiles: ",

    "data_hp" => " en date du ",

    "prenotazione_non_loggato" => "Pour réserver, vous devez être connecté",

    "recensioni_non_loggato_hp" => "Pour pouvoir poster un avis, vous devez être connecté",

    "recensioni_non_loggato_hp" => "Pour réserver, vous devez être connecté",

    "descrizione_iniziale_db" => "Bienvenue dans l’univers incroyable de Dragon Ball ! Ici, l’aventure prend vie sous des cieux vibrants et des mondes fantastiques. Commencez le vôtre sur la mythique Terre, en explorant les montagnes et les plaines qui ont donné naissance à moi et à mes compagnons d’aventure. Ci-dessous, vous pouvez explorer des mondes qui conviennent seulement à ceux qui ont une force physique et spirituelle appropriée. Vous ferez face aux                   intempéries, à la gravité élevée et à d’autres difficultés utiles pour vos entraînements.",
    
    "scelta_db" => "Choisissez votre destination et...",
    
    "breve_descrizione1_db" => "Visitez Namecc, un monde extraverti aux couleurs particulières, habité par des extraterrestres très accueillants, les Nameks.
    Il a une structure rocheuse et une gravité tout à fait semblable à celle de la Terre, mais la surface de la planète se présente comme
    un immense océan parsemé de milliers de petites îles et d’îlots.",
    
    "stanza_db" => "Chambre de l’esprit et du temps",
    
    "breve_descrizione2_db" => "Réservez un voyage dans la Chambre de l’Esprit et du Temps, située au Temple de Dieu.
      Une année dans cette pièce équivaut à une journée à l’extérieur. La gravité est dix fois supérieure à la normale.
    Très utile si vous ne voulez pas perdre de <span>temps</span>!",
    
    "torneo_db" => "Tournoi Tenkaichi",
    
    "breve_descrizione3_db" => "Assistez aux meilleurs combats de la planète Terre, ici seulement, au tournoi le plus célèbre de tous. Vous rencontrerez les meilleurs combattants,
    Pourquoi ne pas vous mettre à l’épreuve et participer?",
    
    "caratteristiche1_db" => "<strong>Planète:</strong> Namecc <br> <strong>Habitants:</strong> Nameks <br> <strong>Risque:</strong> basse",
    
    "descrizione_approfondita1_db" => "C’est une planète de type terrestre.
      Il a une structure rocheuse et une gravité tout à fait semblable à celle de la Terre, mais il diffère à de nombreux égards.
      La surface de la planète ressemble à un immense océan parsemé de milliers et de milliers de petites îles et d’îlots,
      certains des récifs simples, d’autres plus vastes, mais il n’y a aucune trace de ce que l’on pourrait appeler un continent.
      La végétation, les arbustes et les plantes, est de couleur bleue et l’atmosphère et le ciel sont de couleur verte.
      La plupart de la faune est constituée de poissons ou d’amphibiens, et les seules créatures animales qui vivent sur la terre ferme semblent être les Nameks.
      La planète orbite autour de trois soleils, de sorte que la nuit ne tombe jamais sur Namek. De plus, une année Namek est composée de 130 jours terrestres.",
    
    "prenota_biglietto_db" => "Réservez votre billet d’avion...",
    
    "nome_db" => "Nom: ",
    
    "cognome_db" => "Prènom: ",
    
    "email_db" => "Email: ",
    
    "da_db" => "De: ",
    
    "a_db" => "A': ",
    
    "caratteristiche2_db" => "<strong>Planète:</strong> Terre <br> <strong>Habitants:</strong> aucun <br> <strong>Risque:</strong> inexistant",
    
    "descrizione_approfondita2_db" => "La Chambre de l’Esprit et du Temps est un monde vide, avec un seul bâtiment, dans lequel il y a l’entrée de la salle,
       avec un logement, des vivres, des salles de bains et des chambres à coucher. Dans la chambre il n’y a pas le jour et la nuit, mais dans les environs tout est blanc.
       La dilatation temporelle qui se produit dans la Chambre de l’Esprit et du Temps est qu’une journée hors de la salle équivaut à 1 an à l’intérieur,
       ou 1 minute dehors sont environ 6 heures dedans. À droite et à gauche du bâtiment, il y a 2 sabliers de sable émeraude, l’un qui fait tomber le sable en bas et l’autre en haut.
        Au centre du petit dôme dans le bâtiment, il y a aussi une horloge. La température varie de +60 degrés à -40 degrés.
        Grâce à cela, toute personne entrant dans la salle spéciale peut obtenir une année d’entraînement spécial et strict,
        Ils ne passeront que 24 heures dans la réalité.",
    
    "caratteristiche3_db" => "<strong>Planète:</strong> Terre <br> <strong>Participants:</strong> quiconque est admis <br> <strong>Risque:</strong> grand",
    
    "descrizione_approfondita3_db" => "Dépêchez-vous ! Le tournoi a lieu dans un stade sur l’île de Papaya, tous les trois ans.
       Les inscriptions au tournoi ont lieu le jour même de l’ouverture et sont ouvertes aux guerriers de tout âge et de tout sexe.
      Le tournoi se divise en deux phases, celle des éliminatoires, où tous les inscrits s’affrontent dans des combats à huis clos, et la phase des finales,
        Les huit finalistes sélectionnés lors des éliminatoires ont été retenus.
        Le tournoi Tenkaichi est célèbre pour les compétences incroyables des participants, les mouvements spectaculaires et les stratégies de combat uniques. Certains des personnages les plus
         Des icônes de Dragon Ball ont participé à ce tournoi, comme Goku, Piccolo, Vegeta, et bien d’autres. Pendant le tournoi, les participants sont soumis à des règles
         des spécifications telles que l’interdiction de l’utilisation d’armes et la nécessité de rester dans l’arène.
         Réservez aussi, et décidez si vous êtes un spectateur ou un participant!",
    
    "recensione_db" => "Laissez un avis",
    
    "torna_indietro" => "Retourner",
    
    "invia_prenotazione" => "Envoyer réservation", 

	
	"descrizioneAutoreSP" => "Bonjour visiteur ! Mon fidèle et meilleur ami Patrick Star et moi sommes prêts à vous guider et à vous montrer les magnifiques endroits sous-marins de Bikini Bottom. Plus bas, vous trouverez les Destinations populaires avec leurs informations correspondantes, les Avis & Commentaires et bien plus encore ! Si ce n'est pas déjà fait, connectez-vous/inscrivez-vous pour découvrir des offres et des produits incontournables. Je vous attends !",
	
    "destinazioniPopolariSP" => "Destinations populaires",
	
    "destinazioneBBSP" => "Explorez la ville sous-marine de SpongeBob et ses amis.",
	
    "destinazioneKKSP" => "Dégustez le célèbre Krabby Patty au restaurant de SpongeBob.",
	
    "destinazioneGWSP" => "Amusez-vous avec les manèges et les attractions au parc d'attractions.",
	
    "destinazioneVCSP" => "Hébergez-vous dans les maisons emblématiques et appréciées de tout Bikini Bottom.",
	
    "breveDescrizioneDettagliBBSP" => "Ville située au fond de l'océan Pacifique",
	
    "breveDescrizioneDettagliKKSP" => "Restaurant de restauration rapide",
	
    "breveDescrizioneDettagliGWSP" => "Parc d'attractions",
	
    "breveDescrizioneDettagliVCSP" => "Quartier principal",
	
    "descrizioneProfondaBBSP" => "Bikini Bottom est une ville sous-marine et le principal décor de la série animée SpongeBob SquarePants. Elle est située sur le fond marin de l'Océan Pacifique et est le lieu de résidence des personnages principaux de la série, notamment SpongeBob SquarePants, Patrick Star, Squidward Tentacles et Sandy Cheeks. La ville se caractérise par un mélange vibrant de paysages marins et d'étranges habitats sous-marins, allant des profondeurs sombres des abysses aux barrières coralliennes les plus lumineuses et colorées. Bikini Bottom est composée de divers quartiers et lieux emblématiques, chacun avec sa propre personnalité et atmosphère unique. Qu'attends-tu? Réserve maintenant!",
	
    "descrizioneProfondaKKSP" => "Le Krusty Krab est une institution culinaire emblématique située à Bikini Bottom. Sa structure extérieure rappelle la forme d'un vieux tonneau de homard. L'intérieur est caractérisé par des couleurs vives et lumineuses, avec une thématique marine comprenant des décorations telles que des filets de pêche, des gouvernails et des peintures de créatures marines. La cuisine est gérée par le chef SpongeBob SquarePants et est le cœur battant de l'opération du Krusty Krab, où sont préparés les célèbres Krabby Patty (un hamburger de qualité supérieure préparé avec des ingrédients secrets et aimé de tous les habitants de Bikini Bottom).",
	
    
    "descrizioneProfondaGWSP" => "Glove World est un parc d'attractions à thème et l'un des lieux les plus emblématiques et mémorables de Bikini Bottom, attirant des visiteurs de toute la ville sous-marine et au-delà. Glove World est inspiré du concept de gant, avec de nombreux éléments du parc évoquant l'idée de gants et de mains. Il se caractérise par des tours en forme de doigts de gant, des entrées en forme de main et des décorations rappelant des gants de différentes formes et tailles. L'ensemble du parc est conçu pour créer une atmosphère amusante et ludique. Glove World propose une large gamme d'attractions et de jeux pour divertir ses visiteurs, ainsi qu'une variété de points de restauration et de boutiques vendant des souvenirs à thème gant et des plats amusants comme le célèbre Glove Burger (hamburgers et frites à thème gant) et le Finger Hat Stand (chapeaux en forme de doigts de gant dans une variété de couleurs et de styles).",
	
    "descrizioneProfondaVCSP" => "Via della Conchiglia est l'une des rues les plus emblématiques et caractéristiques de Bikini Bottom. Sa position centrale en fait un point de repère important pour les habitants de la ville. L'aspect de la rue est caractérisé par une série de bâtiments colorés et une grande variété d'activités commerciales le long de ses côtés. Elle est souvent représentée avec une atmosphère animée et un va-et-vient constant de personnages. Le long de Via della Conchiglia, on trouve une variété de boutiques, de restaurants et d'autres établissements commerciaux. Il y a des boutiques de souvenirs qui vendent des articles à thème marin, tels que des coquillages, des jouets et des objets décoratifs. De plus, il y a des cafés et des restaurants qui proposent de la nourriture et des boissons aux habitants et aux visiteurs de Bikini Bottom. Certains des magasins les plus emblématiques comprennent le magasin de marionnettes, la crèmerie et le stand de popcorn. Via della Conchiglia abrite également de nombreuses résidences et maisons. Ces habitations présentent souvent une variété de styles architecturaux et de designs, allant des chalets en bois aux bâtiments plus élaborés. Certains des personnages principaux de la série vivent le long de cette rue ou à proximité.",
	
    "prenotazioneSP" => "Réservation",
	
    "nomeSP" => "Prénom",
	
    "dataArrivoSP" => "Date d'arrivée",
	
    "dataPartenzaSP" => "Date de départ",
	
    "prenotaSP" => "Réserver",
	
    "bottoneIndietroSP" => "Revenir en arrière",
	
    "sezioneRecensioniSP" => "Avis et Commentaires",
	
    "aggiungiCommentoSP" => "Ajouter un commentaire",
	
    "scriviCommentoSP" => "Écrire un commentaire",
	
    "inviaCommentoSP" => "Envoyer un commentaire",
	
    "ringraziamentoRecensioneSP" => "Merci d'avoir laissé votre avis, à bientôt !",
	
    "article_migliorirecensioni_table_caption_titolo_sec" => "Meilleures critiques",
	
    "article_migliorirecensioni_table_thead_r1c1" => "Note étoilée",
	
    "article_migliorirecensioni_table_thead_r1c2" => "Meilleurs 3 Commentaires",
	
    "article_migliorirecensioni_table_tbody_p" => "Choisissez la notation en étoiles",
	
    "accessoNecessarioSP" => "Vous devez vous connecter pour afficher!",

    //Dizionario login
    "registrazione_login" => "Enregistrement",

    "nome_login" => "Nom",

    "cognome_login" => "Prénom",

    "sesso_login" => "Sexe",

    "data_login" => "Date de naissance",

    "username_login" => "Nom d'utilisateur",

    "email_login" => "Adresse e-mail",

    "conf_login" => "Confirme password",

    "submit_login" => "Envoie",

    "linkAcc_login" => "Vous êtes déjà inscrit ? <a href='? reg=true&lan=". $lan." '>Connexion</a>",

    "trascina_foto_login" => "Faites glisser l'image à utiliser comme photo de profil",

    "linkReg_login" => "Vous n'avez pas de compte ? <a href='? reg=false&lan=". $lan." '>Inscription</a>",

    "non_corrisponde_login" => "*Les deux mots de passe ne correspondent pas",

    "utenteReg_login" => "Utilisateur enregistré!",

    "caratteri_speciali_nome_cognome_login" => "*Nom et prénom ne doivent pas contenir de chiffres ou de caractères spéciaux",

    "valida_mail_login" => "*Entrez un email avec le domaine gmail.com ,outlook.com ou studenti.unisa.it",

    "criteri_password_login" => "*Le mot de passe doit contenir un minimum de 8 et un maximum de 16 caractères, en plus il doit contenir au moins une lettre minuscule, une lettre majuscule et un caractère spécial",

    "accesso_login" => "Accès",

    "accesso_effettuato_login" => "Connectez-vous à la page <a href='../homepage/homepage.php?lan=". $lan."'>homepage</a>",

    "benvenuto_accesso_login" => "Bienvenue ",

    "password_errata_accesso_login" => "Password incorrecte",

    "email_esistente_accesso_login" => " Email inexistant",

    "tasto_accedi" => "CONNECTEZ-VOUS OU INSCRIVEZ-VOUS",

    //Dizionario Homepage
    "header_searchForm_input_placeholder" => "Recherche..",
    
    "header_searchForm_button_value" => "ENVOIE",
    
    "header_accessForm_button_value" => "ENTRE OU INSCRIS-TOI",
    
    "footer_adviceForm_p" => "Envoyez-nous un email, suggérant..",
    
    "footer_adviceForm_ol_li1_p" => "..un nouvel <span>univers</span>:",
    
    "footer_adviceForm_ol_li1_button_value" => "ENVOIE",
    
    "footer_adviceForm_ol_li2_p" => "..ou une nuouvelle <span>destination</span>:",
    
    "footer_adviceForm_ol_li2_button_value" => "ENVOIE",
    
    
    "footer_adviceForm_ol_li3_p" => "Merci, l’email va être envoyé!",
    
    "footer_aboutus_p_chisiamo" => "QUI ON EST",
    
    "footer_aboutus_p_testoaboutus" => "Nous sommes Antonio, Francesco, Alessandro et Luigi, quatre étudiants inscrits à la faculté de génie informatique de l’Université de Salerne qui vont passer l’examen de \"Software Technologies pour le Web\". Ce que vous voyez est le résultat <br> de notre projet, nous espérons être <br> à votre goût!",
    
    "aside_p_titaside" => "FAITES DÉFILER LA PAGE ET DÉCOUVREZ CE QUI SE TROUVE SOUS CHACUN DE CES CADEAUX!",
    
    "aside_narr_p_txtdbz" => "Salut! Je suis Gokû, le champion de la justice et le défenseur de notre univers! Tu peux m’appeler Kakarot, mon nom de Saiyan. Si tu vas dans mon univers, je serai <br> ton guide!",
    
    "aside_narr_p_txtspsq" => "Je suis SpongeBob, l’éponge la plus heureuse et joyeuse de tout Bikini Bottom! Je suis là pour vous conduire dans une aventure sous-marine que vous n’oublierez pas. Vite. Suis-moi, mon ami!",
    
    "aside_narr_p_txthp" => "Je m’appelle Harry Potter, ravi de vous rencontrer! Je suis là pour vous accompagner dans le monde magique de Poudlard et au-delà. Préparez-vous!",
    
    "section_metepiuvisitate_div_titololpv_h2" => "DESTINATIONS LES PLUS VISIT&EacuteES",
    
    "section_offertepromo_div_titoloofp_h2" => "OFFRES ET PROMOTIONS",
    
    "section_eventidata_legend_titolosec" => "<strong>ENTREZ LA P&EacuteRIODE ET D&EacuteCOUVREZ L’&EacuteV&EacuteNEMENT CORRESPONDANT!</strong>",
    
    "section_eventidata_p" => "<strong>Fonction désactivée!</strong>",
    
    "section_eventidata_form_p_pbottoni_input1" => "ENTREZ",
    
    "section_eventidata_form_p_pbottoni_input2" => "EFFACER",
    
    "article_migliorirecensioni_table_caption_titolo_sec" => "<strong>COMMENTAIRES UNIVERS</strong>",
    
    "article_migliorirecensioni_table_thead_r1c1" => "&EacuteVALUATION",
    
    "article_migliorirecensioni_table_thead_r1c2" => "TROIS D&EacuteRNIERES",
    
    "article_migliorirecensioni_table_tbody_p" => "<strong>Filtrer par les &eacutetoiles:</strong>",
    
    "article_migliorirecensioni_table_tbody_p_extra" => "<strong>Vous ne pouvez pas filtrer par <br> évaluation!</strong>",

    "offerte_non_loggato" => "Connectez-vous ou inscrivez-vous pour voir les offres!",

    "bottone_info_utente" => "Informations utilisateur",

    "bottone_chiudi_scheda" => "Fermer l’onglet",

    "scheda_utente" => "Onglet Utilisateur");

    
?>
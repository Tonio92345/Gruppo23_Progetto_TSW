<?php
    require_once "../logindb.php";
    include '../language/language.php';

    //Do inizio alla sessione che mi servirà per la variabile $_SESSION['logged']
    session_start();
    
    //Se sono appena entrato sul sito non sono loggato quindi metto a false $_SERVER['logged']
    if(!isset($_SESSION['logged'])){
        $_SESSION['logged'] = false;
    }
?>
<html>
    <head>
        <title>login</title>
        <link rel="stylesheet" type="text/css" href="login.css">
        <meta charset="utf-8"/>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <base href=""/>
        <link rel="icon" href="" type="image/png"/>
        <meta name="author" content="Gruppo_21"/>
        <meta name="keywords" content=""/>
        <meta name="description" content=""/>

        <script type="text/javascript">
            
            //Funzione chiamata sull'evento ondragover che permette ai dati di essere rilasciati in altri elementi in quanto di default
            //gli elementi non lo consentono
            function allowDrop(event){
                event.preventDefault();
            }

            //Funzione che imposta il tipo di dati e il valore dei dati trascinati
            //In questo caso ho dei dati di tipo "text" e l'informazione passata è la src dell'immagine trascinata
            //che poi una volta droppata diventerà il background della casella di testo con la foto profilo
            function drag(event){
                event.dataTransfer.setData("text", event.target.getAttribute("src"));

            }

            //Funzione che stabilisce cosa faccio una volta avvenuto il drop 
            function drop(event){
                event.preventDefault(); //Necessaria per permettere il drop
                
                var data = event.dataTransfer.getData("text");  //Prendo i dati droppati sottoforma di text
                event.target.style.backgroundImage = "url('" + data + "')"; //Imposto come background del input text la src droppata(appare quindi immagina scelta)
                
                var pic = document.getElementById('foto_scelta');   //Prendo il campo nascosto del form 
                pic.value = data;  //Inserisco nel campo nascosto la src della foto droppata/scelta dall'utente, così
                                    //verrà salvata la src della sua foto profilo e verrà mandata col form tramite metodo post
            }

            function validation(nomeModulo){
                //vedo se password e confermaPassword coincidono, se non lo fanno ritorno false e il form non si invia
                if(nomeModulo.password.value !== nomeModulo.confirm.value) {   
                    //Cambio il colore dei campi che non coincidono per evidenziarli all'utente
                    nomeModulo.password.style.backgroundColor = "rgba(255, 0, 0, 0.565)";
                    nomeModulo.confirm.style.backgroundColor = "rgba(255, 0, 0, 0.565)";

                    //Prendo il paragrafo nascosto ne cambio il contenuto per mostrare il messaggio di errore e lo mostro
                    //mettendo display block
                    var errore =  document.getElementById('error');
                    errore.innerText = "<?php echo $dizionario['non_corrisponde_login']; ?>";
                    errore.style.display = "block";

                    //Azzero i value di password e confermaPassword per svuotarli
                    nomeModulo.password.value = "";
                    nomeModulo.confirm.value = "";

                    //Restituisco false e non invio il modulo
                    return false;
                
                }
                
                //Restituisco true se password e confermaPassword coincidono
                return true;

            }

            //Funzione che applico per vedere se il campo nome e cognome hanno numeri o valori speciali al loro interno e se ciò avviene gestire l'errore
            function soloLettere(campo){
                var errore =  document.getElementById('error');     //Prendo il paragrafo nascosto usato per segnalare errore
                var btn = document.getElementById('reg_submit');   //Prendo il tasto submit
                var regex = /^[A-Za-z\s]+$/;    //Regex che rappresenta parola con solo lettere, no numeri e no caratteri speciali

                //Vedo se in nome/cognome la stringa inserita non va bene
                if(!campo.value.match(regex) && campo.value != ""){
                    
                    //Cambio il contenuto del paragrafo nascosto e lo mostro per segnalare l'errore
                    errore.innerText = "<?php echo $dizionario['caratteri_speciali_nome_cognome_login']; ?>";
                    errore.style.display = "block";
                    return false;

                }else{

                    //Se nome e cognome sono validi il bottone è attivo e il paragrafo che segnala l'errore è vuoto e nascosto
                    errore.style.display = "none";
                    errore.innerText = "";
                    return true;
                }
            }

            //Funzione che serve per fare in modo che dopo che do password e confermaPassword che non coincidono dopo  che mando il 
            //submit e le due caselle di testo si illuminano di rosso cliccandoci sopra per riscriverle in maniera corretta si leva
            //il background rosso
            function ripristina_colore(event){
                event.target.style.backgroundColor = "white";
            }


            
            function validaEmail(campo){
                var str = campo.value.toLowerCase();
                var dominio = str.split("@");
                var regex = /@/;
                var errore =  document.getElementById('error');     //Prendo il paragrafo nascosto usato per segnalare errore
                var btn = document.getElementById('reg_submit');   //Prendo il tasto submit


                if(regex.test(str)){
                    if(dominio[1] == "gmail.com"  || dominio[1] == "outlook.com" || dominio[1] == "studenti.unisa.it"){ 
                        //Se il dominio è giusto non c'è errore
                        errore.style.display = "none";
                        errore.innerText = "";
                        return true;

                    }else{
                        //Cambio il contenuto del paragrafo nascosto e lo mostro per segnalare l'errore
                        errore.innerText = "<?php echo $dizionario['valida_mail_login']; ?>";
                        errore.style.display = "block";
                        return false;

                    }
                }
                else{
                    //Se nella stringa dell'email non c'è @ non dobbiamo fare nessun controllo, l'input di type mail
                    //si accorge già da solo che l'email non va bene perchè non c'è @
                    errore.style.display = "none";
                    errore.innerText = "";
                    return true;

                }
            }

            function validaPassword(campo){
                var psw = campo.value;
                var errore =  document.getElementById('error');     //Prendo il paragrafo nascosto usato per segnalare errore
                var btn = document.getElementById('reg_submit');   //Prendo il tasto submit
                var regex = /(?=.*[a-z])(?=.*[A-Z])(?=.*[\W_])/

                if(!regex.test(psw) && psw != ""){
                    campo.style.backgroundColor = "red";
                    //Cambio il contenuto del paragrafo nascosto e lo mostro per segnalare l'errore
                    errore.innerText = "<?php echo $dizionario['criteri_password_login']; ?>";
                    errore.style.display = "block";
                    return false;

                }else{
                    //Il paragrafo torna ad essere vuoto e nascosto se la password rispetta i vincoli richiesti
                    errore.innerText = "";
                    errore.style.display = "none";
                    return true;

                }
                
            }


            function valida_campo_form(){
                var nome = document.getElementById('nome_reg');
                var cognome = document.getElementById('cognome_reg');
                var mail = document.getElementById('mail_reg');
                var psw = document.getElementById('pass_reg');
                var btn = document.getElementById('reg_submit');   //Prendo il tasto submit

                if(!soloLettere(nome)){
                    //Disabilito il bottone di invio quando ho password non valida
                    btn.disabled = true;
                    btn.addEventListener("mouseover", function(event){
                        event.target.style.cursor = "not-allowed";
                    });
                
                }else if(!soloLettere(cognome)){
                    //Disabilito il bottone di invio quando ho password non valida
                    btn.disabled = true;
                    btn.addEventListener("mouseover", function(event){
                        event.target.style.cursor = "not-allowed";
                    });
                }else if(!validaEmail(mail)){
                    //Disabilito il bottone di invio quando ho password non valida
                    btn.disabled = true;
                    btn.addEventListener("mouseover", function(event){
                        event.target.style.cursor = "not-allowed";
                    });
                }else if(!validaPassword(psw)){
                    //Disabilito il bottone di invio quando ho password non valida
                    btn.disabled = true;
                    btn.addEventListener("mouseover", function(event){
                        event.target.style.cursor = "not-allowed";
                    });
                }else{
                    //Abilito il bottone di invio quando ho password valida
                    btn.disabled = false;
                    btn.addEventListener("mouseover", function(event){
                        event.target.style.cursor = "pointer";
                    })
                }
            }
            
        </script>

    </head>
    <body>

    <?php
        //Se non è settata la variabile log la imposto a false per far vedere inizialmente all'utente la pagina per l'accesso
        if(!isset($_GET["reg"])){
            $_GET["reg"]="true";
        }

        //Se l'utente non è loggato perchè ha fatto click sul link REGISTRATI allora log sarà false e quindi mostrerò la pagina per la registrazione
        if($_GET["reg"] == "false"){

    ?>
        <!--Div dove trovo a sinistra i dati da inserire e a destra la parte dedicata alla scelta della foto profilo-->
        <h1><?php echo $dizionario['registrazione_login']?></h1>
        <div id="registrazione">

            <!--Div dedicato all'inserimento dei dati-->
            <div id="campi_reg">
                <!--Form con i vari campi da inserire-->
                <form action="<?php echo $_SERVER['PHP_SELF']?>?reg=false&lan=<?php echo $lan; ?>" method="post" onSubmit="return validation(this);">
                    
                    <!--Nome-->
                    <p>
                        <label for="nome"><?php echo $dizionario['nome_login']; ?></label><br>
                        <input type="text" name="nome" id="nome_reg" placeholder="Giovanni" value="<?php echo isset($_POST['nome']) ? $_POST['nome'] : ''; ?>" class="campo_form" onchange="valida_campo_form()" required >
                    </p>

                    <!--Cognome-->
                    <p>
                        <label for="cognome"><?php echo $dizionario['cognome_login']; ?></label> <br>
                        <input type="text" name="cognome"  id="cognome_reg" placeholder="Rossi" value="<?php echo isset($_POST['cognome']) ? $_POST['cognome'] : ''; ?>" class="campo_form" onchange="valida_campo_form()" required>
                    </p>

                    <!--Sesso-->
                    <p>
                        <?php echo $dizionario['sesso_login']; ?> <br>
                        <label for="m">M </label> <input id="male" type="radio" name="sesso" value="M" <?php echo isset($_POST['sesso']) && $_POST['sesso'] == 'M' ? 'checked' : ''; ?> required>
                        <label for="f">F </label> <input id="female" type="radio" name="sesso" value="F" <?php echo isset($_POST['sesso']) && $_POST['sesso'] == 'F' ? 'checked' : ''; ?> required>
                    </p>

                    <!--Data di nascita-->
                    <p>
                        <label for="data"><?php echo $dizionario['data_login']; ?></label> <br>
                        <input type="date" name="data" value="<?php echo isset($_POST['data']) ? $_POST['data'] : ''; ?>" required>
                    </p>

                    <!--Username-->
                    <p>
                        <label for="username"><?php echo $dizionario['username_login']; ?></label> <br>
                        <input type="text" name="username" value="<?php echo isset($_POST['username']) ? $_POST['username'] : ''; ?>" title="Please enter your username" class="campo_form" required>
                    </p>

                    <!--Email-->
                    <p>
                        <label for="email"><?php echo $dizionario['email_login']; ?></label> <br>
                        <input type="email" name="email"  id="mail_reg" placeholder="Giovanni.rossi@gmail.com" value="<?php echo isset($_POST['email']) ? $_POST['email'] : ''; ?>" onchange="valida_campo_form()" class="campo_form" required>
                    </p>

                    <!--Password-->
                    <p>
                        <label for="password">Password</label> <br>
                        <input type="password" name="password"  id="pass_reg" class="campo_form" onclick="ripristina_colore(event)" onblur="valida_campo_form()" minlength="8" maxlength="16" required>
                    </p>

                    <!--Conferma password-->
                    <p>
                        <label for="confirm"><?php echo $dizionario['conf_login']; ?></label> <br>
                        <input type="password" name="confirm" class="campo_form" onclick="ripristina_colore(event)" required minlength="8" maxlength="16">
                    </p>

                    <!--Paragrafo nascosto che serve a segnalare gli errori che fa l'utente quando inserisce i campi del form-->
                    <p id="error"></p>

                    <!--Paragrafo nascosto dove metto la src della foto che l'utente sceglie e trascina nella parte dedicata alla foto profilo
                        Inizialmente il value di questo paragrafo è la foto utente di default, cambia col drop dell'immagine-->
                    <input type="text" name="propic" id="foto_scelta" value="propics/propic.png">
                    
                    <!--Tasto submit-->
                    <input type="submit" value="<?php echo $dizionario['submit_login']; ?>" class="submit" id="reg_submit">

                    <!--Scritta con link alla pagina di accesso dove la variabile passata tramite metodo GET log è true 
                        e viene dunque mostrata la pagina per fare accesso diretto con solo email e password-->
                    <p>
                        <?php echo $dizionario['linkAcc_login']; ?>
                    </p>
                    
                </form>
            </div>

            <!--Div dedicato alla scelta della foto profilo-->
            <div id="scegli_foto">
                
                <!--Riquadro circolare dove trascino la foto, è un input di tipo text che prende come background-image l'immagine che
                    trasciniamo (Drag and Drop)-->
                <p>
                    <input type="text" readonly name="foto" id="drop_foto" ondrop="drop(event)" ondragover="allowDrop(event)"> <br>
                    <label for="foto"><?php echo $dizionario['trascina_foto_login']; ?></label>
                </p>

                <!--Div dove sono presenti le varie foto profilo da scegliere-->
                <div id="set_foto">
                    <img src="propics/propicHP_7" alt="Immagine Harry Potter" draggable="true" class="img_profilo" ondragstart="drag(event)">
                    <img src="propics/propicHP_8" alt="Immagine Hermione Granger" draggable="true" class="img_profilo" ondragstart="drag(event)">
                    <img src="propics/propicHP_9" alt="Immagine Ron Weaslay" draggable="true" class="img_profilo" ondragstart="drag(event)">
                    <img src="propics/propicHP_6" alt="Immagine Voldemort" draggable="true" class="img_profilo" ondragstart="drag(event)">
                    <img src="propics/goku" alt="Immagine Goku" draggable="true" class="img_profilo" ondragstart="drag(event)">
                    <img src="propics/vegeta" alt="Immagine Vegeta" draggable="true" class="img_profilo" ondragstart="drag(event)">
                    <img src="propics/majin-bu" alt="Immagine Majin-bu" draggable="true" class="img_profilo" ondragstart="drag(event)">
                    <img src="propics/freezer" alt="Immagine Freezer" draggable="true" class="img_profilo" ondragstart="drag(event)">
                    <img src="propics/spongebob" alt="Immagine SpongeBob" draggable="true" class="img_profilo" ondragstart="drag(event)">
                    <img src="propics/patrik" alt="Immagine Patrik" draggable="true" class="img_profilo" ondragstart="drag(event)">
                    <img src="propics/squiddy" alt="Immagine Squiddy" draggable="true" class="img_profilo" ondragstart="drag(event)">
                    <img src="propics/plankton" alt="Immagine Plankton" draggable="true" class="img_profilo" ondragstart="drag(event)">
                
                </div>
            </div>
        </div>
            

    <?php
        //Se ho passato info col form tramite metodo post posso inserire utente connettendomi al database
		if(!empty($_POST)){
            //CONNESSIONE AL DB
            $db = pg_connect($connection_string) or die('Impossibile connetersi al database: ' . pg_last_error());
            
            //Prendo i valori dei campi che dovrò inserire nella tabella utenti del database
            $username = pg_escape_literal($_POST["username"]);
            $nome = pg_escape_literal($_POST["nome"]);
            $cognome = pg_escape_literal($_POST["cognome"]);
            $sesso = $_POST["sesso"];
            $data = $_POST["data"];
            $email = strtolower(pg_escape_literal($_POST["email"]));
            $password = password_hash(pg_escape_literal($_POST["password"]), PASSWORD_DEFAULT); //Metto nel database il valore hash della password
            $propic = pg_escape_literal($_POST["propic"]);

            //Creo la query string e la preparo per vedere se va bene
            $sql = "INSERT INTO utenti(username, nome, cognome, sesso, data, email, password, propic)
                    VALUES($1, $2, $3, $4, $5, $6, $7, $8)";
            $ret = pg_prepare($db,"InsertUtenti", $sql);
            
            //Se non va bene mostro errore sennò procedo
            if(!$ret) {
                echo pg_last_error($db);
            }else{
                //echo "<p>Prepared Statement Creato</p>";

                //Preparo la query per prendere tutti gli utenti della table e la eseguo
                $sql = "SELECT * FROM utenti";
                $utenti = pg_query($db, $sql);

                //Se la query da errore lo stampo
                if(!$utenti) {
                    echo pg_last_error($db);
                
                }else{
                    //Uso la variabile presente per verificare se i campi inseriti che sono primary key corrispondono
                    //alle primary key di un utente già presente nella table e quindi non è possibile inserire il nuovo utente
                    //con le stesse primary key
                    $email_presente = false;
                    $username_presente = false;

                    //Scorro la table e non appena vedo che l'utente che voglio inserire ha email o username uguali a quelli di 
                    //un utente già presente nella table presente diventa true
                    while($row = pg_fetch_assoc($utenti)){
                        foreach ($row as $key => $value) {
                            if($key == "username" && $value === $username){
                                $username_presente = true;
                            }
                            if($key == "email" && $value === $email){
                                $email_presente = true;
                            }
                        }
                    }
                    //Se presente=false eseguo la query per inserire il nuovo utente nella table e verifico con ret che sia andata a buon fine
                    if($username_presente == false && $email_presente == false){
                        $ret = pg_execute($db, "InsertUtenti", array($username, $nome, $cognome, $sesso, $data, $email, $password, $propic));
                    ?>
                    <script>
                        alert("<?php echo $dizionario['utenteReg_login']; ?>");
                    </script>
                        
                    <?php
                        if(!$ret){
                            echo pg_last_error($db);
                        }

                    }else if($username_presente == true && $email_presente == true){ //Caso entrambi già presenti
                        ?>
                        <script type="text/javascript">
                            //Prendo il paragrafo nascosto usato per segnalare errore
                            var errore =  document.getElementById('error');

                            //Cambio il contenuto del paragrafo nascosto e lo mostro per segnalare l'errore
                            errore.innerText = "*Email e Nome utente già utilizzati";
                            errore.style.display = "block";
                        </script>

                        <?php
                    }else if($username_presente == true){   //Caso dove solo lo username è già usato
                        ?>
                        <script type="text/javascript">
                            //Prendo il paragrafo nascosto usato per segnalare errore
                            var errore =  document.getElementById('error');

                            //Cambio il contenuto del paragrafo nascosto e lo mostro per segnalare l'errore
                            errore.innerText = "*Nome utente già utilizzato";
                            errore.style.display = "block";
                        </script>

                        <?php
                    }else if($email_presente == true){
                        ?>
                        <script type="text/javascript">
                            //Prendo il paragrafo nascosto usato per segnalare errore
                            var errore =  document.getElementById('error');

                            //Cambio il contenuto del paragrafo nascosto e lo mostro per segnalare l'errore
                            errore.innerText = "*Email già utilizzata";
                            errore.style.display = "block";
                        </script>

                        <?php
                    }
                }
            }
            //Chiudo la connessione
            pg_close($db);
        }
        
        //Ora se log=true carico la pagina di accesso, non quella di registrazione dell'utente
        }else{   
        ?>

        <!--Pagina di accesso-->
        <h1 id="accessTitle"><?php echo $dizionario['accesso_login']; ?></h1>
        <div id="accesso">
            <!--Form con i campi per l'accesso-->
            <form action="<?php echo $_SERVER['PHP_SELF']?>?reg=true&lan=<?php echo $lan; ?>" method="post" id="moduloAccesso">
                <!--Email-->
                <p>
                    <label for="email"><?php echo $dizionario['email_login']; ?></label> <br>
                    <input type="email" placeholder="Giovanni.rossi@gmail.com" value="<?php echo isset($_POST['email']) ? $_POST['email'] : ''; ?>" name="email">
                </p>

                <!--Password-->
                <p>
                    <label for="password">Password</label> <br>
                    <input type="password" name="password">
                </p>

                <!--Tasto submit-->
                <input type="submit" value="<?php echo $dizionario['submit_login']; ?>" class="submit">

                <!--Paragrafo nascosto per segnalare errori o altro durante l'accesso-->
                <p id="messaggioAccesso"></p>

                <!--Testo con link a che porta alla pagina di registrazione mettendo con metodo get log=false-->
                <p>
                    <?php echo $dizionario['linkReg_login']; ?>
                </p>
                
            </form>

            <!--Contenitore  nascosto che viene mostrato quando l'utente accede con le sue credenziali-->
            <div id="benvenuto">
                <!--Contenitore coll messaggio di benvenuto e invito ad andare alla homepage dopo che l'utente si è loggato-->
                <div>
                    <p> <?php echo $dizionario['accesso_effettuato_login']; ?> </p>
                </div>
                <!--Contenitore con l'immmagine profilo dell'utente appena loggato-->
                <div>
                    <img src="" alt="Foto profilo account" id="propic_benvenuto">
                </div>
            </div>
        </div>

        <?php
            //Se il vettore di post non è vuoto, ovvero se l'utente ha inviato i dati con il form
            if(!empty($_POST)){
                //CONNESSIONE AL DB
                $db = pg_connect($connection_string) or die('Impossibile connetersi al database: ' .pg_last_error());
                
                //Prendo email e password inserite
                $email = strtolower(pg_escape_literal($_POST["email"]));
                $password = pg_escape_literal($_POST["password"]);

                //Prendo colonna email dal database
                $sql = "SELECT email FROM utenti";
                $mails = pg_query($db, $sql);

                //Se la query da errore lo stampo
                if(!$mails) {
                    echo pg_last_error($db);
                }else{
                    //Scorro la table e vedo se c'è una mail uguale a quella inserita dall'utente e se 
                    //trovo la mail prendo anche il valore della riga dove è presente l'email tramite 
                    //counter_row(così facendo so quale è la riga con dati utente)
                    $trovato = false;
                    $counter_row = 0;
                    while($row = pg_fetch_assoc($mails)){
                        foreach($row as $key => $value){
                            if($value == $email){
                                $trovato = true;
                                break;
                            }
                        }
                        if($trovato == true ){
                            break;
                        }else{
                            $counter_row++;
                        }
                    }

                    //Se ho trovato mail prendo tramite la funzione pg_fetch_result() gli altri dati(password, nomeUtente e propic) presenti 
                    //nella riga dell'utente tramite pg_fetch_result()(posso farlo perchè so che la riga dell'utente si trova a indice=counter_row)
                    //verifico che la password inserita corrispondano alla password dell'utente con quella mail
                    if($trovato == true){
                        
                        //Prendo colonne utenti dal database e prendo info che mi interessano
                        $sql = "SELECT * FROM utenti";
                        $utenti = pg_query($db, $sql);
                        
                        $_SESSION['username'] = pg_fetch_result($utenti, $counter_row, 'username');
                        $_SESSION['nome'] = pg_fetch_result($utenti, $counter_row, 'nome');
                        $_SESSION['cognome'] = pg_fetch_result($utenti, $counter_row, 'cognome');
                        $_SESSION['sesso'] = pg_fetch_result($utenti, $counter_row, 'sesso');
                        $_SESSION['data'] = pg_fetch_result($utenti, $counter_row, 'data');
                        $_SESSION['email'] = pg_fetch_result($utenti, $counter_row, 'email');
                        $_SESSION['propic'] = pg_fetch_result($utenti, $counter_row, 'propic');
                        

                        $password_trovata = pg_fetch_result($utenti, $counter_row, 'password');
                        $nomeUtente_trovato = pg_fetch_result($utenti, $counter_row, 'username');
                        $propic_trovata = pg_fetch_result($utenti, $counter_row, 'propic');

                        //Verifico se la password inserita ha lo stesso valore di hash della password nel database
                        if(password_verify($password, $password_trovata)){
                            //Se la password è giusta l'utente accede quindi la vvaraiabile log=true
                            $_SESSION['logged'] = true;
                            ?>

                            <!--Script che mostra all'utente quando accede correttamente che ha effettuato l'accesso e mostra la pagina nascosta di benvenuto-->
                            <script type="text/javascript">
                                //Prendo il div con il form per accedere e il div che devo mostrare all'utente per dargli il benvenuto
                                var acc = document.getElementById('moduloAccesso');
                                var hidden = document.getElementById('benvenuto');
                                
                                //Nascondo la pagina per accedere e mostro qulla di benvenuto cambiando da display 'none' a display 'flex'
                                acc.style.display = "none";
                                hidden.style.display = "flex";
                                
                                //Modifico il contenuto del titolo del div di accesso scrivendo il messaggio di benvenuto per il nome utente
                                //che ha effettuato l'accesso
                                var title = document.getElementById('accessTitle');
                                title.innerHTML = "<?php echo $dizionario['benvenuto_accesso_login'].$nomeUtente_trovato;?>";

                                //Imposto come foto della pagina di benvenuto la pagina dell'utente loggato
                                var foto = document.getElementById('propic_benvenuto');
                                foto.src = <?php echo $propic_trovata; ?>;
                            </script>
                                
                            <?php
                        }else{
                            ?>
                            <!--Script che mostra messaggio di errore se la password è sbagliata-->
                            <script type="text/javascript">
                                //Prendo il paragrafo nascosto
                                var messaggio = document.getElementById('messaggioAccesso');

                                //Mostro il paragrafo e scrivo il messaggio di errore al suo interno
                                messaggio.style.display = "block";
                                messaggio.innerText = "<?php echo $dizionario['password_errata_accesso_login'];?>";
                            </script>
                            <?php
                        }
                    }else{
                        ?>
                        <!--Script che mostra messaggio di errore se si prova ad accedere con un email non presente nel database, quindi
                            non è associata a nessun utente-->
                        <script type="text/javascript">
                            //Prendo il paragrafo nascosto
                            var messaggio = document.getElementById('messaggioAccesso');

                            //Mostro il paragrafo e scrivo il messaggio di errore al suo interno
                            messaggio.style.display = "block";
                            messaggio.innerText = "<?php echo $dizionario['email_esistente_accesso_login'];?>";
                        </script>
                        <?php
                    }
                }
                pg_close($db);  //Chiudo la connessione
            }
        }
        ?>
        
    </body>
</html>
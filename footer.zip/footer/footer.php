<script src="../footer/footer.js"></script>
<link rel="stylesheet" type="text/css" href="../footer/footer.css">

<div class="footer">
    <div class="social">
        <a href="https://www.instagram.com/multiversus.tsw21/"><img src="../footer/img/instagram_logo_bw.png" alt="uk_flag" width="40px"></a>
        <a href="https://www.facebook.com/profile.php?id=61556461230445"><img src="../footer/img/facebook_logo_bw.png" alt="italy_flag" width="40px"></a>
        <a href="https://twitter.com/Multiversus21"><img src="../footer/img/x_logo_bw.png" alt="france_flag" width="40px"></a>
    </div>
    <div class="suggeriscici">
        <form id="adviceForm">
            <p><?php echo $dizionario['footer_adviceForm_p'];?></p>
            <ol>
                <li>
                    <p><?php echo $dizionario['footer_adviceForm_ol_li1_p'];?></p>
                    <input class="inputText" id="adv_uni" type="text" placeholder="Es. Pokemon" oninput="submitDisabled(0)">
                    <button class="buttonInvia" type="submit" onclick="mailSubmitted(0)" disabled="true"><?php echo $dizionario['footer_adviceForm_ol_li1_button_value'];?></button>
                </li>
                <li>
                    <p><?php echo $dizionario['footer_adviceForm_ol_li2_p'];?></p>
                    <input class="inputText" id="adv_meta" type="text" placeholder="Es. Kame House" oninput="submitDisabled(1)">
                    <button class="buttonInvia" type="submit" onclick="mailSubmitted(1)" disabled="true"><?php echo $dizionario['footer_adviceForm_ol_li2_button_value'];?></button>
                </li>
                <li value="3">
                    <p><?php echo $dizionario['footer_adviceForm_ol_li3_p'];?></p>
                </li>
            </ol>
        </form>
    </div>
    <div class="about_us">
        <p id="chisiamo" onclick="appear()"><?php echo $dizionario['footer_aboutus_p_chisiamo'];?></p>
        <img src="../footer/img/Paper_footer.png" alt="paper_aboutus" width="400px">
        <p id="testo_aboutus"><?php echo $dizionario['footer_aboutus_p_testoaboutus'];?></p>
    </div>    
    <div class="logo_footer">
        <a href="../homepage/homepage.php?lang=<?php echo $lan;?>"><img src="../footer/img/B.png" alt="logo_multiversus" width="300px"></a>
    </div>
</div>